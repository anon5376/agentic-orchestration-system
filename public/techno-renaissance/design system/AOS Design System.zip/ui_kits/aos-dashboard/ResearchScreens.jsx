const { EvidencePlate, ConvergenceCore, ContextInspector, Button, StateBadge, SectionLabel, Telemetry } = window.AOSDesignSystem_20e4c5;
const DE = window.AOSDATA;

function EvidenceScreen({ sel, setSel, run, RouteHeader }) {
  const selected = DE.evidence.find((e) => e.id === sel);
  const facets = [
    { label: "PRIMARY", n: 4 }, { label: "USER DOCUMENT", n: 1 }, { label: "DERIVED", n: 1 },
    { label: "CONTRADICTED", n: 2, tone: "consequence" }, { label: "UNRESOLVED", n: 1, tone: "consequence" }
  ];
  return (
    <>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <RouteHeader label="Evidence" index="04/08" title="128 items, 6 consequential, 2 contradicted."
          telemetry={[{ label: "Items", value: "128" }, { label: "Verified", value: "96", tone: "verified" }, { label: "Contradicted", value: "2", tone: "consequence" }, { label: "Producers", value: "9" }]} />
        <div style={{ flex: 1, minHeight: 0, display: "flex" }}>
          <div style={{ width: "196px", flex: "none", borderRight: "1px solid var(--border-on-dark)", padding: "var(--space-6) var(--space-5)", display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
            <SectionLabel on="dark">Provenance</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column" }}>
              {facets.map((f) => (
                <button key={f.label} onClick={() => run(`evidence filter --provenance ${f.label.toLowerCase()}`)} style={{ display: "flex", justifyContent: "space-between", gap: "10px", background: "transparent", border: "none", borderBottom: "1px solid var(--border-on-dark)", padding: "9px 0", cursor: "pointer", font: "400 11px/1 var(--font-telemetry)", letterSpacing: "0.06em", color: f.tone ? "var(--vermilion)" : "var(--text-on-dark-secondary)" }}>
                  <span>{f.label}</span><span style={{ color: "var(--cold-white)" }}>{f.n}</span>
                </button>
              ))}
            </div>
            <SectionLabel on="dark">Producers</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: "7px", font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>
              {[["A-14", 22], ["A-07", 38], ["V-03", 31], ["A-31", 14], ["A-19", 9], ["CL-1", 34]].map(([id, n]) => (
                <div key={id} style={{ display: "flex", justifyContent: "space-between" }}><span>{id}</span><span style={{ color: "var(--text-on-dark-secondary)" }}>{n}</span></div>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "var(--space-6) var(--gutter-page)", display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: "var(--space-5)", alignContent: "start" }}>
            {DE.evidence.map((e) => (
              <EvidencePlate key={e.id} on="dark" {...e} selected={sel === e.id} onOpen={() => { setSel(e.id); run(`evidence trace ${e.id}`); }} />
            ))}
          </div>
        </div>
      </div>
      <ContextInspector
        open={!!selected} kind="EVIDENCE" title={selected ? selected.id : ""} subtitle={selected ? selected.source : ""}
        sections={selected ? [
          { label: "Claim", body: selected.claim },
          { label: "Provenance", rows: [{ k: "Class", v: selected.provenance }, { k: "Freshness", v: selected.freshness }, { k: "Confidence", v: selected.confidence, tone: "active" }, { k: "Produced by", v: selected.producedBy }] },
          { label: "Downstream", rows: (selected.consumers || []).map((c) => ({ k: "Used by", v: c })) },
          { label: "Dissent", rows: [{ k: "State", v: selected.contradiction ? "CONTRADICTED" : "CORROBORATED", tone: selected.contradiction ? "consequence" : "verified" }], body: selected.contradiction ? "The contradiction stays attached to the claim and travels into synthesis. It is not resolved by removal." : "No open contradiction recorded against this item." }
        ] : []}
        onClose={() => setSel(null)}
        actions={<><Button on="dark" variant="secondary" size="sm" full onClick={() => run(`evidence open --source ${sel}`)}>Open source</Button><Button on="dark" variant="ghost" size="sm" full onClick={() => run(`evidence dispute ${sel}`)}>Dispute</Button></>}
      />
    </>
  );
}

function SynthesisScreen({ coreOpen, setCoreOpen, run, go, RouteHeader }) {
  const objections = DE.branches.filter((b) => b.state === "conflict");
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <RouteHeader label="Synthesis" index="05/08" title="Six branches compress into one ranked conclusion."
        telemetry={[{ label: "Branches", value: "6" }, { label: "Evidence", value: "128", tone: "verified" }, { label: "Confidence", value: "0.72", tone: "active" }, { label: "Objections", value: "3", tone: "consequence" }]} />
      <div style={{ flex: 1, minHeight: 0, display: "flex" }}>
        <div style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "var(--space-8) var(--gutter-page)" }}>
          <ConvergenceCore
            size={188} agents={41} models={5} evidence={128} generation="08" confidence="0.72" objections={3}
            branches={DE.branches} expanded={coreOpen} onToggle={() => setCoreOpen(!coreOpen)}
          />
          <div style={{ marginTop: "var(--space-10)", borderTop: "1px solid var(--border-on-dark-strong)", paddingTop: "var(--space-7)", display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
            <SectionLabel on="dark">Proposed conclusion</SectionLabel>
            <p style={{ margin: 0, maxWidth: "40ch", font: "400 34px/1.06 var(--font-display)", letterSpacing: "var(--tracking-display)", color: "var(--cold-white)", textWrap: "pretty" }}>
              On disclosed capacity alone, supply falls short of 2029 EU demand by 11–19%.
            </p>
            <p style={{ margin: 0, maxWidth: "var(--measure-body)", font: "400 15px/1.5 var(--font-interface)", color: "var(--text-on-dark-secondary)" }}>
              The conclusion holds only while announced ramp schedules are discounted at their historical slip rate and imports remain outside the mission boundary. Two objections below can invert the sign of the result.
            </p>
            <div style={{ display: "flex", gap: "10px", marginTop: "var(--space-4)" }}>
              <Button on="dark" variant="primary" onClick={() => run("synthesis accept --with-objections")}>Accept with objections</Button>
              <Button on="dark" variant="secondary" onClick={() => go("EVIDENCE")}>Inspect inputs</Button>
              <Button on="dark" variant="ghost" onClick={() => run("synthesis reopen --branch A-19")}>Reopen branch</Button>
            </div>
          </div>
        </div>
        <div style={{ width: "320px", flex: "none", borderLeft: "1px solid var(--border-on-dark-strong)", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "var(--space-5)", borderBottom: "1px solid var(--border-on-dark)" }}>
            <SectionLabel on="dark" rule>Unresolved objections</SectionLabel>
          </div>
          {objections.map((o) => (
            <div key={o.label} style={{ padding: "var(--space-5)", borderBottom: "1px solid var(--border-on-dark)", borderLeft: "3px solid var(--vermilion)", display: "flex", flexDirection: "column", gap: "8px" }}>
              <span style={{ font: "400 15px/1.35 var(--font-interface)", color: "var(--cold-white)" }}>{o.label}</span>
              <span style={{ font: "400 11px/1.4 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{o.source} · CONF {o.confidence}</span>
            </div>
          ))}
          <div style={{ padding: "var(--space-5)", borderBottom: "1px solid var(--border-on-dark)", display: "flex", flexDirection: "column", gap: "8px" }}>
            <span style={{ font: "400 15px/1.35 var(--font-interface)", color: "var(--cold-white)" }}>Unit conversion in one filing is unverified.</span>
            <span style={{ font: "400 11px/1.4 var(--font-telemetry)", color: "var(--quiet-metal)" }}>EV-131 · A-19 · CONF 0.41</span>
            <StateBadge on="dark" state="gate" label="NEEDS A-22" />
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ padding: "var(--space-5)", borderTop: "1px solid var(--border-on-dark)", font: "400 11px/1.6 var(--font-telemetry)", color: "var(--quiet-metal-dim)" }}>
            Objections travel with the conclusion. Accepting does not close them.
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EvidenceScreen, SynthesisScreen });
