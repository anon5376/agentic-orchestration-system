const { ObjectiveAperture, Button, StateBadge, Telemetry, SectionLabel, ContextInspector, Aperture } = window.AOSDesignSystem_20e4c5;
const DM = window.AOSDATA;

function MissionsScreen({ sel, setSel, run, go, RouteHeader }) {
  const active = DM.missions[0];
  const rest = DM.missions.slice(1);
  const selected = DM.missions.find((m) => m.id === sel);
  return (
    <>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <RouteHeader
          label="Missions" index="01/08" title="Four objectives, one accelerating."
          telemetry={[{ label: "Active", value: "1" }, { label: "Agents", value: "87" }, { label: "Spend 24h", value: "$45.85", tone: "active" }, { label: "Generation", value: "07 → 08", tone: "transition" }]}
        />
        <div style={{ flex: 1, minHeight: 0, display: "flex" }}>
          <div onClick={() => go("SWARM")} style={{ flex: "1.25", background: "var(--cobalt)", padding: "var(--space-10) var(--gutter-page)", display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer", minWidth: 0 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-7)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "var(--space-4)" }}>
                <Aperture size={16} tone="white" state="running" />
                <span style={{ font: "400 11px/1 var(--font-telemetry)", letterSpacing: "0.1em", color: "var(--text-on-field-secondary)" }}>{active.id} · GEN {active.gen} · OPEN GATES {active.gates}</span>
              </div>
              <h2 style={{ margin: 0, font: "400 clamp(38px,4.4vw,64px)/0.94 var(--font-display)", letterSpacing: "var(--tracking-display)", color: "var(--cold-white)", maxWidth: "20ch", textWrap: "pretty" }}>{active.goal}</h2>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-6)" }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,max-content)", gap: "var(--space-11)" }}>
                {[["AGENTS", `${active.agents}`], ["TOKENS", active.tokens], ["COST", active.cost], ["VELOCITY", active.velocity]].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                    <span style={{ font: "400 10px/1 var(--font-telemetry)", letterSpacing: "0.12em", color: "var(--text-on-field-secondary)" }}>{k}</span>
                    <span style={{ font: "500 22px/1 var(--font-telemetry)", color: "var(--cold-white)", fontVariantNumeric: "tabular-nums" }}>{v}</span>
                  </div>
                ))}
              </div>
              <Button on="field" variant="primary" onClick={() => go("SWARM")}>Enter swarm</Button>
            </div>
          </div>
          <div style={{ flex: 1, minWidth: 0, borderLeft: "1px solid var(--border-on-dark-strong)", display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "14px var(--space-7)", borderBottom: "1px solid var(--border-on-dark)" }}>
              <SectionLabel on="dark" rule>Other missions</SectionLabel>
            </div>
            {rest.map((m) => (
              <button key={m.id} onClick={() => { setSel(m.id); run(`mission open ${m.id}`); }} style={{ textAlign: "left", background: sel === m.id ? "var(--void-plate)" : "transparent", border: "none", borderBottom: "1px solid var(--border-on-dark)", padding: "var(--space-6) var(--space-7)", display: "flex", flexDirection: "column", gap: "10px", cursor: "pointer" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-5)" }}>
                  <span style={{ font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{m.id} · GEN {m.gen}</span>
                  <StateBadge on="dark" state={m.state} />
                </div>
                <span style={{ font: "400 19px/1.15 var(--font-display)", color: "var(--cold-white)", textWrap: "pretty" }}>{m.goal}</span>
                <Telemetry on="dark" size="sm" items={[{ label: "Agents", value: String(m.agents) }, { label: "Tokens", value: m.tokens }, { label: "Cost", value: m.cost, tone: "active" }, { label: "Elapsed", value: m.elapsed }]} />
              </button>
            ))}
            <div style={{ flex: 1 }} />
            <div style={{ padding: "var(--space-6) var(--space-7)", borderTop: "1px solid var(--border-on-dark)", display: "flex", gap: "10px" }}>
              <Button on="dark" variant="primary" size="sm" onClick={() => go("INTAKE")}>New objective</Button>
              <Button on="dark" variant="ghost" size="sm" onClick={() => run("mission archive --state failed")}>Archive failed</Button>
            </div>
          </div>
        </div>
      </div>
      <ContextInspector
        open={!!selected} kind="MISSION" title={selected ? selected.goal : ""} subtitle={selected ? `${selected.id} · generation ${selected.gen}` : ""}
        sections={selected ? [
          { label: "Run", rows: [{ k: "State", v: selected.state.toUpperCase(), tone: selected.state === "failed" ? "consequence" : selected.state === "complete" ? "verified" : "neutral" }, { k: "Agents", v: String(selected.agents) }, { k: "Elapsed", v: selected.elapsed }] },
          { label: "Resource", rows: [{ k: "Tokens", v: selected.tokens }, { k: "Est. cost", v: selected.cost, tone: "active" }, { k: "Velocity", v: selected.velocity }] },
          { label: "Gates", rows: [{ k: "Open", v: String(selected.gates), tone: selected.gates ? "consequence" : "dim" }] }
        ] : []}
        onClose={() => setSel(null)}
        actions={<Button on="dark" variant="secondary" size="sm" full onClick={() => go("SWARM")}>Open swarm</Button>}
      />
    </>
  );
}

function IntakeScreen({ run, go, RouteHeader }) {
  const [goal, setGoal] = React.useState(DM.mission.goal);
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "auto" }}>
      <RouteHeader label="Goal intake" index="02/08" title="One objective, its boundaries, and what would count as done."
        telemetry={[{ label: "Documents", value: "3" }, { label: "Constraints", value: "4" }, { label: "Open ambiguity", value: "2", tone: "consequence" }]} />
      <ObjectiveAperture
        mission={DM.mission.id}
        goal={goal}
        onGoalChange={(e) => setGoal(e.target.value)}
        constraints={DM.mission.constraints}
        documents={DM.mission.documents}
        definitionOfDone={DM.mission.dod}
        ambiguities={DM.mission.ambiguities}
        on="field"
        actions={<>
          <Button on="field" variant="primary" onClick={() => { run(`mission create --goal "${goal.slice(0, 40)}…" --budget 2.5M`); go("SWARM"); }}>Decompose</Button>
          <Button on="field" variant="secondary" onClick={() => run("mission attach --file supplier-capacity-disclosures.csv")}>Attach context</Button>
          <Button on="field" variant="ghost" onClick={() => run("mission ask --ambiguity 1")}>Answer ambiguity</Button>
        </>}
      />
      <div style={{ display: "flex", justifyContent: "space-between", gap: "var(--space-7)", padding: "var(--space-7) var(--gutter-page)" }}>
        <p style={{ margin: 0, maxWidth: "58ch", font: "400 13px/1.5 var(--font-interface)", color: "var(--text-on-dark-secondary)" }}>
          The lead studies the goal and the attached context before assigning work. It may split a task, replace an approach, create a new specialist, or request a missing input as evidence changes — the plan is not frozen at creation.
        </p>
        <span style={{ font: "400 10px/1.6 var(--font-telemetry)", letterSpacing: "0.1em", color: "var(--quiet-metal-dim)", textAlign: "right", flex: "none" }}>
          AOS · AGENTIC ORCHESTRATION SYSTEM<br />ILLUSTRATIVE STATE · NOTHING EXECUTES<br />AI/ACC
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { MissionsScreen, IntakeScreen });
