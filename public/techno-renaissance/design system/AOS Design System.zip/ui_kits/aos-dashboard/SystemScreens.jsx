const { GenerationRift, ContextInspector, Button, StateBadge, SectionLabel, Telemetry } = window.AOSDesignSystem_20e4c5;
const DV = window.AOSDATA;

function EvolutionScreen({ run, RouteHeader }) {
  const g = DV.generation;
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <RouteHeader label="Evolution" index="06/08" title="Generation 08 is a candidate, not a fact."
        telemetry={[{ label: "Proposals", value: "4" }, { label: "Passed", value: "3", tone: "verified" }, { label: "Regressions", value: "1", tone: "consequence" }, { label: "Rollback", value: "RETAINED" }]} />
      <div style={{ flex: 1, minHeight: 0, display: "flex", overflow: "hidden" }}>
        <div style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "var(--space-7) var(--gutter-page)" }}>
          <GenerationRift baseline={g.baseline} candidate={g.candidate} changes={g.changes} regressions={g.regressions} rollback={g.rollback} adoption={g.adoption} />
          <div style={{ marginTop: "var(--space-7)", display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
            <SectionLabel on="dark" rule>Execution traces</SectionLabel>
            {g.traces.map((t) => (
              <button key={t.id} onClick={() => run(`generation trace ${t.id}`)} style={{ display: "flex", alignItems: "center", gap: "var(--space-5)", textAlign: "left", background: "transparent", border: "none", borderBottom: "1px solid var(--border-on-dark)", padding: "10px 0", cursor: "pointer" }}>
                <span style={{ width: "78px", flex: "none", font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{t.id}</span>
                <span style={{ flex: 1, font: "400 14px/1.3 var(--font-interface)", color: "var(--cold-white)" }}>{t.label}</span>
                <span style={{ font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{t.detail}</span>
                <StateBadge on="dark" state={t.result === "PASS" ? "verified" : "failed"} label={t.result} />
              </button>
            ))}
          </div>
        </div>
        <div style={{ width: "300px", flex: "none", borderLeft: "1px solid var(--border-on-dark-strong)", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "var(--space-5)", borderBottom: "1px solid var(--border-on-dark)" }}><SectionLabel on="dark" rule>Causal chain</SectionLabel></div>
          {[
            ["OBSERVED FAILURE", "MSN-2264 lost 1.02M tokens to duplicate scans."],
            ["CAUSAL HYPOTHESIS", "Verification sat below deduplication in the topology."],
            ["PROPOSED CHANGE", "Collapse duplicates before verification; move verification up."],
            ["HELD-OUT EVALUATION", "40 archived missions, no overlap with the proposal set."],
            ["COMPARISON", "+7.4% verified claims against GEN 07 baseline."],
            ["DECISION", "Awaiting owner approval at the gate below."]
          ].map(([k, v], i) => (
            <div key={k} style={{ padding: "var(--space-5)", borderBottom: "1px solid var(--border-on-dark)", borderLeft: `3px solid ${i === 5 ? "var(--vermilion)" : "var(--ultraviolet)"}`, display: "flex", flexDirection: "column", gap: "6px" }}>
              <span style={{ font: "500 10px/1 var(--font-telemetry)", letterSpacing: "0.1em", color: i === 5 ? "var(--vermilion)" : "var(--ultraviolet)" }}>{k}</span>
              <span style={{ font: "400 13px/1.45 var(--font-interface)", color: "var(--text-on-dark)" }}>{v}</span>
            </div>
          ))}
          <div style={{ flex: 1 }} />
          <div style={{ padding: "var(--space-5)", borderTop: "1px solid var(--border-on-dark)", font: "400 11px/1.6 var(--font-telemetry)", color: "var(--quiet-metal-dim)" }}>
            AOS does not approve its own high-risk changes.
          </div>
        </div>
      </div>
    </div>
  );
}

function CapabilitiesScreen({ sel, setSel, run, RouteHeader }) {
  const rows = DV.capabilities.flatMap((g) => g.rows.map((r) => ({ ...r, group: g.group })));
  const selected = rows.find((r) => r.name === sel);
  const head = ["RESOURCE", "AUTH", "MODELS", "CONTEXT", "RATE", "COST", "TOOLS", "IN USE", ""];
  return (
    <>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <RouteHeader label="Capabilities" index="07/08" title="Routing topology: harnesses, models, skills, servers, tools."
          telemetry={[{ label: "Harnesses", value: "4" }, { label: "Models", value: "7" }, { label: "MCP", value: "2" }, { label: "Generated", value: "1", tone: "consequence" }]} />
        <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 0.7fr 1.4fr 0.7fr 0.5fr 0.8fr 0.6fr 0.5fr auto", gap: 0, alignItems: "stretch" }}>
            {head.map((h, i) => (
              <div key={i} style={{ padding: "10px var(--space-5)", borderBottom: "1px solid var(--border-on-dark-strong)", font: "500 10px/1 var(--font-telemetry)", letterSpacing: "0.1em", color: "var(--quiet-metal)", background: "var(--void)", position: "sticky", top: 0 }}>{h}</div>
            ))}
            {DV.capabilities.map((g) => [
              <div key={g.group} style={{ gridColumn: "1 / -1", padding: "12px var(--space-5) 6px", font: "500 10px/1 var(--font-telemetry)", letterSpacing: "0.14em", color: "var(--ultraviolet)", borderBottom: "1px solid var(--border-on-dark)" }}>{g.group} · {g.rows.length}</div>,
              ...g.rows.map((r) => {
                const cells = [r.name, r.auth, r.models, r.context, r.rate, r.cost, r.tools, String(r.inUse)];
                return cells.map((c, ci) => (
                  <div key={r.name + ci} onClick={() => { setSel(r.name); run(`capability inspect "${r.name}"`); }}
                    style={{ padding: "11px var(--space-5)", borderBottom: "1px solid var(--border-on-dark)", cursor: "pointer", background: sel === r.name ? "var(--void-plate)" : "transparent",
                      font: ci === 0 ? "500 13px/1.2 var(--font-interface)" : "400 12px/1.2 var(--font-telemetry)",
                      color: ci === 0 ? "var(--cold-white)" : "var(--text-on-dark-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{c}</div>
                )).concat(
                  <div key={r.name + "s"} onClick={() => setSel(r.name)} style={{ padding: "11px var(--space-5)", borderBottom: "1px solid var(--border-on-dark)", background: sel === r.name ? "var(--void-plate)" : "transparent", cursor: "pointer" }}>
                    <StateBadge on="dark" state={r.state} form="bare" />
                  </div>
                );
              })
            ])}
          </div>
          <p style={{ margin: 0, padding: "var(--space-7) var(--gutter-page)", maxWidth: "var(--measure-body)", font: "400 13px/1.5 var(--font-interface)", color: "var(--text-on-dark-secondary)" }}>
            Providers expose their real differences: model availability, reasoning controls, context limits, rate limits, authentication mode, tool support, token accounting and cost. A generated tool is not trusted because an agent wrote it — it stays blocked until a bounded test passes.
          </p>
        </div>
      </div>
      <ContextInspector
        open={!!selected} kind="CAPABILITY" title={selected ? selected.name : ""} subtitle={selected ? `${selected.group} · ${selected.inUse} task(s)` : ""}
        sections={selected ? [
          { label: "Routing", rows: [{ k: "Auth", v: selected.auth }, { k: "Models", v: selected.models }, { k: "Context", v: selected.context }, { k: "Tool support", v: selected.tools }] },
          { label: "Pressure", rows: [{ k: "Rate limit", v: selected.rate, tone: selected.rate === "68%" ? "consequence" : "neutral" }, { k: "Cost", v: selected.cost, tone: "active" }, { k: "State", v: selected.state.toUpperCase(), tone: selected.state === "blocked" ? "consequence" : "neutral" }] },
          selected.note ? { label: "Note", body: selected.note } : { label: "Note", body: "No constraint recorded beyond the provider's published limits." }
        ] : []}
        onClose={() => setSel(null)}
        actions={<Button on="dark" variant="secondary" size="sm" full onClick={() => run(`capability test "${sel}"`)}>Run bounded test</Button>}
      />
    </>
  );
}

function MemoryScreen({ run, RouteHeader }) {
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <RouteHeader label="Memory" index="08/08" title="Three stores, explicit inheritance, visible boundaries."
        telemetry={[{ label: "Global", value: "412" }, { label: "Project", value: "1 286" }, { label: "Agent", value: "94" }, { label: "Expiring 24h", value: "37", tone: "transition" }]} />
      <div style={{ flex: 1, minHeight: 0, overflow: "auto", display: "flex", flexDirection: "column" }}>
        {DV.memory.map((m, i) => (
          <div key={m.scope} style={{ display: "flex", alignItems: "stretch", borderBottom: "1px solid var(--border-on-dark)", paddingLeft: `${i * 48}px` }}>
            <div style={{ flex: 1, display: "flex", alignItems: "center", gap: "var(--space-7)", padding: "var(--space-7) var(--gutter-page) var(--space-7) var(--space-7)", borderLeft: `3px solid ${i === 0 ? "var(--cobalt)" : i === 1 ? "var(--ultraviolet)" : "var(--quiet-metal)"}` }}>
              <div style={{ width: "160px", flex: "none", display: "flex", flexDirection: "column", gap: "6px" }}>
                <span style={{ font: "500 22px/1 var(--font-display)", letterSpacing: "0.04em", color: "var(--cold-white)" }}>{m.scope}</span>
                <span style={{ font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{m.items} ITEMS</span>
              </div>
              <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: "8px" }}>
                <span style={{ font: "400 14px/1.4 var(--font-interface)", color: "var(--text-on-dark)" }}>{m.note}</span>
                <Telemetry on="dark" size="sm" items={[{ label: "Retention", value: m.retention }, { label: "Inherits to", value: m.inherit }, { label: "Write policy", value: m.policy }]} />
              </div>
              <Button on="dark" variant="ghost" size="sm" onClick={() => run(`memory list --scope ${m.scope.toLowerCase()}`)}>Inspect</Button>
            </div>
          </div>
        ))}
        <div style={{ display: "flex", gap: "var(--space-10)", padding: "var(--space-8) var(--gutter-page)" }}>
          <p style={{ margin: 0, maxWidth: "52ch", font: "400 13px/1.5 var(--font-interface)", color: "var(--text-on-dark-secondary)" }}>
            Inheritance runs downward only: a global pattern reaches every mission, a project finding reaches that mission's agents, and an agent's working context reaches nothing. “Remember everything” is an option with consequences, not a hidden default.
          </p>
          <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
            <Button on="dark" variant="secondary" size="sm" onClick={() => run("memory export --scope project --format jsonl")}>Export project</Button>
            <Button on="dark" variant="consequence" size="sm" onClick={() => run("memory purge --scope agent --confirm")}>Purge agent memory</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EvolutionScreen, CapabilitiesScreen, MemoryScreen });
