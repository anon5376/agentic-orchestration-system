/* Deterministic illustrative state for the AOS UI kit. No live data, no random values. */
window.AOSDATA = (() => {
  const mission = {
    id: "MSN-2291",
    goal: "Can solid-state cell supply meet 2029 EU demand?",
    generation: "07",
    candidate: "08",
    started: "2026-09-14 09:52Z",
    agents: 41,
    active: 9,
    tokens: "1.84M",
    cost: "$21.40",
    elapsed: "01:12:44",
    evidence: 128,
    objections: 3,
    budget: "2.5M",
    dod: ["One ranked conclusion with cost bounds", "Every claim traced to a primary filing", "Objections attached, not resolved away"],
    constraints: ["2.5M token budget", "Primary filings only", "No paid data sources", "Stop any branch above $8"],
    documents: [
      { name: "eu-battery-directive-2026.pdf", size: "2.1 MB" },
      { name: "supplier-capacity-disclosures.csv", size: "340 KB" },
      { name: "prior-run-MSN-2104-retro.md", size: "18 KB" }
    ],
    ambiguities: [
      { q: "Does “supply” include imports from non-EU plants?", status: "ASKED" },
      { q: "Is 2029 calendar or fiscal?", status: "ASSUMED CALENDAR" }
    ]
  };

  const agents = [
    { id: "OBJ", role: "Objective", owner: "—", depth: 0, lane: 0.5, harness: "AOS", model: "control plane", state: "running", tokens: "—", cost: "$21.40", elapsed: "01:12:44", evidence: 128, deps: 0, workspace: "mission root", reasoning: "—", context: "—" },
    { id: "L-01", role: "Lead", owner: "OBJ", depth: 1, lane: 0.36, harness: "AOS", model: "claude-opus-4", state: "running", tokens: "180K", cost: "$9.10", elapsed: "01:12:02", evidence: 4, deps: 0, workspace: "ws/lead", reasoning: "HIGH", context: "62% of 200K", skills: ["decompose", "budget-guard"], mcp: ["filings-index"] },
    { id: "A-07", role: "Supply mapping", owner: "L-01", depth: 2, lane: 0.22, harness: "Codex", model: "gpt-5-codex", state: "running", tokens: "640K", cost: "$12.80", elapsed: "22:10", evidence: 38, deps: 1, workspace: "ws/a-07", reasoning: "MEDIUM", context: "41% of 400K", skills: ["table-extract"], mcp: ["filings-index", "eur-lex"] },
    { id: "A-22", role: "Filings audit", owner: "L-01", depth: 2, lane: 0.62, harness: "Claude Code", model: "claude-sonnet-4", state: "blocked", tokens: "94K", cost: "$1.10", elapsed: "03:41", evidence: 6, deps: 2, workspace: "ws/a-22", reasoning: "HIGH", context: "18% of 200K", skills: ["cite-check"], mcp: ["filings-index"], block: "Rate limit · anthropic · retry in 41s" },
    { id: "A-31", role: "Demand model", owner: "L-01", depth: 2, lane: 0.88, harness: "DeepSeek Harness", model: "deepseek-r1", state: "complete", tokens: "221K", cost: "$0.84", elapsed: "11:03", evidence: 14, deps: 0, workspace: "ws/a-31", reasoning: "HIGH", context: "34% of 128K", skills: ["forecast-audit"], mcp: [] },
    { id: "A-14", role: "Corpus triage", owner: "A-07", depth: 3, lane: 0.16, harness: "Claude Code", model: "claude-sonnet-4", state: "running", tokens: "412K", cost: "$4.90", elapsed: "07:22", evidence: 22, deps: 1, workspace: "ws/a-14", reasoning: "MEDIUM", context: "77% of 200K", skills: ["dedupe", "table-extract"], mcp: ["filings-index"] },
    { id: "A-19", role: "Capacity reconciler", owner: "A-07", depth: 3, lane: 0.44, harness: "Codex", model: "gpt-5 → opus-4", state: "handoff", tokens: "308K", cost: "$6.20", elapsed: "04:58", evidence: 9, deps: 2, workspace: "ws/a-19", reasoning: "HIGH", context: "handoff at 182K", skills: ["unit-normalise"], mcp: ["filings-index"], note: "Context exceeded gpt-5 window; lead moved the task to opus-4 mid-run." },
    { id: "V-03", role: "Claim verifier", owner: "L-01", depth: 4, lane: 0.3, harness: "Ollama (local)", model: "qwen3-8b", state: "running", tokens: "96K", cost: "$0.00", elapsed: "02:14", evidence: 31, deps: 1, workspace: "ws/v-03", reasoning: "LOW", context: "22% of 32K", skills: ["verify-claim"], mcp: [], note: "Local model earned this role in GEN 06 on cost/quality trade-off." },
    { id: "CORE", role: "Convergence", owner: "L-01", depth: 5, lane: 0.5, harness: "AOS", model: "synthesis", state: "waiting", tokens: "—", cost: "—", elapsed: "—", evidence: 128, deps: 4, workspace: "mission root", reasoning: "—", context: "—" }
  ];

  const clusters = [
    { id: "CL-1", kind: "cluster", depth: 3, lane: 0.72, label: "Source scanners", count: 34, owner: "A-07", tokens: "2.1M", cost: "$18.60", distribution: { complete: 25, running: 6, waiting: 2, failed: 1 } },
    { id: "CL-2", kind: "cluster", depth: 4, lane: 0.74, label: "Unit normalisers", count: 12, owner: "A-19", tokens: "480K", cost: "$3.20", distribution: { complete: 9, running: 2, failed: 1 } }
  ];

  const edges = [
    { from: "OBJ", to: "L-01", throughput: 0.9 },
    { from: "L-01", to: "A-07", throughput: 0.7 },
    { from: "L-01", to: "A-22", state: "waiting" },
    { from: "L-01", to: "A-31", state: "verified", throughput: 0.3 },
    { from: "A-07", to: "A-14", throughput: 0.8 },
    { from: "A-07", to: "A-19", state: "handoff", throughput: 0.5 },
    { from: "A-07", to: "CL-1", state: "dormant" },
    { from: "A-19", to: "CL-2", state: "dormant" },
    { from: "A-22", to: "A-19", kind: "dependency", state: "conflict", label: "BLOCKS" },
    { from: "A-14", to: "V-03", throughput: 0.6 },
    { from: "V-03", to: "CORE", state: "verified", throughput: 0.4 },
    { from: "A-31", to: "CORE", state: "stable", throughput: 0.2 }
  ];

  const activePath = ["OBJ", "L-01", "A-07", "A-14", "V-03", "CORE"];

  const evidence = [
    { id: "EV-118", claim: "Two of three named suppliers disclose 2029 capacity below the modelled EU requirement.", source: "Supplier 10-K filings (3)", provenance: "PRIMARY · RETRIEVED", freshness: "4h", confidence: "0.81", producedBy: "A-14", consumers: ["A-19", "CORE"], contradiction: false },
    { id: "EV-121", claim: "Announced gigafactory ramp schedules slip by a median of 14 months against first public guidance.", source: "Company announcements, 2019–2026", provenance: "PRIMARY · COMPUTED", freshness: "11h", confidence: "0.74", producedBy: "A-07", consumers: ["A-31"], contradiction: false },
    { id: "EV-126", claim: "EU demand projection assumes a 38% solid-state share by 2029.", source: "eu-battery-directive-2026.pdf, p.44", provenance: "USER DOCUMENT", freshness: "SUPPLIED", confidence: "0.66", producedBy: "A-31", consumers: ["CORE"], contradiction: true },
    { id: "EV-131", claim: "One supplier's disclosed capacity is stated in cell count, not GWh; conversion is unverified.", source: "Supplier filing (1)", provenance: "PRIMARY · UNRESOLVED", freshness: "2h", confidence: "0.41", producedBy: "A-19", consumers: ["A-22"], contradiction: true },
    { id: "EV-134", claim: "Import capacity from non-EU plants is excluded by the current mission boundary.", source: "Mission constraint · operator", provenance: "DECISION RECORD", freshness: "1h", confidence: "1.00", producedBy: "L-01", consumers: ["A-07", "A-31"], contradiction: false },
    { id: "EV-137", claim: "31 of 34 scanner findings duplicate three underlying filings.", source: "Scanner cluster CL-1", provenance: "DERIVED · AGGREGATE", freshness: "22m", confidence: "0.88", producedBy: "V-03", consumers: ["L-01"], contradiction: false }
  ];

  const branches = [
    { label: "Supply falls short on disclosed capacity", source: "A-14 · 22 evidence", confidence: "0.81", weight: 0.95, state: "verified" },
    { label: "Shortfall closes if announced ramps hold", source: "A-07 · 38 evidence", confidence: "0.52", weight: 0.7 },
    { label: "Demand baseline itself is contested", source: "A-31 · 14 evidence", confidence: "0.44", weight: 0.6, state: "conflict" },
    { label: "Unit conversion error could invert the result", source: "A-19 · 9 evidence", confidence: "0.41", weight: 0.5, state: "conflict" },
    { label: "Scanner findings add no independent signal", source: "V-03 · 31 evidence", confidence: "0.88", weight: 0.4, dormant: true },
    { label: "Imports excluded by operator decision", source: "L-01 · 1 decision", confidence: "1.00", weight: 0.55 }
  ];

  const missions = [
    { id: "MSN-2291", goal: "Can solid-state cell supply meet 2029 EU demand?", state: "running", agents: 41, gen: "07 → 08", tokens: "1.84M", cost: "$21.40", elapsed: "01:12:44", velocity: "3.1 findings/min", gates: 1 },
    { id: "MSN-2287", goal: "Which of our failed runs share a single coordination cause?", state: "complete", agents: 18, gen: "07", tokens: "760K", cost: "$8.05", elapsed: "00:41:19", velocity: "1.4 findings/min", gates: 0 },
    { id: "MSN-2281", goal: "Build a verified cost model for local-model substitution.", state: "waiting", agents: 6, gen: "06", tokens: "210K", cost: "$1.60", elapsed: "00:09:02", velocity: "0.4 findings/min", gates: 1 },
    { id: "MSN-2264", goal: "Reconstruct the provenance chain for the 2025 policy brief.", state: "failed", agents: 22, gen: "06", tokens: "1.02M", cost: "$14.80", elapsed: "00:58:41", velocity: "—", gates: 0 }
  ];

  const generation = {
    baseline: { label: "GEN 07", metrics: [
      { label: "Verified claims", value: "71%" },
      { label: "Wasted tokens", value: "18%" },
      { label: "Median mission cost", value: "$26.10" },
      { label: "Long-context routing", value: "0.67" },
      { label: "Human gates per run", value: "2.4" }
    ] },
    candidate: { label: "GEN 08 · CANDIDATE", metrics: [
      { label: "Verified claims", value: "78%", delta: "+7.4" },
      { label: "Wasted tokens", value: "6%", delta: "−12" },
      { label: "Median mission cost", value: "$19.40", delta: "−$6.70" },
      { label: "Long-context routing", value: "0.62", delta: "−0.05", regression: true },
      { label: "Human gates per run", value: "1.7", delta: "−0.7" }
    ] },
    changes: [
      { kind: "RULE", text: "The lead must request a missing input before delegating." },
      { kind: "RULE", text: "Duplicate scanner findings collapse before verification." },
      { kind: "TOPOLOGY", text: "Verification moved one level up, under the lead." },
      { kind: "ROUTING", text: "Local qwen3-8b takes first-pass claim verification." }
    ],
    regressions: ["Long-context routing on corpora above 200K tokens"],
    rollback: "gen-07 · 4a91c2",
    adoption: "AWAITING APPROVAL",
    traces: [
      { id: "TR-08-1", label: "Held-out eval · 40 archived missions", result: "PASS", detail: "+7.4% verified claims" },
      { id: "TR-08-2", label: "Cost regression suite", result: "PASS", detail: "−12% wasted tokens" },
      { id: "TR-08-3", label: "Long-context routing suite", result: "FAIL", detail: "−0.05 on >200K corpora" },
      { id: "TR-08-4", label: "Safety: self-modification bounds", result: "PASS", detail: "No rule touched approval gates" }
    ]
  };

  const capabilities = [
    { group: "HARNESS", rows: [
      { name: "Claude Code", auth: "OAUTH", models: "sonnet-4, opus-4", context: "200K", rate: "68%", cost: "$/1M 3.00", tools: "FULL", state: "running", inUse: 3 },
      { name: "Codex", auth: "API KEY", models: "gpt-5, gpt-5-codex", context: "400K", rate: "22%", cost: "$/1M 2.50", tools: "FULL", state: "running", inUse: 2 },
      { name: "DeepSeek Harness", auth: "API KEY", models: "deepseek-r1", context: "128K", rate: "4%", cost: "$/1M 0.55", tools: "PARTIAL", state: "complete", inUse: 1 },
      { name: "Ollama (local)", auth: "LOCAL", models: "qwen3-8b, llama3.1-8b", context: "32K", rate: "—", cost: "COMPUTE", tools: "NONE", state: "running", inUse: 1 }
    ] },
    { group: "SKILL", rows: [
      { name: "table-extract", auth: "—", models: "any", context: "—", rate: "—", cost: "—", tools: "—", state: "running", inUse: 2 },
      { name: "cite-check", auth: "—", models: "any", context: "—", rate: "—", cost: "—", tools: "—", state: "waiting", inUse: 1 },
      { name: "verify-claim", auth: "—", models: "local preferred", context: "—", rate: "—", cost: "—", tools: "—", state: "running", inUse: 1 }
    ] },
    { group: "MCP", rows: [
      { name: "filings-index", auth: "OAUTH", models: "—", context: "—", rate: "31%", cost: "—", tools: "READ", state: "running", inUse: 4 },
      { name: "eur-lex", auth: "PUBLIC", models: "—", context: "—", rate: "8%", cost: "—", tools: "READ", state: "running", inUse: 1 }
    ] },
    { group: "GENERATED TOOL", rows: [
      { name: "gwh-converter", auth: "SANDBOX", models: "—", context: "—", rate: "—", cost: "—", tools: "EXEC", state: "blocked", inUse: 0, note: "Written by A-19. Bounded test required before any worker may depend on it." }
    ] }
  ];

  const memory = [
    { scope: "GLOBAL", items: 412, retention: "PERSISTENT", inherit: "ALL MISSIONS", policy: "OPERATOR APPROVAL TO WRITE", state: "running", note: "Validated coordination patterns and policies." },
    { scope: "PROJECT", items: 1286, retention: "MISSION + 90d", inherit: "MISSION AGENTS", policy: "LEAD MAY WRITE", state: "running", note: "Documents, findings, decisions, and this run's history." },
    { scope: "AGENT", items: 94, retention: "TASK", inherit: "NONE", policy: "ISOLATED WORKSPACE", state: "waiting", note: "Working context for one role; discarded at task close." }
  ];

  const cli = [
    { kind: "command", text: "mission open MSN-2291" },
    { kind: "output", text: "goal: Can solid-state cell supply meet 2029 EU demand?  gen 07  budget 2.5M" },
    { kind: "command", text: "swarm dispatch --lead L-01 --parallel 3" },
    { kind: "output", text: "9 specialists created · 34 scanners aggregated as CL-1 · 12 normalisers as CL-2" },
    { kind: "handoff", text: "A-19 handoff gpt-5 → claude-opus-4 (context 182K of 400K, reasoning HIGH)" },
    { kind: "ok", text: "evidence EV-118 verified by V-03 (local qwen3-8b) against 3 primary filings" },
    { kind: "error", text: "A-22 blocked: rate limit anthropic · retry 41s · 2 dependents waiting" },
    { kind: "meta", text: "tokens 1.84M / 2.5M · cost $21.40 · elapsed 01:12:44 · 1 gate open" }
  ];

  const palette = [
    { cat: "MISSION", cmd: "mission open <id>", hint: "Switch the active mission" },
    { cat: "SWARM", cmd: "swarm inspect --agent A-14", hint: "Open an agent in the inspector" },
    { cat: "SWARM", cmd: "swarm stop --branch A-22", hint: "Stop a low-value or blocked branch" },
    { cat: "EVIDENCE", cmd: "evidence trace EV-131", hint: "Show provenance and consumers" },
    { cat: "SYNTHESIS", cmd: "synthesis open --core", hint: "Expand the convergence core" },
    { cat: "EVOLUTION", cmd: "generation diff 07 08", hint: "Compare baseline and candidate" },
    { cat: "AI/ACC", cmd: "velocity report --window 24h", hint: "Generation velocity and throughput" }
  ];

  return { mission, agents, clusters, edges, activePath, evidence, branches, missions, generation, capabilities, memory, cli, palette };
})();
