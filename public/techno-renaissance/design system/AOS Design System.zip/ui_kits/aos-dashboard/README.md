# AOS dashboard — UI kit

Desktop surface, designed at **1440×900**. Open `index.html`.

All eight routes are click-through from the global rail:

| Route | What it shows |
|---|---|
| `MISSIONS` | Four objectives; the active one is a committed cobalt field with generation velocity |
| `INTAKE` | `ObjectiveAperture` on a cobalt field: goal, constraints, context, definition of done, open ambiguity |
| `SWARM` | The `AccelerationField`: hierarchy, active causal path, aggregated clusters, inspector, decision gate |
| `EVIDENCE` | Provenance facets, producer counts, `EvidencePlate` grid, provenance/dissent inspector |
| `SYNTHESIS` | `ConvergenceCore` expanded into its branches, proposed conclusion, unresolved objections |
| `EVOLUTION` | `GenerationRift`, execution traces, the causal chain from failure to decision |
| `CAPABILITIES` | Routing topology for harnesses, models, skills, MCP servers and generated tools |
| `MEMORY` | Global / project / agent stores with retention, inheritance and write policy |

Interactions: click an agent or cluster to open the inspector · `⌘K` command
palette · `⌃\`` toggles the CLI sheet (also click the bar) · the decision gate
resolves on choice and logs the command into the CLI.

## Files

- `index.html` — mount; loads `styles.css`, the compiled bundle, then the screens
- `Shell.jsx` — app state, `GlobalRail`, route switch, `RouteHeader`, gate wiring, `CLISheet`, command palette
- `SwarmScreen.jsx` — the first surface, plus inspector content for agents and clusters
- `MissionScreens.jsx` — `MISSIONS`, `INTAKE`
- `ResearchScreens.jsx` — `EVIDENCE`, `SYNTHESIS`
- `SystemScreens.jsx` — `EVOLUTION`, `CAPABILITIES`, `MEMORY`
- `data.js` — deterministic illustrative state for mission MSN-2291 (`window.AOSDATA`)

Screens compose the design-system components from `window.AOSDesignSystem_20e4c5`; no
primitive is reimplemented here. State is fiction, the rail says
`ILLUSTRATIVE`, and the CLI says `SIMULATED`.
