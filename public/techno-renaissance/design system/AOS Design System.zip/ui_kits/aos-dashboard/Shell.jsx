const { GlobalRail, CLISheet, ContextInspector, DecisionGate, Button, SectionLabel, Telemetry, StateBadge, Aperture } = window.AOSDesignSystem_20e4c5;
const D = window.AOSDATA;

function CommandPalette({ open, onClose, onRun }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 20, background: "rgba(5,5,9,0.72)", display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: "120px" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "620px", background: "var(--void-raise)", border: "1px solid var(--border-on-dark-strong)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "0 14px", height: "44px", borderBottom: "1px solid var(--border-on-dark)" }}>
          <Aperture size={14} tone="cobalt" state="converging" />
          <input autoFocus placeholder="command or goal…" style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "var(--cold-white)", font: "400 14px/1 var(--font-telemetry)" }} />
          <span style={{ font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)" }}>ESC</span>
        </div>
        {D.palette.map((p) => (
          <button key={p.cmd} onClick={() => { onRun(p.cmd); onClose(); }} style={{ display: "flex", alignItems: "baseline", gap: "14px", width: "100%", textAlign: "left", padding: "9px 14px", background: "transparent", border: "none", borderBottom: "1px solid var(--border-on-dark)", cursor: "pointer" }}>
            <span style={{ width: "84px", flex: "none", font: "500 10px/1.4 var(--font-telemetry)", letterSpacing: "0.08em", color: p.cat === "AI/ACC" ? "var(--ultraviolet)" : "var(--quiet-metal-dim)" }}>{p.cat}</span>
            <span style={{ flex: 1, font: "400 13px/1.4 var(--font-telemetry)", color: "var(--cold-white)" }}>{p.cmd}</span>
            <span style={{ font: "400 11px/1.4 var(--font-interface)", color: "var(--quiet-metal)" }}>{p.hint}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* One header strip shared by every route: objective, then aggregate telemetry. */
function RouteHeader({ label, index, title, telemetry, right, children }) {
  return (
    <div style={{ flex: "none", borderBottom: "1px solid var(--border-on-dark)", padding: "14px var(--gutter-page)", display: "flex", flexDirection: "column", gap: "10px", background: "var(--void)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--space-7)" }}>
        <SectionLabel on="dark" index={index}>{label}</SectionLabel>
        <span style={{ flex: 1 }} />
        {right}
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "var(--space-10)" }}>
        <h1 style={{ margin: 0, font: "400 30px/1.08 var(--font-display)", letterSpacing: "var(--tracking-title)", color: "var(--cold-white)", maxWidth: "44ch", textWrap: "pretty" }}>{title}</h1>
        {telemetry ? <Telemetry on="dark" items={telemetry} style={{ flex: "none" }} /> : null}
      </div>
      {children}
    </div>
  );
}

function App() {
  const [route, setRoute] = React.useState("SWARM");
  const [sel, setSel] = React.useState(null);
  const [cliOpen, setCliOpen] = React.useState(false);
  const [paletteOpen, setPaletteOpen] = React.useState(false);
  const [lines, setLines] = React.useState(D.cli);
  const [gateOpen, setGateOpen] = React.useState(true);
  const [prompt, setPrompt] = React.useState("");
  const [coreOpen, setCoreOpen] = React.useState(true);
  const [expanded, setExpanded] = React.useState([]);

  React.useEffect(() => {
    const h = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPaletteOpen((v) => !v); }
      if (e.key === "Escape") setPaletteOpen(false);
      if (e.ctrlKey && e.key === "`") { e.preventDefault(); setCliOpen((v) => !v); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const run = (cmd) => { setLines((l) => [...l, { kind: "command", text: cmd }, { kind: "meta", text: "illustrative state · command not executed" }]); setCliOpen(true); };
  const go = (r) => { setRoute(r); setSel(null); };

  const shared = { sel, setSel, run, go, coreOpen, setCoreOpen, expanded, setExpanded, gateOpen, setGateOpen, RouteHeader };
  const screen =
    route === "SWARM" ? <window.SwarmScreen {...shared} /> :
    route === "MISSIONS" ? <window.MissionsScreen {...shared} /> :
    route === "INTAKE" ? <window.IntakeScreen {...shared} /> :
    route === "EVIDENCE" ? <window.EvidenceScreen {...shared} /> :
    route === "SYNTHESIS" ? <window.SynthesisScreen {...shared} /> :
    route === "EVOLUTION" ? <window.EvolutionScreen {...shared} /> :
    route === "CAPABILITIES" ? <window.CapabilitiesScreen {...shared} /> :
    <window.MemoryScreen {...shared} />;

  const gate =
    route === "SWARM" && gateOpen ? {
      prompt: "A-22 is blocked by a provider rate limit and two dependents are waiting.",
      detail: "Filings audit holds the unit-conversion check that could invert EV-118. Waiting costs 41 seconds; rerouting costs an estimated $2.10 and loses the cite-check skill.",
      authority: "OPERATOR",
      choices: [
        { label: "Wait 41s", consequence: "Dependents stay queued", reversible: true, variant: "secondary" },
        { label: "Reroute to Codex", consequence: "Loses cite-check skill", reversible: true, variant: "primary" },
        { label: "Stop branch", consequence: "Drops 6 evidence items", reversible: false, variant: "consequence" }
      ]
    } : route === "EVOLUTION" && gateOpen ? {
      prompt: "Promote GEN 08 to the default coordination policy?",
      detail: "Held-out evaluation across 40 archived missions: +7.4% verified claims, −12% wasted tokens, one new regression in long-context routing. Rollback point gen-07 · 4a91c2 is retained either way.",
      authority: "OWNER",
      choices: [
        { label: "Promote", consequence: "New runs use GEN 08", reversible: true, variant: "primary" },
        { label: "Reject", consequence: "Candidate archived with traces", reversible: true, variant: "secondary" },
        { label: "Promote + auto-adopt", consequence: "Future safe changes self-promote", reversible: false, variant: "consequence" }
      ]
    } : null;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--void)", overflow: "hidden" }}>
      <GlobalRail route={route} mission={`${D.mission.id} · GEN ${D.mission.generation}`} mode="ILLUSTRATIVE" connection={{ state: "degraded", label: "4 PROVIDERS · 1 LIMITED" }} onRoute={go} onCommand={() => setPaletteOpen(true)} />
      <main style={{ flex: 1, minHeight: 0, display: "flex", overflow: "hidden" }}>{screen}</main>
      {gate ? <DecisionGate open {...gate} onChoose={(c) => { setGateOpen(false); run(`gate resolve --choice "${c.label}"`); }} /> : null}
      <CLISheet expanded={cliOpen} lines={lines} context={`mission/${D.mission.id}${sel ? ` · ${sel}` : ""}`} simulated prompt={prompt} onPromptChange={setPrompt} onSubmit={(v) => { if (v.trim()) run(v.trim()); setPrompt(""); }} onToggle={() => setCliOpen((v) => !v)} />
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onRun={run} />
    </div>
  );
}

Object.assign(window, { App, CommandPalette, RouteHeader });
