const { AccelerationField, ContextInspector, Button, StateBadge, Telemetry, SectionLabel } = window.AOSDesignSystem_20e4c5;
const DS = window.AOSDATA;

function agentInspector(a, run) {
  const sections = [
    { label: "Ownership", rows: [
      { k: "Owner", v: a.owner },
      { k: "Depth", v: String(a.depth) },
      { k: "Workspace", v: a.workspace }
    ] },
    { label: "Runtime", rows: [
      { k: "Harness", v: a.harness },
      { k: "Model", v: a.model, tone: a.state === "handoff" ? "transition" : "neutral" },
      { k: "Reasoning", v: a.reasoning },
      { k: "Context", v: a.context }
    ] },
    { label: "Resource", rows: [
      { k: "Tokens", v: a.tokens },
      { k: "Est. cost", v: a.cost, tone: "active" },
      { k: "Elapsed", v: a.elapsed }
    ] },
    { label: "Work", rows: [
      { k: "Evidence", v: String(a.evidence), tone: "verified" },
      { k: "Dependencies", v: String(a.deps), tone: a.deps ? "neutral" : "dim" },
      { k: "Skills", v: (a.skills || []).join(", ") || "—" },
      { k: "MCP", v: (a.mcp || []).join(", ") || "—" }
    ] }
  ];
  if (a.block) sections.push({ label: "Intervention", rows: [{ k: "Blocked by", v: a.block, tone: "consequence" }], body: "Two dependents are waiting. Resolve at the decision gate below." });
  if (a.note) sections.push({ label: "Note", body: a.note });
  return sections;
}

function clusterInspector(c) {
  const total = Object.values(c.distribution).reduce((x, y) => x + y, 0);
  return [
    { label: "Aggregate", rows: [
      { k: "Workers", v: String(c.count) },
      { k: "Owner", v: c.owner },
      { k: "Tokens", v: c.tokens },
      { k: "Est. cost", v: c.cost, tone: "active" }
    ] },
    { label: "Distribution", rows: Object.keys(c.distribution).map((k) => ({ k, v: `${c.distribution[k]} / ${total}`, tone: k === "failed" ? "consequence" : k === "complete" ? "verified" : "neutral" })) },
    { label: "Why aggregated", body: "34 siblings run the same low-value scan. AOS draws the active path and bundles repetition; expanding enters the cluster as a new scale without losing lineage." }
  ];
}

function SwarmScreen({ sel, setSel, run, RouteHeader }) {
  const items = [...DS.agents.map((a) => ({ ...a, compact: true })), ...DS.clusters];
  const selected = items.find((i) => i.id === sel);
  return (
    <>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <RouteHeader
          label="Swarm" index="03/08"
          title={DS.mission.goal}
          telemetry={[
            { label: "Agents", value: `${DS.mission.active}/${DS.mission.agents}` },
            { label: "Tokens", value: DS.mission.tokens },
            { label: "Cost", value: DS.mission.cost, tone: "active" },
            { label: "Elapsed", value: DS.mission.elapsed },
            { label: "Evidence", value: String(DS.mission.evidence), tone: "verified" }
          ]}
          right={<div style={{ display: "flex", gap: "10px" }}>
            <StateBadge on="dark" state="running" label="RUNNING 9" />
            <StateBadge on="dark" state="waiting" label="WAITING 2" />
            <StateBadge on="dark" state="blocked" label="BLOCKED 1" />
            <StateBadge on="dark" state="complete" label="COMPLETE 26" />
            <StateBadge on="dark" state="failed" label="FAILED 1" />
          </div>}
        />
        <div style={{ flex: 1, minHeight: 0 }}>
          <AccelerationField
            items={items}
            edges={DS.edges}
            activePath={DS.activePath}
            selectedId={sel}
            onSelect={(id) => { setSel(id); run(`swarm inspect --agent ${id}`); }}
            height="100%"
            caption="46 OF 41 OWNED TASKS AGGREGATED INTO 2 CLUSTERS"
          />
        </div>
      </div>
      <ContextInspector
        open={!!selected}
        kind={selected && selected.kind === "cluster" ? "CLUSTER" : "AGENT"}
        title={selected ? (selected.role || selected.label) : ""}
        subtitle={selected ? `${selected.id} · ${selected.kind === "cluster" ? `${selected.count} workers` : `${selected.harness} / ${selected.model}`}` : ""}
        sections={selected ? (selected.kind === "cluster" ? clusterInspector(selected) : agentInspector(selected, run)) : []}
        onClose={() => setSel(null)}
        actions={selected && selected.kind === "cluster"
          ? <><Button on="dark" variant="primary" size="sm" full onClick={() => run(`swarm enter --cluster ${selected.id}`)}>Enter cluster</Button><Button on="dark" variant="secondary" size="sm" full onClick={() => run(`swarm summarise --cluster ${selected.id}`)}>Summarise</Button></>
          : <><Button on="dark" variant="secondary" size="sm" full onClick={() => run(`swarm trace --agent ${sel}`)}>Open trace</Button><Button on="dark" variant="consequence" size="sm" full onClick={() => run(`swarm stop --branch ${sel}`)}>Stop branch</Button></>}
      />
    </>
  );
}

Object.assign(window, { SwarmScreen });
