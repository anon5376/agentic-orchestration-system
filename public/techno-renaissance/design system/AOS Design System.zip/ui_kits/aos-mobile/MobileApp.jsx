const { Aperture, Button, StateBadge, Telemetry, SectionLabel, ContextInspector, CLISheet, DecisionGate, ClusterAggregate } = window.AOSDesignSystem_20e4c5;
const DMob = window.AOSDATA;

const STAGES = [
  { key: "FRONTIER", label: "Frontier", note: "Unresolved", ids: [] },
  { key: "CONVERGENCE", label: "Convergence", note: "6 branches compressing", ids: ["CORE"] },
  { key: "MUTATION", label: "Mutation", note: "GEN 08 candidate", ids: ["V-03", "CL-2"] },
  { key: "SWARM", label: "Swarm", note: "9 active of 41", ids: ["L-01", "A-07", "A-22", "A-31", "A-14", "A-19", "CL-1"] },
  { key: "CONSTRAINT", label: "Constraint", note: "2.5M tokens · primary sources only", ids: ["OBJ"] }
];

function Rail({ route, onMenu }) {
  return (
    <header style={{ flex: "none", height: "48px", display: "flex", alignItems: "center", gap: "10px", padding: "0 14px", background: "var(--void)", borderBottom: "1px solid var(--border-on-dark)" }}>
      <Aperture size={15} tone="white" state="running" />
      <span style={{ font: "600 17px/1 var(--font-display)", letterSpacing: "0.08em", color: "var(--cold-white)" }}>AOS</span>
      <span style={{ font: "500 10px/1 var(--font-interface)", letterSpacing: "0.14em", color: "var(--quiet-metal)" }}>{route}</span>
      <span style={{ flex: 1 }} />
      <span style={{ font: "400 10px/1 var(--font-telemetry)", padding: "3px 5px", border: "1px solid var(--quiet-metal)", color: "var(--quiet-metal)" }}>ILLUSTRATIVE</span>
      <button onClick={onMenu} style={{ background: "transparent", border: "1px solid var(--border-on-dark-strong)", color: "var(--cold-white)", height: "26px", padding: "0 8px", font: "400 11px/1 var(--font-telemetry)", cursor: "pointer" }}>CMD</button>
    </header>
  );
}

function AgentRow({ a, onSelect }) {
  const cluster = a.kind === "cluster";
  return (
    <button onClick={() => onSelect(a.id)} style={{ display: "flex", flexDirection: "column", gap: "7px", width: "100%", textAlign: "left", padding: "11px 14px 11px", paddingLeft: `${14 + (a.depth || 0) * 10}px`, background: "transparent", border: "none", borderBottom: "1px solid var(--border-on-dark)", borderLeft: `3px solid ${cluster ? "var(--quiet-metal-dim)" : a.state === "running" ? "var(--cobalt)" : a.state === "complete" ? "var(--ion)" : a.state === "blocked" ? "var(--vermilion)" : a.state === "handoff" ? "var(--ultraviolet)" : "var(--quiet-metal-dim)"}`, cursor: "pointer" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "10px", width: "100%" }}>
        <span style={{ font: "500 13px/1.1 var(--font-interface)", letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--cold-white)" }}>
          {cluster ? `${a.label} ×${a.count}` : a.role}
        </span>
        <span style={{ font: "400 10px/1 var(--font-telemetry)", color: "var(--quiet-metal-dim)", flex: "none" }}>{a.id}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px", width: "100%" }}>
        <span style={{ font: "400 10px/1.3 var(--font-telemetry)", color: "var(--text-on-dark-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {cluster ? `← ${a.owner} · aggregated` : `${a.harness} / ${a.model}`}
        </span>
        <span style={{ font: "500 10px/1 var(--font-telemetry)", color: "var(--text-on-dark-secondary)", flex: "none", fontVariantNumeric: "tabular-nums" }}>
          {a.tokens} · {a.cost || "—"}
        </span>
      </div>
      {!cluster ? <StateBadge on="dark" state={a.state} form="bare" /> : null}
    </button>
  );
}

function MobileApp() {
  const [open, setOpen] = React.useState(["SWARM", "CONVERGENCE"]);
  const [sel, setSel] = React.useState(null);
  const [cliOpen, setCliOpen] = React.useState(false);
  const [gateOpen, setGateOpen] = React.useState(true);
  const items = [...DMob.agents, ...DMob.clusters];
  const selected = items.find((i) => i.id === sel);
  const toggle = (k) => setOpen((o) => (o.includes(k) ? o.filter((x) => x !== k) : [...o, k]));

  return (
    <div style={{ position: "relative", display: "flex", flexDirection: "column", height: "100%", background: "var(--void)", overflow: "hidden" }}>
      <Rail route="SWARM" onMenu={() => setCliOpen(true)} />
      <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
        <div style={{ background: "var(--cobalt)", padding: "18px 14px 16px", display: "flex", flexDirection: "column", gap: "14px" }}>
          <span style={{ font: "400 10px/1 var(--font-telemetry)", letterSpacing: "0.1em", color: "var(--text-on-field-secondary)" }}>{DMob.mission.id} · GEN {DMob.mission.generation} · 1 GATE OPEN</span>
          <h1 style={{ margin: 0, font: "400 30px/0.98 var(--font-display)", letterSpacing: "var(--tracking-display)", color: "var(--cold-white)", textWrap: "pretty" }}>{DMob.mission.goal}</h1>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: "10px 18px" }}>
            {[["AGENTS", "9/41"], ["TOKENS", DMob.mission.tokens], ["COST", DMob.mission.cost], ["ELAPSED", DMob.mission.elapsed]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", flexDirection: "column", gap: "3px" }}>
                <span style={{ font: "400 9px/1 var(--font-telemetry)", letterSpacing: "0.12em", color: "var(--text-on-field-secondary)" }}>{k}</span>
                <span style={{ font: "500 16px/1 var(--font-telemetry)", color: "var(--cold-white)", fontVariantNumeric: "tabular-nums" }}>{v}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ padding: "14px 14px 8px" }}>
          <SectionLabel on="dark" rule>Stages</SectionLabel>
        </div>
        {STAGES.map((s, i) => {
          const isOpen = open.includes(s.key);
          const rows = s.ids.map((id) => items.find((x) => x.id === id)).filter(Boolean);
          return (
            <section key={s.key}>
              <button onClick={() => toggle(s.key)} style={{ display: "flex", alignItems: "center", gap: "12px", width: "100%", textAlign: "left", padding: "13px 14px", background: "transparent", border: "none", borderTop: "1px solid var(--border-on-dark)", cursor: "pointer" }}>
                <span style={{ font: "400 10px/1 var(--font-telemetry)", color: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)", width: "18px", flex: "none" }}>{String(STAGES.length - i).padStart(2, "0")}</span>
                <span style={{ flex: 1, display: "flex", flexDirection: "column", gap: "4px" }}>
                  <span style={{ font: "500 15px/1 var(--font-display)", letterSpacing: "0.08em", textTransform: "uppercase", color: i === 0 ? "var(--ultraviolet)" : "var(--cold-white)" }}>{s.label}</span>
                  <span style={{ font: "400 11px/1.3 var(--font-telemetry)", color: "var(--quiet-metal)" }}>{s.note}</span>
                </span>
                <span style={{ font: "400 11px/1 var(--font-telemetry)", color: "var(--quiet-metal)", flex: "none" }}>{rows.length ? (isOpen ? "−" : `+${rows.length}`) : "—"}</span>
              </button>
              {isOpen ? rows.map((a) => <AgentRow key={a.id} a={a} onSelect={setSel} />) : null}
            </section>
          );
        })}
        <div style={{ padding: "16px 14px 24px", borderTop: "1px solid var(--border-on-dark)", font: "400 11px/1.6 var(--font-telemetry)", color: "var(--quiet-metal-dim)" }}>
          The spatial field does not shrink to this width. Stages keep the same causal order: constraint below, frontier above.<br />AI/ACC
        </div>
      </div>

      {gateOpen ? (
        <DecisionGate open authority="OPERATOR"
          prompt="A-22 blocked by a rate limit."
          choices={[{ label: "Wait 41s", consequence: "Dependents queued", reversible: true, variant: "secondary" }, { label: "Reroute", consequence: "Loses cite-check", reversible: true, variant: "primary" }]}
          onChoose={() => setGateOpen(false)}
          style={{ flex: "none", flexDirection: "column" }}
        />
      ) : null}
      <CLISheet expanded={cliOpen} lines={DMob.cli} context={`mission/${DMob.mission.id}`} simulated hint="TAP" onToggle={() => setCliOpen((v) => !v)} style={{ flex: "none" }} />

      {selected ? (
        <div style={{ position: "absolute", inset: 0, zIndex: 10, display: "flex", flexDirection: "column", justifyContent: "flex-end", background: "rgba(5,5,9,0.6)" }} onClick={() => setSel(null)}>
          <div onClick={(e) => e.stopPropagation()} style={{ height: "72%" }}>
            <ContextInspector
              open kind={selected.kind === "cluster" ? "CLUSTER" : "AGENT"}
              title={selected.role || selected.label}
              subtitle={selected.kind === "cluster" ? `${selected.id} · ${selected.count} workers` : `${selected.id} · ${selected.harness} / ${selected.model}`}
              sections={selected.kind === "cluster"
                ? [{ label: "Aggregate", rows: [{ k: "Workers", v: String(selected.count) }, { k: "Owner", v: selected.owner }, { k: "Tokens", v: selected.tokens }, { k: "Cost", v: selected.cost, tone: "active" }] }]
                : [
                  { label: "Ownership", rows: [{ k: "Owner", v: selected.owner }, { k: "Workspace", v: selected.workspace }] },
                  { label: "Runtime", rows: [{ k: "Harness", v: selected.harness }, { k: "Model", v: selected.model }, { k: "Reasoning", v: selected.reasoning }, { k: "Context", v: selected.context }] },
                  { label: "Resource", rows: [{ k: "Tokens", v: selected.tokens }, { k: "Cost", v: selected.cost, tone: "active" }, { k: "Elapsed", v: selected.elapsed }] },
                  { label: "Work", rows: [{ k: "Evidence", v: String(selected.evidence), tone: "verified" }, { k: "Dependencies", v: String(selected.deps) }] }
                ]}
              onClose={() => setSel(null)}
              actions={<Button on="dark" variant="secondary" size="sm" full onClick={() => setSel(null)}>Close</Button>}
              style={{ width: "100%", height: "100%", borderLeft: "none", borderTop: "1px solid var(--border-on-dark-strong)" }}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

Object.assign(window, { MobileApp });
