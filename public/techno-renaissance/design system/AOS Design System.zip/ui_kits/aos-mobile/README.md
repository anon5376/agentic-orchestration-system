# AOS mobile — UI kit

The same mission as the desktop kit at **390×844**. Open `index.html`.

The spatial field is not shrunk. Below 760px the causal order becomes an ordered
stage list — `FRONTIER` at the top, `CONSTRAINT` at the bottom — and each stage
expands into a hierarchical agent list indented by delegation depth. Tapping an
agent opens `ContextInspector` as a bottom sheet; the CLI is a full-width sheet;
the decision gate stacks above it.

## Files

- `index.html` — mount; loads `styles.css`, the compiled bundle, `../aos-dashboard/data.js`, then `MobileApp.jsx`
- `MobileApp.jsx` — compact rail, objective field, stage list, agent rows, sheets

State is the same deterministic `window.AOSDATA` as the desktop kit, so the two
surfaces always agree.
