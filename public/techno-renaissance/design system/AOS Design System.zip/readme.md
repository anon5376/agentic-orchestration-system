# AOS — Design System

**AOS (Agentic Orchestration System)** is an open-source research control plane and
second-layer harness that coordinates existing AI workers, coding agents, APIs,
OAuth providers, MCP servers, skills, plugins and local models.

A user gives AOS a difficult research goal plus documents and context. AOS
decomposes it into a hierarchical swarm of specialised agents, runs isolated
parallel work, tracks evidence, provenance, models, tokens, cost, timing and
dependencies, then synthesises findings, records failures, and proposes
versioned self-improvements behind approval gates.

The product has two surfaces over one mission state: a **dashboard** and a
**CLI**. The visible product name is always exactly **AOS**.

The design north star, taken verbatim from the supplied brief, is **The
Acceleration Chamber**: the control surface of an intelligence accelerating
beyond its previous form. It combines Nous/Hermes editorial restraint (committed
cobalt and white fields, thin contemporary type, hard boundaries, sparse image
rhythm) with technological acceleration (recursive delegation, compressed time,
model handoffs, convergence, mutation, visible generations). It should read as
serious research infrastructure whose internal velocity occasionally becomes
visible — never retro-futurism, never a generic admin dashboard.

## Sources given to us

Everything in this system was derived from one uploaded brief. There was **no
codebase, no Figma file, no repository, no logo and no font binaries**.

| Source | Path as supplied | What it gave us |
|---|---|---|
| Product idea | `uploads/AOS-ACCELERATION-CHAMBER-CLAUDE-DESIGN/IDEA.md` | Product model, mission lifecycle, capabilities, memory, self-improvement loop, dashboard/CLI split |
| Design authority | `uploads/AOS-ACCELERATION-CHAMBER-CLAUDE-DESIGN/DESIGN.md` | Colour palette with hex values, typography intent, layout/shell rules, elevation, shapes, the component inventory, motion, do's and don'ts |
| Brief | `uploads/AOS-ACCELERATION-CHAMBER-CLAUDE-DESIGN/START_HERE.md` | First surface (`#/swarm` at 1440×900 and 390×844), remaining routes, rejection criteria, usability proof |
| Reference index | `uploads/AOS-ACCELERATION-CHAMBER-CLAUDE-DESIGN/REFERENCE_INDEX.md` | Which references govern what, and the explicit instruction not to copy them |
| Mood references | `references/nous/01–14 (*.png)`, `references/tiktok/01–04 (*.jpg)` | Composition and mood only: field commitment, contrast, sparse rhythm, recursion, convergence, warped scale. Public Nous Research / Hermes Agent / Nous Portal captures and TikTok stills — **used as mood, never reproduced; no artwork, mark, copy or layout was copied** |

Nothing here was taken from Nous branding: the palette, type roles, shell
geometry and component list all come from the supplied `DESIGN.md`.

## CONTENT FUNDAMENTALS

How AOS writes. The voice is an instrument's voice: it reports, it does not sell.

**Person.** No "I". Second person only in imperatives on controls
("Attach context", "Open trace"). Everything else is stated in the third person
about the system: "The lead requests a missing input before delegating."

**Tense and mood.** Present tense for state, past tense for evidence, future
only where a consequence is being declared before an action ("New runs use
GEN 08"). Declarative sentences. No exclamation marks anywhere.

**Casing.**
- `UPPERCASE` with `--tracking-label` for rails, region labels, run state, terse
  actions, and telemetry labels: `SWARM`, `RUNNING`, `HUMAN GATE`, `TOKENS`.
- Sentence case for headings, claims, notes and body copy: "Generation 08 is a
  candidate, not a fact."
- Lowercase for machine strings, exactly as the system emits them:
  `claude-sonnet-4`, `ws/a-14`, `gen-07 · 4a91c2`, `swarm dispatch --lead L-01`.
- Never uppercase a paragraph.

**Numbers.** Always with a unit or a denominator, always monospace, always
tabular: `412K`, `$4.90`, `07:22`, `9/41`, `68%`, `CONF 0.81`. A bare number is
only acceptable in a count next to its noun (`EVID 22`).

**Honesty rules** (these are content rules, not decoration):
- Demo state is labelled: the rail shows `ILLUSTRATIVE`, the CLI shows
  `SIMULATED`, and nothing claims to execute when it does not.
- Consequence before action: every gate choice states what changes, whether it is
  reversible, and who may authorise it.
- Dissent stays visible. `CONTRADICTED` is a first-class state and a contradicted
  claim is never quietly dropped.
- No present-tense capability claims about intelligence. AOS is not ASI; the
  singularity is the horizon metaphor and a convergence state, never a boast.
- Capabilities describe real differences: "PARTIAL tool support", "LOCAL",
  "OAUTH", "retry 41s".

**Length.** Headings up to about 8 words. Body paragraphs 1–3 sentences, max
62 characters per line (`--measure-body`). Telemetry strings never wrap.

**Vocabulary.** mission, objective, constraint, decomposition, lead, specialist,
delegation, harness, model, reasoning effort, workspace, dependency, evidence,
provenance, claim, dissent, objection, convergence, synthesis, gate, authority,
generation, candidate, baseline, regression, rollback, promotion, aggregate,
cluster, frontier. Avoid: "AI-powered", "seamless", "magic", "insights",
"supercharge", "just", "simply".

**"AI/ACC"** may appear only as a subtle secondary metadata label — a footer tag,
a command-palette category, a hidden system detail. It is in this system exactly
twice: as a palette category and as an intake footer line. It must never appear
in a hero title or the brand lockup.

**Emoji: never.** Not in UI, not in docs, not in commit-style strings.

**Examples, verbatim from the kits.**
- Route title: `Generation 08 is a candidate, not a fact.`
- Gate: `A-22 is blocked by a provider rate limit and two dependents are waiting.`
- Gate choice: `Promote + auto-adopt` / `Future safe changes self-promote` / `IRREVERSIBLE`
- Evidence claim: `Two of three named suppliers disclose 2029 capacity below the modelled EU requirement.`
- Aggregate caption: `46 OF 41 OWNED TASKS AGGREGATED INTO 2 CLUSTERS`
- Memory note: `“Remember everything” is an option with consequences, not a hidden default.`
- CLI: `A-22 blocked: rate limit anthropic · retry 41s · 2 dependents waiting`

## VISUAL FOUNDATIONS

### Colour

Ten core values, from `DESIGN.md`, in `tokens/colors.css`: Acceleration Cobalt
`#101CFF`, Void `#050509`, Ultraviolet Transit `#6B45FF`, Ion Signal `#B8FF3D`,
Intervention Vermilion `#FF3B12`, Mineral White `#F4F4F0`, Cold White `#FAFBFF`,
Graphite `#15151B`, Quiet Metal `#7F818C`, Rule `#CFD0D6`. Every other value in
the system is a derived step of those ten (`--cobalt-deep`, `--void-plate`,
`--graphite-edge`, …) — no new hues are invented.

Rules:
- Cobalt and void are **committed whole fields**, not card fills. One dominant
  field per screen.
- Cobalt means active computation or selection. Ultraviolet means transition,
  distance, or an adjacent generation. Ion means verified — never "cool".
  Vermilion is rare and consequential: conflict, gate, failure, rollback.
- One dominant field + one signal colour + neutrals on a normal screen.
- No gradients as content, no multicolour glow, no teal/magenta cyberpunk
  palette, no colour that does not encode state.
- Semantic aliases are always preferred in code: `--surface-operational`,
  `--text-on-dark-secondary`, `--state-blocked`, `--trace-handoff`.

### Typography

Three roles, three families (see *Substitutions* below):

| Role | Family | Token | Use |
|---|---|---|---|
| Display | Archivo Narrow | `--font-display` | Monumental state, route titles, objectives, scope names |
| Interface | Instrument Sans | `--font-interface` | Body, labels, buttons, node roles |
| Telemetry | IBM Plex Mono | `--font-telemetry` | Ids, models, tokens, cost, timestamps, CLI, all numbers |

Scale: one monumental element per viewport (`--type-monument`,
clamp 56→132px), display 88/64/44, titles 32/24/18, body 15/13, labels 11–12,
telemetry 14/12/11 — never below 11px. Hierarchy comes from scale and position,
not weight: only 400/500/600 are used. Tracking: `-0.03em` at monument scale,
`0.14em` on uppercase labels. Line height 0.88–0.94 for display, 1.5 for body.

Typographic distortion (stretch, shear, split, phase-shift) is permitted **only**
while representing a live handoff, a branch divergence, a generation boundary,
temporal compression or a fault. Static titles stay crisp. No permanent glitch
type, no blackletter, no faux-terminal lettering.

### Layout & structure

- A 44px global rail on top; a 32px CLI rail on the bottom that expands to 300px
  on request. **There is no permanent left sidebar.**
- Primary work field ≈ two thirds of the viewport; a 380px context inspector
  takes the remaining third **only when something is selected**; a bottom
  decision strip appears **only** when a real gate exists. Never more than three
  major regions, and one dominant focal event.
- Hard boundaries, cropped fields and edge-to-edge colour blocks replace floating
  cards. Page gutter 32px (20px narrow), grid 12 columns, 24px gap.
- Large negative space is functional: it establishes hierarchy and gives active
  traces somewhere to move. An empty-feeling region is a density decision, not a
  gap to fill.
- Responsive: above 1200px full field + conditional inspector; 760–1200px drop
  peripheral telemetry and collapse aggregates, keep the causal path; below
  760px the spatial field becomes ordered stages and hierarchical lists, and the
  inspector and CLI become sheets. Never a miniature unreadable desktop graph.

### Backgrounds & imagery

Fields are flat colour. Atmosphere is **generated in CSS, never shipped as an
image**: `--dither-fine`, `--dither-coarse`, `--hatch-45` (mutation seams),
`--grid-field` (48px field grid at 55% graphite), `--density-dormant`,
`--scale-ticks`. No photography, illustration or texture files were supplied, so
image regions render as honest labelled slots (`SOURCE IMAGE · NOT SUPPLIED`).

When real imagery arrives it must be nonhuman and meaningful: infrastructure,
machinery, fibres, chips, servers, optical systems, scans, material structure,
robotic mechanisms, signal fields, dithered evidence fragments, severe
documentary crops. Cool, high-contrast, desaturated or duotone-to-cobalt;
dithering is allowed on evidence imagery but never on source text. Forbidden:
statues, Renaissance figures, AI faces, disembodied hands, humanoid robots,
brains, stock black holes, galaxies, astronauts, occult symbolism.

### Depth, borders, corners, cards

Structurally flat. Depth comes from adjacency, occlusion, crop, scale, density
and contrast — **no glassmorphism, no gloss, no soft drop shadows, no floating
panels, no bevels, no 3D chrome**. The only "shadow" tokens in the system are
1px hard seams (`--seam-scar`, `--seam-consequence`).

- Corners are square; `--radius-max` is 2px and is the largest radius in AOS.
  Circles are reserved for apertures, convergence, time, capacity and sockets.
- Hairlines are 1px: `--border-hairline-dark` `#23232C` on void,
  `--border-rule-dark` `#34343F` for structural edges, `--rule` `#CFD0D6` on
  mineral. Dividers may be interrupted by labels or connection ports.
- There are no cards. A bounded object (agent plate, evidence plate, cluster) is
  a 1px-bordered rectangle on the field with a **3px left edge in its state
  colour** and no radius, no shadow, no hover lift.
- Selection inverts a plate to cobalt with a cold-white edge. Off-path plates
  recede via the opacity ladder (`--opacity-recede` 0.44, `--opacity-dormant`
  0.24) — contrast, not blur.

### Transparency & blur

Used twice only: a modal scrim (`rgba(5,5,9,0.72)`) behind the command palette
and mobile sheets, and the left-edge fade on the stage ladder so traces can pass
under it. **No backdrop blur anywhere.** Type is never alpha-muted — secondary
text uses a solid tint (`#A2A4AE` on void, `#C3C7FF` on cobalt) so contrast
holds.

### Motion

Causal and brief, from `tokens/motion.css`: 140ms state, 260ms branch, 420ms core
compression, 640ms generation. Easing `--ease-instrument`
`cubic-bezier(.2,0,0,1)` for interface state, `--ease-compress`
`cubic-bezier(.65,0,.35,1)` for gravitational compression, linear for telemetry
only. Branches split when work is delegated; traces travel upward as evidence
accumulates; the core compresses during synthesis; a handoff phase-shifts once;
a mutation opens a seam and leaves a scar. The single permitted loop is the
aperture's 3.2s rotation while work is genuinely in flight. No ambient particles,
no pulsing neon, no auto-scrolling telemetry, no jitter, no glitch loops.
`prefers-reduced-motion` zeroes every duration token.

### Interaction states

- **Hover:** background darkens or a hairline gains contrast
  (`--cobalt-deep` on primary, `--void-plate` on dark, `--surface-sunken` on
  mineral). Never lighten, never lift, never scale.
- **Press:** the committed colour holds; no shrink, no shadow.
- **Focus:** a 1px cobalt edge plus an inset 1px ring, and on inputs the aperture
  glyph appears in the field. `--focus-ring-on-dark` is cold white on cobalt.
- **Selected:** inverted plate (cobalt fill, cold-white edge) and the rest of the
  branch dims.
- **Disabled:** 34% opacity, no colour change.
- **Links:** `--state-running-on-dark` `#5560FF` on dark, `--cobalt` on mineral;
  hover goes to full cold white / void. Underline only inside running prose.

### Signature shape

The **open convergence aperture**: asymmetric paths compress toward a centre but
do not terminate there — one path exits the far side as the next generation. It
is the system sigil, the input focus mark, the centre of the swarm field, the
synthesis gate, the mutation boundary and the progress indicator. Legible at
16px, expressive at viewport scale. Below 20px it drops its feeder lines.

## ICONOGRAPHY

**There is no AOS logo.** None was supplied, and none was invented. Wherever a
mark would go, `AOS` is set in the display family, uppercase, `0.08em` tracking,
beside the aperture sigil — that is the lockup, see
`guidelines/brand-lockup.card.html`.

**The aperture sigil** (`assets/aperture.svg`, `assets/aperture-field.svg`) is not
a logo: it is the signature shape specified in the supplied `DESIGN.md`, drawn as
plain geometry (one open arc, two feeder lines, one axis line that exits the far
side, one centre point). Use the `Aperture` component in React. In static HTML,
**inline the SVG** so `currentColor`/`stroke` applies — an `<img src="*.svg">`
cannot be tinted.

**Icon set: none was supplied.** AOS uses almost no pictorial icons by design —
the interface speaks in state colour, hairlines, monospace labels and the
aperture. Where a glyph is genuinely needed, this system uses, in order:

1. **Typographic marks** carrying system meaning: `//` for a region label, `←`
   for ownership ("← A-07"), `→` for a next step, `·` as the telemetry
   separator, `×` for counts and close, `−` / `+` for expand/collapse, `●` / `■`
   for time-based vs held state, `⌘K` / `⌃\`` for shortcuts, `›` for the CLI
   prompt. These are text, not icons, and inherit type colour.
2. **Lucide** (CDN, `stroke-width: 1.25`, 16px box, `currentColor`) **only** when
   a real pictorial affordance is unavoidable — a file attachment, a provider
   socket. This is a **flagged substitution**: no icon set was supplied, and
   Lucide's thin strokes are the closest match to the brief's hard 1px language.
   Link it as `https://unpkg.com/lucide-static@0.454.0/icons/<name>.svg` and
   inline the markup rather than using `<img>`.
3. Nothing else. No icon font, no emoji, no unicode pictographs
   (⚠️, ✅, 🚀 are all forbidden), no hand-rolled illustrative SVG.

## Component inventory

The component list is exactly the inventory defined in the supplied
`DESIGN.md` > Components, plus a small set of primitives marked as additions.
Cards: one per directory, `group="Components"`.

**`components/shell/`** — the instrument chrome
- `GlobalRail` — AOS lockup, routes, mission id, demo/live honesty, connection health, command aperture
- `ContextInspector` — conditional 380px detail region for the current selection (bottom sheet on narrow screens)
- `DecisionGate` — bottom strip with action, consequence, reversibility, authority
- `CLISheet` — collapsible keyboard-first command surface with working context and simulated/executes state

**`components/swarm/`** — the acceleration field
- `AccelerationField` — the central working surface; causal geometry, active path, aggregation
- `AgentNode` — one owned task: role, id, harness/model, state, tokens · cost · elapsed
- `AgentTrace` — directional delegation and dependency edges with state and throughput
- `ClusterAggregate` — dormant or repetitive branches bundled with counts and distribution
- `ConvergenceCore` — the singularity as an inspectable convergence state with a generation exit

**`components/research/`** — objective, evidence, mutation
- `ObjectiveAperture` — goal intake with constraints, context, definition of done, open ambiguity
- `EvidencePlate` — claim, source, provenance, freshness, confidence, contradiction, consumers
- `GenerationRift` — baseline/candidate seam with changed rules, metric deltas, regressions, rollback

**`components/core/`** — *intentional additions* (primitives `DESIGN.md` assumes but does not enumerate; each exists because the enumerated components need it)
- `Button` — the single control style; `DecisionGate`, inspectors and kits all use it
- `Field` — the single input style, with the aperture focus mark
- `StateBadge` — the fixed run-state vocabulary in one place, so states cannot drift
- `Telemetry` — labelled machine values with tabular figures, used by every surface
- `SectionLabel` — the `// REGION` marker described under Layout
- `Aperture` — the signature shape as a component, so the sigil is never redrawn

Each component directory holds `<Name>.jsx`, `<Name>.d.ts` (props contract),
`<Name>.prompt.md` (what & when, usage, variants) and one `@dsCard` HTML.

## UI kits

- **`ui_kits/aos-dashboard/`** — AOS dashboard at 1440×900, all eight routes
  click-through: `SWARM` (default), `MISSIONS`, `INTAKE`, `EVIDENCE`,
  `SYNTHESIS`, `EVOLUTION`, `CAPABILITIES`, `MEMORY`. Select an agent or cluster
  to open the inspector, expand the CLI (⌃\`), open the command palette (⌘K),
  resolve the decision gate. Deterministic state lives in `data.js`.
- **`ui_kits/aos-mobile/`** — the same mission at 390×844: ordered stages,
  hierarchical agent lists, inspector as a bottom sheet, CLI as a full-width
  sheet. The desktop graph is not shrunk.

## Index

| Path | What it is |
|---|---|
| `styles.css` | Global entry point — webfont import plus `@import`s of every token file. Consumers link this. |
| `tokens/colors.css` | Core palette, derived steps, semantic aliases, state and trace colours |
| `tokens/typography.css` | Families, scale, weights, leading, tracking, measures |
| `tokens/spacing.css` | 4px scale, shell geometry, hit targets |
| `tokens/borders.css` | Border widths, hairlines, radii (max 2px), dashes, seams |
| `tokens/motion.css` | Durations, easings, reduced-motion overrides |
| `tokens/surfaces.css` | Generated dither/hatch/grid atmosphere and the opacity ladder |
| `assets/` | `aperture.svg`, `aperture-field.svg`, `assets/readme.md` (what is deliberately absent) |
| `components/{shell,swarm,research,core}/` | The component inventory above |
| `guidelines/*.card.html` | 19 foundation specimen cards: Colors, Type, Spacing, Brand |
| `ui_kits/aos-dashboard/` | Desktop kit: `index.html`, `Shell.jsx`, `SwarmScreen.jsx`, `MissionScreens.jsx`, `ResearchScreens.jsx`, `SystemScreens.jsx`, `data.js`, `README.md` |
| `ui_kits/aos-mobile/` | Mobile kit: `index.html`, `MobileApp.jsx`, `README.md` |
| `thumbnail.html` | Project tile |
| `SKILL.md` | Agent Skills front matter for use in Claude Code |

## Substitutions and gaps — read before shipping

1. **Fonts are substitutes.** No binaries were supplied. `DESIGN.md` asks for "a
   narrow contemporary grotesk", "a neutral modern sans" and "a disciplined
   monospace"; this system uses Archivo Narrow, Instrument Sans and IBM Plex Mono
   from Google Fonts, loaded by a remote `@import` at the top of `styles.css`
   **and** a `<link>` in each card/kit head (some preview environments drop
   nested remote `@import`s). Supply the real families and only
   `tokens/typography.css` plus that import change.
2. **No logo, no wordmark file.** Type lockup only, as described under
   ICONOGRAPHY.
3. **No icon set, no imagery.** Lucide is a flagged CDN substitution; image
   regions are honest empty slots.
4. **Illustrative data only.** `ui_kits/aos-dashboard/data.js` is deterministic
   fiction for one mission (MSN-2291). Nothing executes; every surface says so.
5. **Not covered because nothing defined it:** light-field ("mineral") screens
   beyond the specimen cards, empty/error/loading states for each route, an
   account or settings surface, and docs/marketing pages. The tokens carry a full
   light context (`--surface-canvas`, `--text-primary`, …) ready for them.
