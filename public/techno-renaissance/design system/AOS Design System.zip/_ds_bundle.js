/* @ds-bundle: {"format":4,"namespace":"AOSDesignSystem_20e4c5","components":[{"name":"Aperture","sourcePath":"components/core/Aperture.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Field","sourcePath":"components/core/Field.jsx"},{"name":"SectionLabel","sourcePath":"components/core/SectionLabel.jsx"},{"name":"StateBadge","sourcePath":"components/core/StateBadge.jsx"},{"name":"Telemetry","sourcePath":"components/core/Telemetry.jsx"},{"name":"EvidencePlate","sourcePath":"components/research/EvidencePlate.jsx"},{"name":"GenerationRift","sourcePath":"components/research/GenerationRift.jsx"},{"name":"ObjectiveAperture","sourcePath":"components/research/ObjectiveAperture.jsx"},{"name":"CLISheet","sourcePath":"components/shell/CLISheet.jsx"},{"name":"ContextInspector","sourcePath":"components/shell/ContextInspector.jsx"},{"name":"DecisionGate","sourcePath":"components/shell/DecisionGate.jsx"},{"name":"GlobalRail","sourcePath":"components/shell/GlobalRail.jsx"},{"name":"AccelerationField","sourcePath":"components/swarm/AccelerationField.jsx"},{"name":"AgentNode","sourcePath":"components/swarm/AgentNode.jsx"},{"name":"AgentTrace","sourcePath":"components/swarm/AgentTrace.jsx"},{"name":"ClusterAggregate","sourcePath":"components/swarm/ClusterAggregate.jsx"},{"name":"ConvergenceCore","sourcePath":"components/swarm/ConvergenceCore.jsx"}],"sourceHashes":{"components/core/Aperture.jsx":"cef096c82174","components/core/Button.jsx":"5b1a73f46f3e","components/core/Field.jsx":"d225e3d9c2b0","components/core/SectionLabel.jsx":"c232433365fd","components/core/StateBadge.jsx":"f29922cdd324","components/core/Telemetry.jsx":"8b36a3477c9c","components/research/EvidencePlate.jsx":"69006b88b96e","components/research/GenerationRift.jsx":"54bbb33a1de9","components/research/ObjectiveAperture.jsx":"76fe4f73a7aa","components/shell/CLISheet.jsx":"f2e53cae14c7","components/shell/ContextInspector.jsx":"d5059eaa2483","components/shell/DecisionGate.jsx":"a11bf5f6eea8","components/shell/GlobalRail.jsx":"4f6c7136aa10","components/swarm/AccelerationField.jsx":"d4ad5d53b5dd","components/swarm/AgentNode.jsx":"a6e7ea11ba09","components/swarm/AgentTrace.jsx":"6eef932d2f7f","components/swarm/ClusterAggregate.jsx":"4e387e539694","components/swarm/ConvergenceCore.jsx":"1fc1d49deffd","ui_kits/aos-dashboard/MissionScreens.jsx":"a7d5f91e370a","ui_kits/aos-dashboard/ResearchScreens.jsx":"94d68834a050","ui_kits/aos-dashboard/Shell.jsx":"838530aaa646","ui_kits/aos-dashboard/SwarmScreen.jsx":"676fd8395ddd","ui_kits/aos-dashboard/SystemScreens.jsx":"2910988be0c8","ui_kits/aos-dashboard/data.js":"d89c1180c178","ui_kits/aos-dashboard/doc-page.js":"f52ae9c02fca","ui_kits/aos-mobile/MobileApp.jsx":"35c5fcbd722f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AOSDesignSystem_20e4c5 = window.AOSDesignSystem_20e4c5 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Aperture.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cobalt: "var(--cobalt)",
  white: "var(--cold-white)",
  void: "var(--void)",
  ion: "var(--ion)",
  ultraviolet: "var(--ultraviolet)",
  inherit: "currentColor"
};

/* The AOS system sigil: asymmetric paths compress toward a centre but do not
   terminate there — one path exits the far side as the next generation.
   Geometry is fixed; only scale, tone and state change. */
function Aperture({
  size = 16,
  tone = "inherit",
  state = "idle",
  title,
  style,
  ...rest
}) {
  const color = TONES[tone] || tone;
  const running = state === "running";
  const converging = state === "converging";
  const apertureSx = {
    display: "block",
    color,
    flex: "none",
    transformOrigin: "50% 50%",
    animation: running ? "aos-aperture-turn 3.2s linear infinite" : "none",
    ...style
  };
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: size >= 48 ? 1 : 1.5,
    strokeLinecap: "butt",
    role: title ? "img" : "presentation",
    "aria-label": title,
    style: apertureSx
  }, rest), /*#__PURE__*/React.createElement("style", null, "@keyframes aos-aperture-turn{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){svg{animation:none!important}}"), /*#__PURE__*/React.createElement("path", {
    d: "M16.98 16.18A6.5 6.5 0 1 1 16.98 7.82"
  }), size >= 20 ? /*#__PURE__*/React.createElement("path", {
    d: "M0 3 5.9 9.8",
    strokeOpacity: converging ? 1 : 0.72
  }) : null, size >= 20 ? /*#__PURE__*/React.createElement("path", {
    d: "M0 21 5.9 14.2",
    strokeOpacity: converging ? 1 : 0.72
  }) : null, /*#__PURE__*/React.createElement("path", {
    d: "M0 12 23 12"
  }), converging ? /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "1.8",
    fill: "currentColor",
    stroke: "none"
  }) : null);
}
Object.assign(__ds_scope, { Aperture });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Aperture.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SURFACES = {
  light: {
    primary: {
      bg: "var(--cobalt)",
      fg: "var(--cold-white)",
      bd: "var(--cobalt)",
      hoverBg: "var(--cobalt-deep)"
    },
    secondary: {
      bg: "transparent",
      fg: "var(--void)",
      bd: "var(--void)",
      hoverBg: "var(--surface-sunken)"
    },
    ghost: {
      bg: "transparent",
      fg: "var(--text-secondary)",
      bd: "transparent",
      hoverBg: "var(--surface-sunken)"
    },
    consequence: {
      bg: "var(--vermilion)",
      fg: "var(--cold-white)",
      bd: "var(--vermilion)",
      hoverBg: "#E22F08"
    }
  },
  dark: {
    primary: {
      bg: "var(--cobalt)",
      fg: "var(--cold-white)",
      bd: "var(--cobalt)",
      hoverBg: "#2733FF"
    },
    secondary: {
      bg: "transparent",
      fg: "var(--cold-white)",
      bd: "var(--border-on-dark-strong)",
      hoverBg: "var(--void-plate)"
    },
    ghost: {
      bg: "transparent",
      fg: "var(--text-on-dark-secondary)",
      bd: "transparent",
      hoverBg: "var(--void-plate)"
    },
    consequence: {
      bg: "transparent",
      fg: "var(--vermilion)",
      bd: "var(--vermilion)",
      hoverBg: "rgba(255,59,18,0.12)"
    }
  },
  field: {
    primary: {
      bg: "var(--cold-white)",
      fg: "var(--cobalt)",
      bd: "var(--cold-white)",
      hoverBg: "#E6E9FF"
    },
    secondary: {
      bg: "transparent",
      fg: "var(--cold-white)",
      bd: "var(--cold-white)",
      hoverBg: "rgba(250,251,255,0.14)"
    },
    ghost: {
      bg: "transparent",
      fg: "var(--text-on-field-secondary)",
      bd: "transparent",
      hoverBg: "rgba(250,251,255,0.1)"
    },
    consequence: {
      bg: "var(--vermilion)",
      fg: "var(--cold-white)",
      bd: "var(--vermilion)",
      hoverBg: "#E22F08"
    }
  }
};
const SIZES = {
  sm: {
    h: "var(--control-height)",
    px: "10px",
    fs: "var(--type-label)"
  },
  md: {
    h: "var(--control-height-lg)",
    px: "16px",
    fs: "var(--type-label-lg)"
  }
};
function Button({
  variant = "primary",
  size = "md",
  on = "light",
  icon,
  iconAfter,
  disabled = false,
  full = false,
  children,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = (SURFACES[on] || SURFACES.light)[variant] || SURFACES.light.primary;
  const z = SIZES[size] || SIZES.md;
  const buttonSx = {
    display: full ? "flex" : "inline-flex",
    width: full ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-3)",
    height: z.h,
    padding: `0 ${z.px}`,
    background: hover && !disabled ? s.hoverBg : s.bg,
    color: s.fg,
    border: `1px solid ${s.bd}`,
    borderRadius: "var(--radius-none)",
    font: `var(--weight-medium) ${z.fs}/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.34 : 1,
    transition: `background var(--dur-state) var(--ease-instrument),color var(--dur-state) var(--ease-instrument)`,
    whiteSpace: "nowrap",
    userSelect: "none"
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: buttonSx
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flex: "none"
    }
  }, icon) : null, children, iconAfter ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flex: "none"
    }
  }, iconAfter) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Hard-edged input. Focus is marked by a cobalt edge plus the aperture glyph —
   the same mark used for the goal input focus state in DESIGN.md. */
function Field({
  label,
  value,
  placeholder,
  hint,
  prefix,
  multiline = false,
  rows = 3,
  mono = false,
  on = "light",
  invalid = false,
  disabled = false,
  size = "md",
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const dark = on !== "light";
  const edge = invalid ? "var(--vermilion)" : focus ? "var(--cobalt)" : dark ? "var(--border-on-dark-strong)" : "var(--void)";
  const fieldSx = {
    display: "flex",
    alignItems: multiline ? "flex-start" : "center",
    gap: "var(--space-3)",
    background: dark ? "var(--void-plate)" : "var(--surface-plate)",
    border: `1px solid ${edge}`,
    boxShadow: focus ? `inset 0 0 0 1px ${edge}` : "none",
    padding: multiline ? "10px 12px" : "0 12px",
    height: multiline ? "auto" : size === "sm" ? "var(--control-height)" : "var(--control-height-lg)",
    transition: "border-color var(--dur-state) var(--ease-instrument)",
    opacity: disabled ? 0.4 : 1
  };
  const inputSx = {
    flex: 1,
    width: "100%",
    background: "transparent",
    border: "none",
    outline: "none",
    resize: multiline ? "vertical" : "none",
    color: dark ? "var(--cold-white)" : "var(--void)",
    font: `var(--weight-regular) ${size === "sm" ? "var(--type-body-sm)" : "var(--type-body)"}/${multiline ? "var(--leading-body)" : "1"} ${mono ? "var(--font-telemetry)" : "var(--font-interface)"}`,
    letterSpacing: mono ? "var(--tracking-telemetry)" : "0"
  };
  const T = multiline ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)",
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: dark ? "var(--text-on-dark-secondary)" : "var(--text-secondary)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    style: fieldSx
  }, prefix ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)",
      flex: "none",
      paddingTop: multiline ? "3px" : 0
    }
  }, prefix) : null, /*#__PURE__*/React.createElement(T, _extends({
    value: value,
    rows: multiline ? rows : undefined,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: inputSx
  }, rest)), focus ? /*#__PURE__*/React.createElement(__ds_scope.Aperture, {
    size: 14,
    tone: "cobalt",
    state: "converging",
    style: {
      flex: "none",
      marginTop: multiline ? "2px" : 0
    }
  }) : null), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1.4 var(--font-telemetry)`,
      color: invalid ? "var(--vermilion)" : "var(--quiet-metal)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Field.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* `// SECTION` label. The double slash is the AOS structural marker: it means
   "this is a system region", and it is the only decorative glyph in the system. */
function SectionLabel({
  children,
  index,
  on = "light",
  rule = false,
  action,
  style,
  ...rest
}) {
  const dark = on !== "light";
  const color = dark ? "var(--text-on-dark-secondary)" : "var(--text-secondary)";
  const ruleColor = dark ? "var(--border-on-dark)" : "var(--border-rule)";
  const wrapSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-4)",
    minHeight: "20px",
    ...style
  };
  const labelSx = {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color,
    whiteSpace: "nowrap"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: wrapSx
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: labelSx
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: dark ? "var(--quiet-metal-dim)" : "var(--quiet-metal)",
      letterSpacing: "0"
    }
  }, "//"), children, index != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, index) : null), rule ? /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: "1px",
      background: ruleColor
    }
  }) : null, action ? /*#__PURE__*/React.createElement("span", {
    style: {
      flex: "none"
    }
  }, action) : null);
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/core/StateBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATES = {
  running: {
    label: "RUNNING",
    color: "var(--cobalt)",
    onDark: "var(--state-running-on-dark)"
  },
  waiting: {
    label: "WAITING",
    color: "var(--quiet-metal)",
    onDark: "var(--quiet-metal)"
  },
  blocked: {
    label: "BLOCKED",
    color: "var(--ultraviolet)",
    onDark: "#8E72FF"
  },
  failed: {
    label: "FAILED",
    color: "var(--vermilion)",
    onDark: "var(--vermilion)"
  },
  complete: {
    label: "COMPLETE",
    color: "#4C7A00",
    onDark: "var(--ion)"
  },
  dormant: {
    label: "DORMANT",
    color: "var(--quiet-metal-dim)",
    onDark: "var(--quiet-metal-dim)"
  },
  handoff: {
    label: "HANDOFF",
    color: "var(--ultraviolet)",
    onDark: "#8E72FF"
  },
  gate: {
    label: "HUMAN GATE",
    color: "var(--vermilion)",
    onDark: "var(--vermilion)"
  },
  verified: {
    label: "VERIFIED",
    color: "#4C7A00",
    onDark: "var(--ion)"
  }
};
function StateBadge({
  state = "running",
  label,
  on = "light",
  form = "outline",
  dot = true,
  style,
  ...rest
}) {
  const s = STATES[state] || STATES.running;
  const color = on === "light" ? s.color : s.onDark;
  const solid = form === "solid";
  const badgeSx = {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    height: "18px",
    padding: form === "bare" ? 0 : "0 6px",
    border: form === "bare" ? "none" : `1px solid ${solid ? color : color}`,
    background: solid ? color : "transparent",
    color: solid ? state === "complete" || state === "verified" ? "var(--void)" : "var(--cold-white)" : color,
    font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
    letterSpacing: "var(--tracking-label-tight)",
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    ...style
  };
  const dotSx = {
    width: "5px",
    height: "5px",
    flex: "none",
    background: solid ? "currentColor" : color,
    borderRadius: state === "running" || state === "complete" ? "var(--radius-aperture)" : "0",
    opacity: state === "dormant" || state === "waiting" ? 0.7 : 1
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: badgeSx
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: dotSx
  }) : null, label || s.label);
}
Object.assign(__ds_scope, { StateBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StateBadge.jsx", error: String((e && e.message) || e) }); }

// components/core/Telemetry.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE_MAP = {
  neutral: null,
  active: "var(--cobalt)",
  verified: "#4C7A00",
  consequence: "var(--vermilion)",
  transition: "var(--ultraviolet)",
  dim: "var(--quiet-metal)"
};
const TONE_MAP_DARK = {
  neutral: null,
  active: "var(--state-running-on-dark)",
  verified: "var(--ion)",
  consequence: "var(--vermilion)",
  transition: "#8E72FF",
  dim: "var(--quiet-metal-dim)"
};

/* Telemetry: labelled machine values (tokens, cost, elapsed, model, ids).
   Never decorative — every item must be a real measured value. */
function Telemetry({
  items = [],
  layout = "row",
  on = "light",
  size = "md",
  align = "left",
  style,
  ...rest
}) {
  const dark = on !== "light";
  const labelColor = dark ? "var(--quiet-metal)" : "var(--quiet-metal)";
  const valueColor = dark ? "var(--cold-white)" : "var(--void)";
  const fs = size === "sm" ? "var(--type-telemetry-sm)" : "var(--type-telemetry)";
  const wrapSx = {
    display: layout === "grid" ? "grid" : "flex",
    gridTemplateColumns: layout === "grid" ? "repeat(auto-fit,minmax(78px,1fr))" : undefined,
    flexDirection: layout === "stack" ? "column" : "row",
    flexWrap: layout === "row" ? "wrap" : undefined,
    alignItems: layout === "row" ? "baseline" : "stretch",
    gap: layout === "row" ? "0" : "var(--space-4)",
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: wrapSx
  }, rest), items.map((it, i) => {
    const tone = (dark ? TONE_MAP_DARK : TONE_MAP)[it.tone || "neutral"];
    const itemSx = layout === "row" ? {
      display: "flex",
      alignItems: "baseline",
      gap: "6px",
      padding: "0 var(--space-4)",
      borderLeft: i === 0 ? "none" : `1px solid ${dark ? "var(--border-on-dark)" : "var(--border-hairline)"}`,
      paddingLeft: i === 0 ? 0 : "var(--space-4)"
    } : {
      display: "flex",
      flexDirection: "column",
      gap: "3px",
      alignItems: align === "right" ? "flex-end" : "flex-start"
    };
    return /*#__PURE__*/React.createElement("div", {
      key: it.label + i,
      style: itemSx
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
        letterSpacing: "var(--tracking-label-tight)",
        textTransform: "uppercase",
        color: labelColor
      }
    }, it.label), /*#__PURE__*/React.createElement("span", {
      style: {
        font: `var(--weight-medium) ${fs}/1.1 var(--font-telemetry)`,
        letterSpacing: "var(--tracking-telemetry)",
        color: tone || valueColor,
        fontVariantNumeric: "tabular-nums"
      }
    }, it.value, it.unit ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: labelColor,
        marginLeft: "2px"
      }
    }, it.unit) : null));
  }));
}
Object.assign(__ds_scope, { Telemetry });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Telemetry.jsx", error: String((e && e.message) || e) }); }

// components/research/EvidencePlate.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* A bounded source or finding: claim, provenance, freshness, confidence,
   contradiction state, downstream consumers. Source text and citation
   controls stay crisp; only imagery may be dithered. */
function EvidencePlate({
  id,
  claim,
  source,
  provenance,
  freshness,
  confidence,
  contradiction,
  consumers = [],
  producedBy,
  slot = false,
  on = "dark",
  selected = false,
  onOpen,
  style,
  ...rest
}) {
  const dark = on !== "light";
  const fg = dark ? "var(--cold-white)" : "var(--void)";
  const dim = dark ? "var(--quiet-metal)" : "var(--text-secondary)";
  const edge = dark ? "var(--border-on-dark)" : "var(--border-rule)";
  const plateSx = {
    display: "flex",
    flexDirection: "column",
    background: dark ? "var(--void-raise)" : "var(--surface-plate)",
    border: `1px solid ${selected ? "var(--cobalt)" : edge}`,
    color: fg,
    cursor: onOpen ? "pointer" : "default",
    ...style
  };
  const rowSx = {
    display: "flex",
    justifyContent: "space-between",
    gap: "var(--space-4)",
    font: `var(--type-telemetry-sm)/1.4 var(--font-telemetry)`,
    color: dim
  };
  return /*#__PURE__*/React.createElement("article", _extends({
    onClick: onOpen,
    style: plateSx
  }, rest), slot ? /*#__PURE__*/React.createElement("div", {
    style: {
      height: "96px",
      borderBottom: `1px solid ${edge}`,
      color: dark ? "var(--quiet-metal-dim)" : "var(--rule)",
      background: "var(--dither-coarse)",
      display: "flex",
      alignItems: "flex-end",
      padding: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "var(--tracking-label-tight)",
      color: dim
    }
  }, "SOURCE IMAGE \xB7 NOT SUPPLIED")) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, id), /*#__PURE__*/React.createElement("span", {
    style: {
      color: contradiction ? "var(--vermilion)" : dark ? "var(--ion)" : "#4C7A00",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, contradiction ? "CONTRADICTED" : "CORROBORATED")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: `var(--weight-regular) var(--type-body)/1.45 var(--font-interface)`,
      textWrap: "pretty"
    }
  }, claim), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "3px",
      paddingTop: "var(--space-4)",
      borderTop: `1px solid ${edge}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", null, "SOURCE"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg,
      textAlign: "right"
    }
  }, source)), /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", null, "PROVENANCE"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg
    }
  }, provenance)), /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", null, "FRESHNESS"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg
    }
  }, freshness)), /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", null, "CONFIDENCE"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: dark ? "var(--state-running-on-dark)" : "var(--cobalt)"
    }
  }, confidence)), producedBy ? /*#__PURE__*/React.createElement("div", {
    style: rowSx
  }, /*#__PURE__*/React.createElement("span", null, "PRODUCED BY"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg
    }
  }, producedBy)) : null), consumers.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "4px",
      paddingTop: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1.6 var(--font-telemetry)`,
      color: dim,
      marginRight: "4px"
    }
  }, "USED BY"), consumers.map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      padding: "3px 5px",
      border: `1px solid ${edge}`,
      color: fg,
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, c))) : null));
}
Object.assign(__ds_scope, { EvidencePlate });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/research/EvidencePlate.jsx", error: String((e && e.message) || e) }); }

// components/research/GenerationRift.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The mutation seam between a baseline generation and a candidate. The seam is
   visible on purpose: improvement must never look magical. Carries changed
   rules, topology changes, metric deltas, regressions, rollback point and
   adoption state. */
function GenerationRift({
  baseline = {
    label: "GEN 07",
    metrics: []
  },
  candidate = {
    label: "GEN 08 · CANDIDATE",
    metrics: []
  },
  changes = [],
  regressions = [],
  rollback,
  adoption = "AWAITING APPROVAL",
  style,
  ...rest
}) {
  const sideSx = {
    flex: 1,
    minWidth: 0,
    padding: "var(--space-6)",
    display: "flex",
    flexDirection: "column",
    gap: "var(--space-5)"
  };
  const labelSx = {
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color: "var(--quiet-metal)"
  };
  const metricRow = (m, side) => /*#__PURE__*/React.createElement("div", {
    key: m.label,
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      gap: "var(--space-5)",
      padding: "6px 0",
      borderBottom: `1px solid var(--border-on-dark)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, m.label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)`,
      color: side === "candidate" ? "var(--cold-white)" : "var(--text-on-dark-secondary)",
      fontVariantNumeric: "tabular-nums"
    }
  }, m.value), side === "candidate" && m.delta ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: m.regression ? "var(--vermilion)" : "var(--ion)"
    }
  }, m.delta) : null));
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      display: "flex",
      background: "var(--void)",
      border: `1px solid var(--border-on-dark)`,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      ...sideSx,
      opacity: 0.78
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: labelSx
  }, "BASELINE \xB7 ", baseline.label), /*#__PURE__*/React.createElement("div", null, (baseline.metrics || []).map(m => metricRow(m, "baseline"))), rollback ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, "ROLLBACK POINT", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-on-dark-secondary)"
    }
  }, rollback)) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      width: "1px",
      background: "var(--ultraviolet)",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      bottom: 0,
      left: "1px",
      width: "6px",
      background: "var(--hatch-45)",
      color: "var(--ultraviolet)",
      opacity: 0.5
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: sideSx
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...labelSx,
      color: "var(--ultraviolet)"
    }
  }, candidate.label), /*#__PURE__*/React.createElement("div", null, (candidate.metrics || []).map(m => metricRow(m, "candidate"))), changes.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: labelSx
  }, "CHANGED"), changes.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      gap: "8px",
      font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`,
      color: "var(--text-on-dark-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ultraviolet)",
      flex: "none"
    }
  }, c.kind || "RULE"), /*#__PURE__*/React.createElement("span", null, c.text || c)))) : null, regressions.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "4px",
      paddingTop: "var(--space-4)",
      borderTop: `1px solid var(--vermilion)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...labelSx,
      color: "var(--vermilion)"
    }
  }, "NEW REGRESSIONS \xB7 ", regressions.length), regressions.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`,
      color: "var(--cold-white)"
    }
  }, r))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "var(--tracking-label-tight)",
      color: "var(--cold-white)",
      border: `1px solid var(--border-on-dark-strong)`,
      padding: "6px 8px",
      alignSelf: "flex-start"
    }
  }, "ADOPTION \xB7 ", adoption)));
}
Object.assign(__ds_scope, { GenerationRift });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/research/GenerationRift.jsx", error: String((e && e.message) || e) }); }

// components/research/ObjectiveAperture.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Goal intake. One high-contrast aperture for the objective; constraints,
   documents, definition of done and open ambiguities orbit it by importance.
   The prompt dominates — setup controls stay secondary. */
function ObjectiveAperture({
  mission,
  goal,
  placeholder = "State the objective, its boundaries, and what would count as done.",
  constraints = [],
  documents = [],
  definitionOfDone = [],
  ambiguities = [],
  on = "field",
  actions,
  onGoalChange,
  style,
  ...rest
}) {
  const field = on === "field";
  const fg = field ? "var(--cold-white)" : on === "dark" ? "var(--cold-white)" : "var(--void)";
  const dim = field ? "var(--text-on-field-secondary)" : "var(--quiet-metal)";
  const edge = field ? "var(--border-on-field)" : on === "dark" ? "var(--border-on-dark)" : "var(--border-rule)";
  const wrapSx = {
    background: field ? "var(--cobalt)" : on === "dark" ? "var(--void)" : "var(--mineral-white)",
    color: fg,
    padding: "var(--space-10) var(--space-8) 0",
    ...style
  };
  const columns = [{
    label: "CONSTRAINTS",
    items: constraints
  }, {
    label: "CONTEXT",
    items: documents
  }, {
    label: "DEFINITION OF DONE",
    items: definitionOfDone
  }, {
    label: "OPEN AMBIGUITY",
    items: ambiguities,
    warn: true
  }];
  return /*#__PURE__*/React.createElement("section", _extends({
    style: wrapSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)",
      marginBottom: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Aperture, {
    size: 14,
    tone: "inherit",
    state: "converging"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: dim
    }
  }, "OBJECTIVE APERTURE"), mission ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: dim
    }
  }, mission) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: `1px solid ${edge}`,
      borderBottom: `1px solid ${edge}`,
      padding: "var(--space-8) 0"
    }
  }, onGoalChange ? /*#__PURE__*/React.createElement("textarea", {
    value: goal,
    onChange: onGoalChange,
    placeholder: placeholder,
    rows: 3,
    style: {
      width: "100%",
      background: "transparent",
      border: "none",
      outline: "none",
      resize: "none",
      color: fg,
      font: `var(--weight-regular) var(--type-display-3)/var(--leading-display) var(--font-display)`,
      letterSpacing: "var(--tracking-display)"
    }
  }) : /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "24ch",
      font: `var(--weight-regular) var(--type-display-2)/var(--leading-display) var(--font-display)`,
      letterSpacing: "var(--tracking-display)",
      textWrap: "pretty"
    }
  }, goal || placeholder)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))",
      borderBottom: `1px solid ${edge}`
    }
  }, columns.map((c, ci) => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    style: {
      padding: "var(--space-6) var(--space-6) var(--space-7) 0",
      borderLeft: ci === 0 ? "none" : `1px solid ${edge}`,
      paddingLeft: ci === 0 ? 0 : "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: c.warn && c.items.length ? field ? "var(--cold-white)" : "var(--vermilion)" : dim,
      marginBottom: "var(--space-4)",
      display: "flex",
      gap: "6px"
    }
  }, c.label, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: dim
    }
  }, c.items.length)), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "flex",
      flexDirection: "column",
      gap: "6px"
    }
  }, c.items.map((it, i) => {
    const text = typeof it === "string" ? it : it.name || it.q;
    const meta = typeof it === "string" ? null : it.size || it.status;
    return /*#__PURE__*/React.createElement("li", {
      key: i,
      style: {
        display: "flex",
        gap: "8px",
        justifyContent: "space-between",
        font: `var(--weight-regular) var(--type-body-sm)/1.4 var(--font-interface)`,
        color: fg
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        textWrap: "pretty"
      }
    }, text), meta ? /*#__PURE__*/React.createElement("span", {
      style: {
        font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`,
        color: dim,
        flex: "none"
      }
    }, meta) : null);
  }))))), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      padding: "var(--space-7) 0"
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { ObjectiveAperture });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/research/ObjectiveAperture.jsx", error: String((e && e.message) || e) }); }

// components/shell/CLISheet.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const KIND = {
  command: {
    color: "var(--cold-white)",
    prefix: "aos ›"
  },
  output: {
    color: "var(--text-on-dark-secondary)",
    prefix: ""
  },
  meta: {
    color: "var(--quiet-metal)",
    prefix: ""
  },
  ok: {
    color: "var(--ion)",
    prefix: ""
  },
  error: {
    color: "var(--vermilion)",
    prefix: ""
  },
  handoff: {
    color: "#8E72FF",
    prefix: ""
  }
};

/* Keyboard-first command surface. It always states the working context and
   whether an action is simulated. It is not a decorative terminal. */
function CLISheet({
  expanded = false,
  lines = [],
  context = "mission/—",
  prompt = "",
  simulated = true,
  hint = "⌃` TOGGLE",
  onToggle,
  onPromptChange,
  onSubmit,
  style,
  ...rest
}) {
  const sheetSx = {
    display: "flex",
    flexDirection: "column",
    background: "var(--void)",
    borderTop: `1px solid ${expanded ? "var(--border-on-dark-strong)" : "var(--border-on-dark)"}`,
    height: expanded ? "var(--cli-expanded-height)" : "var(--cli-collapsed-height)",
    transition: "height var(--dur-branch) var(--ease-instrument)",
    overflow: "hidden",
    ...style
  };
  const barSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-5)",
    height: "var(--cli-collapsed-height)",
    flex: "none",
    padding: "0 var(--space-5)",
    borderBottom: expanded ? `1px solid var(--border-on-dark)` : "none",
    font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
    color: "var(--quiet-metal)",
    cursor: "pointer"
  };
  const last = lines.length ? lines[lines.length - 1] : null;
  return /*#__PURE__*/React.createElement("section", _extends({
    style: sheetSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: barSx,
    onClick: onToggle
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-on-dark-secondary)",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, "// CLI"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--quiet-metal)"
    }
  }, context), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: "0 5px",
      border: `1px solid ${simulated ? "var(--quiet-metal)" : "var(--ion)"}`,
      color: simulated ? "var(--quiet-metal)" : "var(--ion)",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, simulated ? "SIMULATED" : "EXECUTES"), !expanded && last ? /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      color: KIND[last.kind].color
    }
  }, last.kind === "command" ? "aos › " : "", last.text) : /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--quiet-metal-dim)"
    }
  }, hint)), expanded ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflow: "auto",
      padding: "var(--space-4) var(--space-5)",
      display: "flex",
      flexDirection: "column",
      gap: "3px"
    }
  }, lines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      gap: "8px",
      font: `var(--weight-regular) var(--type-telemetry)/1.45 var(--font-telemetry)`,
      color: KIND[l.kind] ? KIND[l.kind].color : KIND.output.color,
      whiteSpace: "pre-wrap"
    }
  }, l.kind === "command" ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--state-running-on-dark)",
      flex: "none"
    }
  }, "aos \u203A") : null, /*#__PURE__*/React.createElement("span", null, l.text)))), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onSubmit && onSubmit(prompt);
    },
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      flex: "none",
      height: "36px",
      padding: "0 var(--space-5)",
      borderTop: `1px solid var(--border-on-dark)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--state-running-on-dark)",
      font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)`
    }
  }, "aos \u203A"), /*#__PURE__*/React.createElement("input", {
    value: prompt,
    onChange: e => onPromptChange && onPromptChange(e.target.value),
    placeholder: "swarm inspect --agent \u2026",
    style: {
      flex: 1,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--cold-white)",
      font: `var(--weight-regular) var(--type-telemetry)/1 var(--font-telemetry)`
    }
  }))) : null);
}
Object.assign(__ds_scope, { CLISheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/shell/CLISheet.jsx", error: String((e && e.message) || e) }); }

// components/shell/ContextInspector.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const ROW_TONE = {
  neutral: "var(--cold-white)",
  active: "var(--state-running-on-dark)",
  verified: "var(--ion)",
  consequence: "var(--vermilion)",
  transition: "#8E72FF",
  dim: "var(--quiet-metal)"
};

/* Conditional detail region for the current selection. Renders nothing when
   `open` is false — metadata never crowds the work field by default. */
function ContextInspector({
  open = true,
  kind = "AGENT",
  title,
  subtitle,
  sections = [],
  actions,
  children,
  onClose,
  style,
  ...rest
}) {
  if (!open) return null;
  const panelSx = {
    display: "flex",
    flexDirection: "column",
    width: "var(--inspector-width)",
    flex: "none",
    background: "var(--void-raise)",
    borderLeft: `1px solid var(--border-on-dark-strong)`,
    height: "100%",
    overflow: "hidden",
    ...style
  };
  return /*#__PURE__*/React.createElement("aside", _extends({
    style: panelSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      padding: "var(--space-5)",
      borderBottom: `1px solid var(--border-on-dark)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--quiet-metal)"
    }
  }, kind), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    style: {
      background: "transparent",
      border: "none",
      color: "var(--quiet-metal)",
      cursor: "pointer",
      font: `var(--type-telemetry)/1 var(--font-telemetry)`,
      padding: 0
    }
  }, "CLOSE \xD7")), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "var(--space-4) 0 0",
      font: `var(--weight-medium) var(--type-title-2)/var(--leading-title) var(--font-display)`,
      letterSpacing: "var(--tracking-title)",
      color: "var(--cold-white)"
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "6px 0 0",
      font: `var(--weight-regular) var(--type-telemetry)/1.45 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, subtitle) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflow: "auto"
    }
  }, sections.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.label,
    style: {
      borderBottom: `1px solid var(--border-on-dark)`,
      padding: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--quiet-metal-dim)",
      marginBottom: "var(--space-4)"
    }
  }, sec.label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, (sec.rows || []).map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.k + i,
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1.3 var(--font-telemetry)`,
      color: "var(--quiet-metal)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, r.k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry)/1.3 var(--font-telemetry)`,
      color: ROW_TONE[r.tone || "neutral"],
      textAlign: "right",
      fontVariantNumeric: "tabular-nums"
    }
  }, r.v))), sec.body ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: `var(--weight-regular) var(--type-body-sm)/var(--leading-body) var(--font-interface)`,
      color: "var(--text-on-dark-secondary)"
    }
  }, sec.body) : null, sec.children || null))), children), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      display: "flex",
      gap: "var(--space-3)",
      padding: "var(--space-5)",
      borderTop: `1px solid var(--border-on-dark-strong)`
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { ContextInspector });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/shell/ContextInspector.jsx", error: String((e && e.message) || e) }); }

// components/shell/DecisionGate.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Bottom strip, shown only when a decision changes this run or a future
   generation. Every choice states action, consequence, reversibility and
   required authority. Self-modifying or destructive choices are vermilion. */
function DecisionGate({
  open = true,
  prompt,
  detail,
  authority = "OPERATOR",
  choices = [],
  onChoose,
  style,
  ...rest
}) {
  if (!open) return null;
  const stripSx = {
    display: "flex",
    alignItems: "stretch",
    gap: 0,
    background: "var(--void-plate)",
    borderTop: `1px solid var(--vermilion)`,
    ...style
  };
  return /*#__PURE__*/React.createElement("section", _extends({
    style: stripSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: "var(--space-5)",
      display: "flex",
      flexDirection: "column",
      gap: "6px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--vermilion)"
    }
  }, "// DECISION GATE"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, "AUTHORITY REQUIRED \xB7 ", authority)), /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--weight-medium) var(--type-title-3)/1.25 var(--font-display)`,
      color: "var(--cold-white)",
      letterSpacing: "var(--tracking-title)"
    }
  }, prompt), detail ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--weight-regular) var(--type-body-sm)/var(--leading-body) var(--font-interface)`,
      color: "var(--text-on-dark-secondary)",
      maxWidth: "var(--measure-body)"
    }
  }, detail) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flex: "none"
    }
  }, choices.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    style: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      width: "216px",
      padding: "var(--space-5)",
      borderLeft: `1px solid var(--border-on-dark-strong)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "4px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1.4 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, c.consequence), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "var(--tracking-label-tight)",
      color: c.reversible ? "var(--ion)" : "var(--vermilion)"
    }
  }, c.reversible ? "REVERSIBLE" : "IRREVERSIBLE")), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    on: "dark",
    variant: c.variant || "secondary",
    size: "sm",
    full: true,
    onClick: () => onChoose && onChoose(c)
  }, c.label)))));
}
Object.assign(__ds_scope, { DecisionGate });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/shell/DecisionGate.jsx", error: String((e && e.message) || e) }); }

// components/shell/GlobalRail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SURFACE = {
  dark: {
    bg: "var(--void)",
    fg: "var(--cold-white)",
    dim: "var(--quiet-metal)",
    edge: "var(--border-on-dark)"
  },
  light: {
    bg: "var(--mineral-white)",
    fg: "var(--void)",
    dim: "var(--quiet-metal)",
    edge: "var(--border-rule)"
  },
  field: {
    bg: "var(--cobalt)",
    fg: "var(--cold-white)",
    dim: "var(--text-on-field-secondary)",
    edge: "var(--border-on-field)"
  }
};

/* The instrument rail. Edge to edge, one hairline, no marketing header behaviour. */
function GlobalRail({
  route = "SWARM",
  routes = ["MISSIONS", "INTAKE", "SWARM", "EVIDENCE", "SYNTHESIS", "EVOLUTION", "CAPABILITIES", "MEMORY"],
  mission,
  mode = "ILLUSTRATIVE",
  connection = {
    state: "ok",
    label: "4 PROVIDERS"
  },
  onRoute,
  onCommand,
  on = "dark",
  style,
  ...rest
}) {
  const s = SURFACE[on] || SURFACE.dark;
  const railSx = {
    display: "flex",
    alignItems: "stretch",
    height: "var(--rail-height)",
    background: s.bg,
    borderBottom: `1px solid ${s.edge}`,
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color: s.dim,
    ...style
  };
  const lockupSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-3)",
    padding: "0 var(--space-5)",
    borderRight: `1px solid ${s.edge}`,
    color: s.fg
  };
  const navSx = {
    display: "flex",
    alignItems: "stretch",
    flex: 1,
    minWidth: 0,
    overflow: "hidden"
  };
  const rightSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-5)",
    padding: "0 var(--space-5)",
    borderLeft: `1px solid ${s.edge}`
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    style: railSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: lockupSx
  }, /*#__PURE__*/React.createElement(__ds_scope.Aperture, {
    size: 16,
    tone: "inherit",
    state: "running"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-semibold) 17px/1 var(--font-display)`,
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, "AOS")), /*#__PURE__*/React.createElement("nav", {
    style: navSx
  }, routes.map(r => {
    const active = r === route;
    return /*#__PURE__*/React.createElement("button", {
      key: r,
      type: "button",
      onClick: () => onRoute && onRoute(r),
      style: {
        appearance: "none",
        background: active ? on === "field" ? "rgba(250,251,255,0.16)" : "var(--cobalt)" : "transparent",
        color: active ? "var(--cold-white)" : s.dim,
        border: "none",
        borderRight: `1px solid ${s.edge}`,
        padding: "0 var(--space-5)",
        font: "inherit",
        letterSpacing: "inherit",
        textTransform: "inherit",
        cursor: "pointer",
        transition: "color var(--dur-state) var(--ease-instrument),background var(--dur-state) var(--ease-instrument)"
      }
    }, r);
  })), /*#__PURE__*/React.createElement("div", {
    style: rightSx
  }, mission ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "0.04em",
      color: s.dim
    }
  }, mission) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "0 6px",
      height: "18px",
      border: `1px solid ${mode === "LIVE" ? "var(--ion)" : "var(--quiet-metal)"}`,
      color: mode === "LIVE" ? on === "light" ? "#4C7A00" : "var(--ion)" : s.dim,
      font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, mode), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "5px",
      height: "5px",
      borderRadius: "var(--radius-aperture)",
      background: connection.state === "ok" ? "var(--ion)" : connection.state === "degraded" ? "var(--ultraviolet)" : "var(--vermilion)"
    }
  }), connection.label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onCommand,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-3)",
      height: "24px",
      padding: "0 8px",
      background: "transparent",
      border: `1px solid ${s.edge}`,
      color: s.fg,
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      letterSpacing: "0.04em",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Aperture, {
    size: 11,
    tone: "inherit"
  }), "\u2318K")));
}
Object.assign(__ds_scope, { GlobalRail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/shell/GlobalRail.jsx", error: String((e && e.message) || e) }); }

// components/swarm/AgentNode.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const EDGE = {
  running: "var(--cobalt)",
  waiting: "var(--quiet-metal-dim)",
  blocked: "var(--ultraviolet)",
  failed: "var(--vermilion)",
  complete: "var(--ion)",
  dormant: "var(--quiet-metal-dim)",
  handoff: "var(--ultraviolet)",
  gate: "var(--vermilion)"
};

/* One owned task in the hierarchy. Carries only the facts needed to read the
   causal path: role, owner, harness/model, state, tokens, cost, elapsed.
   Everything else belongs in the ContextInspector. */
function AgentNode({
  agent,
  selected = false,
  onPath = false,
  dim = false,
  compact = false,
  width,
  onSelect,
  style,
  ...rest
}) {
  const a = agent || {};
  const accent = EDGE[a.state] || EDGE.waiting;
  const nodeSx = {
    display: "flex",
    flexDirection: "column",
    gap: compact ? "4px" : "6px",
    width: width || (compact ? "186px" : "212px"),
    padding: compact ? "8px 10px" : "10px 12px",
    textAlign: "left",
    background: selected ? "var(--cobalt)" : onPath ? "var(--void-plate)" : "var(--void-raise)",
    border: `1px solid ${selected ? "var(--cold-white)" : onPath ? accent : "var(--border-on-dark)"}`,
    borderLeft: `${selected ? 1 : 3}px solid ${selected ? "var(--cold-white)" : accent}`,
    borderRadius: "var(--radius-none)",
    color: selected ? "var(--cold-white)" : "var(--text-on-dark)",
    opacity: dim ? "var(--opacity-recede)" : 1,
    cursor: onSelect ? "pointer" : "default",
    transition: "opacity var(--dur-state) var(--ease-instrument),background var(--dur-state) var(--ease-instrument),border-color var(--dur-state) var(--ease-instrument)",
    ...style
  };
  const metaSx = {
    font: `var(--weight-regular) var(--type-telemetry-sm)/1.25 var(--font-telemetry)`,
    color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)",
    letterSpacing: "var(--tracking-telemetry)",
    display: "flex",
    gap: "6px",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: onSelect ? "button" : undefined,
    onClick: onSelect ? () => onSelect(a.id) : undefined,
    style: nodeSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) ${compact ? "12px" : "13px"}/1.1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label-tight)",
      textTransform: "uppercase",
      color: "var(--cold-white)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, a.role), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal-dim)"
    }
  }, a.id)), /*#__PURE__*/React.createElement("div", {
    style: metaSx
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: selected ? "var(--cold-white)" : "var(--text-on-dark-secondary)"
    }
  }, a.harness), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "/"), /*#__PURE__*/React.createElement("span", null, a.model)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StateBadge, {
    state: a.state,
    on: selected ? "field" : "dark",
    form: "bare"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) 10px/1 var(--font-telemetry)`,
      color: selected ? "var(--cold-white)" : "var(--text-on-dark-secondary)",
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap"
    }
  }, a.tokens, " \xB7 ", a.cost, " \xB7 ", a.elapsed)), !compact && (a.evidence || a.deps) ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      paddingTop: "4px",
      borderTop: `1px solid ${selected ? "var(--border-on-field)" : "var(--border-on-dark)"}`
    }
  }, a.evidence != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)"
    }
  }, "EVID ", a.evidence) : null, a.deps != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)"
    }
  }, "DEPS ", a.deps) : null) : null);
}
Object.assign(__ds_scope, { AgentNode });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/swarm/AgentNode.jsx", error: String((e && e.message) || e) }); }

// components/swarm/AgentTrace.jsx
try { (() => {
const TRACE = {
  stable: {
    stroke: "var(--trace-stable-on-dark)",
    dash: null,
    opacity: 1
  },
  waiting: {
    stroke: "var(--trace-idle)",
    dash: "4 4",
    opacity: 0.9
  },
  verified: {
    stroke: "var(--trace-verified)",
    dash: null,
    opacity: 1
  },
  conflict: {
    stroke: "var(--trace-conflict)",
    dash: "6 3",
    opacity: 1
  },
  handoff: {
    stroke: "var(--trace-handoff)",
    dash: null,
    opacity: 1
  },
  dormant: {
    stroke: "var(--trace-idle)",
    dash: "1 4",
    opacity: 0.55
  },
  dependency: {
    stroke: "var(--quiet-metal)",
    dash: "2 3",
    opacity: 0.8
  }
};

/* A directional line with source, destination, state and temporal character.
   Renders SVG nodes in the parent's pixel coordinate space: place inside an
   <svg> (AccelerationField does this), or pass `wrap` for a standalone
   diagram. Orthogonal elbows only — direction must never be ambiguous. */
function AgentTrace({
  from = {
    x: 40,
    y: 300
  },
  to = {
    x: 200,
    y: 120
  },
  state = "stable",
  kind = "delegation",
  throughput = 0.4,
  label,
  wrap = false,
  width = 320,
  height = 360,
  viewBox
}) {
  const t = kind === "dependency" ? TRACE.dependency : TRACE[state] || TRACE.stable;
  const mid = from.y + (to.y - from.y) / 2;
  const d = kind === "dependency" ? `M${from.x} ${from.y} H${from.x + (to.x - from.x) / 2} V${to.y} H${to.x}` : `M${from.x} ${from.y} V${mid} H${to.x} V${to.y}`;
  const sw = 1 + Math.max(0, Math.min(1, throughput)) * 2.2;
  const body = /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: t.stroke,
    strokeWidth: sw,
    strokeDasharray: t.dash || undefined,
    strokeOpacity: t.opacity
  }), state === "verified" ? /*#__PURE__*/React.createElement("circle", {
    cx: to.x,
    cy: to.y,
    r: "3",
    fill: "var(--ion)"
  }) : null, state === "conflict" ? /*#__PURE__*/React.createElement("g", {
    stroke: "var(--vermilion)",
    strokeWidth: "1.5"
  }, /*#__PURE__*/React.createElement("path", {
    d: `M${to.x - 4} ${to.y - 4} L${to.x + 4} ${to.y + 4}`
  }), /*#__PURE__*/React.createElement("path", {
    d: `M${to.x + 4} ${to.y - 4} L${to.x - 4} ${to.y + 4}`
  })) : null, state === "handoff" ? /*#__PURE__*/React.createElement("rect", {
    x: to.x - 1.5,
    y: mid - 6,
    width: "3",
    height: "12",
    fill: "var(--ultraviolet)"
  }) : null, label ? /*#__PURE__*/React.createElement("text", {
    x: to.x + 7,
    y: mid - 4,
    fill: "var(--quiet-metal)",
    style: {
      font: "400 10px var(--font-telemetry)",
      letterSpacing: "0.08em"
    }
  }, label) : null);
  if (!wrap) return body;
  return /*#__PURE__*/React.createElement("svg", {
    width: width,
    height: height,
    viewBox: viewBox || `0 0 ${width} ${height}`,
    style: {
      display: "block",
      overflow: "visible"
    }
  }, body);
}
Object.assign(__ds_scope, { AgentTrace });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/swarm/AgentTrace.jsx", error: String((e && e.message) || e) }); }

// components/swarm/ClusterAggregate.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DIST = {
  running: "var(--cobalt)",
  complete: "var(--ion)",
  waiting: "var(--quiet-metal-dim)",
  failed: "var(--vermilion)",
  blocked: "var(--ultraviolet)"
};

/* Dormant or repetitive branches, aggregated. The field never draws unlimited
   nodes: it draws the active path and bundles the rest into named clusters
   with counts, a state distribution, and a way back in. */
function ClusterAggregate({
  label,
  count = 0,
  distribution = {
    running: 0,
    complete: 0,
    waiting: 0,
    failed: 0
  },
  tokens,
  cost,
  owner,
  width,
  onExpand,
  style,
  ...rest
}) {
  const total = Object.values(distribution).reduce((a, b) => a + b, 0) || 1;
  const clusterSx = {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    width: width || "196px",
    padding: "8px 10px",
    background: "var(--void)",
    border: `1px solid var(--border-on-dark)`,
    borderLeft: "3px solid var(--quiet-metal-dim)",
    cursor: onExpand ? "pointer" : "default",
    textAlign: "left",
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: onExpand ? "button" : undefined,
    onClick: onExpand,
    style: clusterSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) 12px/1.1 var(--font-interface)`,
      letterSpacing: "var(--tracking-label-tight)",
      textTransform: "uppercase",
      color: "var(--text-on-dark-secondary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)`,
      color: "var(--cold-white)"
    }
  }, "\xD7", count)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "3px",
      gap: "1px",
      background: "var(--graphite-edge)"
    }
  }, Object.keys(distribution).map(k => distribution[k] ? /*#__PURE__*/React.createElement("span", {
    key: k,
    style: {
      width: `${distribution[k] / total * 100}%`,
      background: DIST[k]
    }
  }) : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-3)",
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, /*#__PURE__*/React.createElement("span", null, owner ? `← ${owner}` : "AGGREGATED"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: "tabular-nums"
    }
  }, tokens, cost ? ` · ${cost}` : "")), onExpand ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--state-running-on-dark)",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, "EXPAND IN PLACE \u2192") : null);
}
Object.assign(__ds_scope, { ClusterAggregate });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/swarm/ClusterAggregate.jsx", error: String((e && e.message) || e) }); }

// components/swarm/AccelerationField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DEFAULT_STAGES = ["FRONTIER", "CONVERGENCE", "MUTATION", "SWARM", "CONSTRAINT"];
const LADDER = 64;

/* The central working surface. Geometry is causal, not physical: depth 0 is the
   constrained objective at the bottom, higher depth rises toward the frontier.
   Supply `depth` (+ optional `lane` 0..1) per item and the field places it;
   explicit `x`/`y` percentages override. Dormant branches come in as clusters. */
function AccelerationField({
  items = [],
  edges = [],
  selectedId,
  onSelect,
  stages = DEFAULT_STAGES,
  activePath = [],
  height = 560,
  grid = true,
  caption,
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  const [box, setBox] = React.useState({
    w: 1200,
    h: typeof height === "number" ? height : 560
  });
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setBox({
      w: el.clientWidth,
      h: el.clientHeight
    });
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const maxDepth = Math.max(1, ...items.map(i => i.depth || 0));
  const byDepth = {};
  items.forEach(i => {
    const d = i.depth || 0;
    (byDepth[d] = byDepth[d] || []).push(i);
  });
  const pos = {};
  items.forEach(i => {
    const d = i.depth || 0;
    const row = byDepth[d];
    const lane = i.lane != null ? i.lane : (row.indexOf(i) + 1) / (row.length + 1);
    const px = i.x != null ? i.x / 100 * box.w : LADDER + 120 + lane * Math.max(120, box.w - LADDER - 240);
    const py = i.y != null ? i.y / 100 * box.h : box.h - 52 - d / maxDepth * Math.max(80, box.h - 104);
    pos[i.id] = {
      x: Math.round(px),
      y: Math.round(py)
    };
  });
  const fieldSx = {
    position: "relative",
    height: typeof height === "number" ? `${height}px` : height,
    background: "var(--void)",
    backgroundImage: grid ? "linear-gradient(to right,rgba(35,35,44,0.55) 0 1px,transparent 1px 100%),linear-gradient(to bottom,rgba(35,35,44,0.55) 0 1px,transparent 1px 100%)" : "none",
    backgroundSize: "48px 48px",
    overflow: "hidden",
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: ref,
    style: fieldSx
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: `0 auto 0 0`,
      width: `${LADDER}px`,
      borderRight: `1px solid var(--border-on-dark)`,
      display: "flex",
      flexDirection: "column",
      zIndex: 3,
      background: "linear-gradient(to right,var(--void) 60%,transparent)"
    }
  }, stages.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s,
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex",
      alignItems: "center",
      gap: "6px",
      paddingLeft: "var(--space-4)",
      borderTop: i === 0 ? "none" : `1px solid rgba(35,35,44,0.7)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "5px",
      height: "1px",
      background: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-regular) 9px/1 var(--font-telemetry)`,
      letterSpacing: "0.1em",
      color: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)",
      writingMode: "vertical-rl",
      transform: "rotate(180deg)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      maxHeight: "100%"
    }
  }, s)))), /*#__PURE__*/React.createElement("svg", {
    width: box.w,
    height: box.h,
    viewBox: `0 0 ${box.w} ${box.h}`,
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 1
    }
  }, edges.map((e, i) => {
    const f = pos[e.from];
    const t = pos[e.to];
    if (!f || !t) return null;
    const onPath = activePath.includes(e.from) && activePath.includes(e.to);
    return /*#__PURE__*/React.createElement(__ds_scope.AgentTrace, {
      key: i,
      from: f,
      to: t,
      state: e.state || "stable",
      kind: e.kind || "delegation",
      throughput: onPath ? e.throughput != null ? e.throughput : 0.6 : 0.1,
      label: e.label
    });
  })), items.map(i => {
    const p = pos[i.id];
    const wrapSx = {
      position: "absolute",
      left: `${p.x}px`,
      top: `${p.y}px`,
      transform: "translate(-50%,-50%)",
      zIndex: selectedId === i.id ? 4 : 2
    };
    return /*#__PURE__*/React.createElement("div", {
      key: i.id,
      style: wrapSx
    }, i.kind === "cluster" ? /*#__PURE__*/React.createElement(__ds_scope.ClusterAggregate, {
      label: i.label,
      count: i.count,
      distribution: i.distribution,
      tokens: i.tokens,
      cost: i.cost,
      owner: i.owner,
      onExpand: onSelect ? () => onSelect(i.id) : undefined
    }) : /*#__PURE__*/React.createElement(__ds_scope.AgentNode, {
      agent: i,
      selected: selectedId === i.id,
      onPath: activePath.includes(i.id),
      dim: activePath.length > 0 && !activePath.includes(i.id),
      compact: i.compact,
      onSelect: onSelect
    }));
  }), caption ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: "var(--space-5)",
      bottom: "var(--space-4)",
      zIndex: 3,
      font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal-dim)",
      letterSpacing: "var(--tracking-label-tight)"
    }
  }, caption) : null);
}
Object.assign(__ds_scope, { AccelerationField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/swarm/AccelerationField.jsx", error: String((e && e.message) || e) }); }

// components/swarm/ConvergenceCore.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The singularity component, as a functional convergence state. It says how
   many branches, agents, models, evidence items and generations are
   compressing into one decision — and it opens back into those inputs.
   It never hides provenance. */
function ConvergenceCore({
  size = 200,
  branches = [],
  agents = 0,
  models = 0,
  evidence = 0,
  generation,
  confidence,
  objections = 0,
  expanded = false,
  onToggle,
  legend = true,
  style,
  ...rest
}) {
  const n = branches.length || 6;
  const r = size / 2;
  const ring = r * 0.44;
  const ticks = Array.from({
    length: n
  }, (_, i) => {
    const b = branches[i] || {
      weight: 0.5,
      state: "stable"
    };
    const ang = -150 + i * 300 / Math.max(1, n - 1); // asymmetric: paths enter from the left arc
    const rad = ang * Math.PI / 180;
    const outer = r * 0.98;
    const inner = ring + 6;
    return {
      x1: r + Math.cos(rad) * outer,
      y1: r + Math.sin(rad) * outer,
      x2: r + Math.cos(rad) * inner,
      y2: r + Math.sin(rad) * inner,
      w: 0.8 + (b.weight || 0.5) * 2.6,
      stroke: b.state === "conflict" ? "var(--vermilion)" : b.state === "verified" ? "var(--ion)" : b.state === "handoff" ? "var(--ultraviolet)" : "var(--trace-stable-on-dark)",
      opacity: b.dormant ? 0.3 : 1
    };
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-11)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    onClick: onToggle,
    style: {
      display: "block",
      flex: "none",
      cursor: onToggle ? "pointer" : "default",
      overflow: "visible"
    }
  }, ticks.map((t, i) => /*#__PURE__*/React.createElement("line", {
    key: i,
    x1: t.x1,
    y1: t.y1,
    x2: t.x2,
    y2: t.y2,
    stroke: t.stroke,
    strokeWidth: t.w,
    strokeOpacity: t.opacity
  })), /*#__PURE__*/React.createElement("circle", {
    cx: r,
    cy: r,
    r: ring,
    fill: "none",
    stroke: "var(--cold-white)",
    strokeWidth: "1",
    strokeDasharray: `${2 * Math.PI * ring * 0.74} ${2 * Math.PI * ring * 0.26}`,
    transform: `rotate(-132 ${r} ${r})`
  }), /*#__PURE__*/React.createElement("circle", {
    cx: r,
    cy: r,
    r: "2.5",
    fill: "var(--cold-white)"
  }), /*#__PURE__*/React.createElement("line", {
    x1: r + ring + 4,
    y1: r,
    x2: size + 8,
    y2: r,
    stroke: "var(--ultraviolet)",
    strokeWidth: "1.5"
  }), /*#__PURE__*/React.createElement("text", {
    x: size + 12,
    y: r + 3,
    fill: "var(--ultraviolet)",
    style: {
      font: "500 10px var(--font-telemetry)",
      letterSpacing: "0.08em"
    }
  }, generation ? `GEN ${generation}` : "NEXT GEN"), /*#__PURE__*/React.createElement("text", {
    x: r,
    y: r - ring - 10,
    textAnchor: "middle",
    fill: "var(--quiet-metal)",
    style: {
      font: "400 10px var(--font-telemetry)",
      letterSpacing: "0.12em"
    }
  }, "CONVERGENCE")), legend ? /*#__PURE__*/React.createElement(__ds_scope.Telemetry, {
    on: "dark",
    layout: "grid",
    style: {
      flex: 1,
      minWidth: 0
    },
    items: [{
      label: "Branches",
      value: n
    }, {
      label: "Agents",
      value: agents
    }, {
      label: "Models",
      value: models
    }, {
      label: "Evidence",
      value: evidence,
      tone: "verified"
    }, {
      label: "Confidence",
      value: confidence,
      tone: "active"
    }, {
      label: "Objections",
      value: objections,
      tone: objections ? "consequence" : "dim"
    }]
  }) : null), expanded && branches.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: `1px solid var(--border-on-dark-strong)`
    }
  }, branches.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.label,
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "var(--space-5)",
      padding: "8px 0",
      borderBottom: `1px solid var(--border-on-dark)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-medium) var(--type-body-sm)/1.3 var(--font-interface)`,
      color: "var(--cold-white)"
    }
  }, b.label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "var(--space-5)",
      font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
      color: "var(--quiet-metal)"
    }
  }, /*#__PURE__*/React.createElement("span", null, b.source), /*#__PURE__*/React.createElement("span", {
    style: {
      color: b.state === "conflict" ? "var(--vermilion)" : "var(--text-on-dark-secondary)"
    }
  }, b.state === "conflict" ? "OBJECTION" : `CONF ${b.confidence}`))))) : null);
}
Object.assign(__ds_scope, { ConvergenceCore });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/swarm/ConvergenceCore.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/MissionScreens.jsx
try { (() => {
const {
  ObjectiveAperture,
  Button,
  StateBadge,
  Telemetry,
  SectionLabel,
  ContextInspector,
  Aperture
} = window.AOSDesignSystem_20e4c5;
const DM = window.AOSDATA;
function MissionsScreen({
  sel,
  setSel,
  run,
  go,
  RouteHeader
}) {
  const active = DM.missions[0];
  const rest = DM.missions.slice(1);
  const selected = DM.missions.find(m => m.id === sel);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Missions",
    index: "01/08",
    title: "Four objectives, one accelerating.",
    telemetry: [{
      label: "Active",
      value: "1"
    }, {
      label: "Agents",
      value: "87"
    }, {
      label: "Spend 24h",
      value: "$45.85",
      tone: "active"
    }, {
      label: "Generation",
      value: "07 → 08",
      tone: "transition"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => go("SWARM"),
    style: {
      flex: "1.25",
      background: "var(--cobalt)",
      padding: "var(--space-10) var(--gutter-page)",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      cursor: "pointer",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Aperture, {
    size: 16,
    tone: "white",
    state: "running"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1 var(--font-telemetry)",
      letterSpacing: "0.1em",
      color: "var(--text-on-field-secondary)"
    }
  }, active.id, " \xB7 GEN ", active.gen, " \xB7 OPEN GATES ", active.gates)), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: "400 clamp(38px,4.4vw,64px)/0.94 var(--font-display)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--cold-white)",
      maxWidth: "20ch",
      textWrap: "pretty"
    }
  }, active.goal)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,max-content)",
      gap: "var(--space-11)"
    }
  }, [["AGENTS", `${active.agents}`], ["TOKENS", active.tokens], ["COST", active.cost], ["VELOCITY", active.velocity]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "4px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1 var(--font-telemetry)",
      letterSpacing: "0.12em",
      color: "var(--text-on-field-secondary)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 22px/1 var(--font-telemetry)",
      color: "var(--cold-white)",
      fontVariantNumeric: "tabular-nums"
    }
  }, v)))), /*#__PURE__*/React.createElement(Button, {
    on: "field",
    variant: "primary",
    onClick: () => go("SWARM")
  }, "Enter swarm"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      borderLeft: "1px solid var(--border-on-dark-strong)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px var(--space-7)",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    rule: true
  }, "Other missions")), rest.map(m => /*#__PURE__*/React.createElement("button", {
    key: m.id,
    onClick: () => {
      setSel(m.id);
      run(`mission open ${m.id}`);
    },
    style: {
      textAlign: "left",
      background: sel === m.id ? "var(--void-plate)" : "transparent",
      border: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      padding: "var(--space-6) var(--space-7)",
      display: "flex",
      flexDirection: "column",
      gap: "10px",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, m.id, " \xB7 GEN ", m.gen), /*#__PURE__*/React.createElement(StateBadge, {
    on: "dark",
    state: m.state
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 19px/1.15 var(--font-display)",
      color: "var(--cold-white)",
      textWrap: "pretty"
    }
  }, m.goal), /*#__PURE__*/React.createElement(Telemetry, {
    on: "dark",
    size: "sm",
    items: [{
      label: "Agents",
      value: String(m.agents)
    }, {
      label: "Tokens",
      value: m.tokens
    }, {
      label: "Cost",
      value: m.cost,
      tone: "active"
    }, {
      label: "Elapsed",
      value: m.elapsed
    }]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-6) var(--space-7)",
      borderTop: "1px solid var(--border-on-dark)",
      display: "flex",
      gap: "10px"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "primary",
    size: "sm",
    onClick: () => go("INTAKE")
  }, "New objective"), /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "ghost",
    size: "sm",
    onClick: () => run("mission archive --state failed")
  }, "Archive failed"))))), /*#__PURE__*/React.createElement(ContextInspector, {
    open: !!selected,
    kind: "MISSION",
    title: selected ? selected.goal : "",
    subtitle: selected ? `${selected.id} · generation ${selected.gen}` : "",
    sections: selected ? [{
      label: "Run",
      rows: [{
        k: "State",
        v: selected.state.toUpperCase(),
        tone: selected.state === "failed" ? "consequence" : selected.state === "complete" ? "verified" : "neutral"
      }, {
        k: "Agents",
        v: String(selected.agents)
      }, {
        k: "Elapsed",
        v: selected.elapsed
      }]
    }, {
      label: "Resource",
      rows: [{
        k: "Tokens",
        v: selected.tokens
      }, {
        k: "Est. cost",
        v: selected.cost,
        tone: "active"
      }, {
        k: "Velocity",
        v: selected.velocity
      }]
    }, {
      label: "Gates",
      rows: [{
        k: "Open",
        v: String(selected.gates),
        tone: selected.gates ? "consequence" : "dim"
      }]
    }] : [],
    onClose: () => setSel(null),
    actions: /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => go("SWARM")
    }, "Open swarm")
  }));
}
function IntakeScreen({
  run,
  go,
  RouteHeader
}) {
  const [goal, setGoal] = React.useState(DM.mission.goal);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Goal intake",
    index: "02/08",
    title: "One objective, its boundaries, and what would count as done.",
    telemetry: [{
      label: "Documents",
      value: "3"
    }, {
      label: "Constraints",
      value: "4"
    }, {
      label: "Open ambiguity",
      value: "2",
      tone: "consequence"
    }]
  }), /*#__PURE__*/React.createElement(ObjectiveAperture, {
    mission: DM.mission.id,
    goal: goal,
    onGoalChange: e => setGoal(e.target.value),
    constraints: DM.mission.constraints,
    documents: DM.mission.documents,
    definitionOfDone: DM.mission.dod,
    ambiguities: DM.mission.ambiguities,
    on: "field",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      on: "field",
      variant: "primary",
      onClick: () => {
        run(`mission create --goal "${goal.slice(0, 40)}…" --budget 2.5M`);
        go("SWARM");
      }
    }, "Decompose"), /*#__PURE__*/React.createElement(Button, {
      on: "field",
      variant: "secondary",
      onClick: () => run("mission attach --file supplier-capacity-disclosures.csv")
    }, "Attach context"), /*#__PURE__*/React.createElement(Button, {
      on: "field",
      variant: "ghost",
      onClick: () => run("mission ask --ambiguity 1")
    }, "Answer ambiguity"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-7)",
      padding: "var(--space-7) var(--gutter-page)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "58ch",
      font: "400 13px/1.5 var(--font-interface)",
      color: "var(--text-on-dark-secondary)"
    }
  }, "The lead studies the goal and the attached context before assigning work. It may split a task, replace an approach, create a new specialist, or request a missing input as evidence changes \u2014 the plan is not frozen at creation."), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1.6 var(--font-telemetry)",
      letterSpacing: "0.1em",
      color: "var(--quiet-metal-dim)",
      textAlign: "right",
      flex: "none"
    }
  }, "AOS \xB7 AGENTIC ORCHESTRATION SYSTEM", /*#__PURE__*/React.createElement("br", null), "ILLUSTRATIVE STATE \xB7 NOTHING EXECUTES", /*#__PURE__*/React.createElement("br", null), "AI/ACC")));
}
Object.assign(window, {
  MissionsScreen,
  IntakeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/MissionScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/ResearchScreens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  EvidencePlate,
  ConvergenceCore,
  ContextInspector,
  Button,
  StateBadge,
  SectionLabel,
  Telemetry
} = window.AOSDesignSystem_20e4c5;
const DE = window.AOSDATA;
function EvidenceScreen({
  sel,
  setSel,
  run,
  RouteHeader
}) {
  const selected = DE.evidence.find(e => e.id === sel);
  const facets = [{
    label: "PRIMARY",
    n: 4
  }, {
    label: "USER DOCUMENT",
    n: 1
  }, {
    label: "DERIVED",
    n: 1
  }, {
    label: "CONTRADICTED",
    n: 2,
    tone: "consequence"
  }, {
    label: "UNRESOLVED",
    n: 1,
    tone: "consequence"
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Evidence",
    index: "04/08",
    title: "128 items, 6 consequential, 2 contradicted.",
    telemetry: [{
      label: "Items",
      value: "128"
    }, {
      label: "Verified",
      value: "96",
      tone: "verified"
    }, {
      label: "Contradicted",
      value: "2",
      tone: "consequence"
    }, {
      label: "Producers",
      value: "9"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "196px",
      flex: "none",
      borderRight: "1px solid var(--border-on-dark)",
      padding: "var(--space-6) var(--space-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark"
  }, "Provenance"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, facets.map(f => /*#__PURE__*/React.createElement("button", {
    key: f.label,
    onClick: () => run(`evidence filter --provenance ${f.label.toLowerCase()}`),
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "10px",
      background: "transparent",
      border: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      padding: "9px 0",
      cursor: "pointer",
      font: "400 11px/1 var(--font-telemetry)",
      letterSpacing: "0.06em",
      color: f.tone ? "var(--vermilion)" : "var(--text-on-dark-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", null, f.label), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--cold-white)"
    }
  }, f.n)))), /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark"
  }, "Producers"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, [["A-14", 22], ["A-07", 38], ["V-03", 31], ["A-31", 14], ["A-19", 9], ["CL-1", 34]].map(([id, n]) => /*#__PURE__*/React.createElement("div", {
    key: id,
    style: {
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", null, id), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-on-dark-secondary)"
    }
  }, n))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "auto",
      padding: "var(--space-6) var(--gutter-page)",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
      gap: "var(--space-5)",
      alignContent: "start"
    }
  }, DE.evidence.map(e => /*#__PURE__*/React.createElement(EvidencePlate, _extends({
    key: e.id,
    on: "dark"
  }, e, {
    selected: sel === e.id,
    onOpen: () => {
      setSel(e.id);
      run(`evidence trace ${e.id}`);
    }
  })))))), /*#__PURE__*/React.createElement(ContextInspector, {
    open: !!selected,
    kind: "EVIDENCE",
    title: selected ? selected.id : "",
    subtitle: selected ? selected.source : "",
    sections: selected ? [{
      label: "Claim",
      body: selected.claim
    }, {
      label: "Provenance",
      rows: [{
        k: "Class",
        v: selected.provenance
      }, {
        k: "Freshness",
        v: selected.freshness
      }, {
        k: "Confidence",
        v: selected.confidence,
        tone: "active"
      }, {
        k: "Produced by",
        v: selected.producedBy
      }]
    }, {
      label: "Downstream",
      rows: (selected.consumers || []).map(c => ({
        k: "Used by",
        v: c
      }))
    }, {
      label: "Dissent",
      rows: [{
        k: "State",
        v: selected.contradiction ? "CONTRADICTED" : "CORROBORATED",
        tone: selected.contradiction ? "consequence" : "verified"
      }],
      body: selected.contradiction ? "The contradiction stays attached to the claim and travels into synthesis. It is not resolved by removal." : "No open contradiction recorded against this item."
    }] : [],
    onClose: () => setSel(null),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => run(`evidence open --source ${sel}`)
    }, "Open source"), /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "ghost",
      size: "sm",
      full: true,
      onClick: () => run(`evidence dispute ${sel}`)
    }, "Dispute"))
  }));
}
function SynthesisScreen({
  coreOpen,
  setCoreOpen,
  run,
  go,
  RouteHeader
}) {
  const objections = DE.branches.filter(b => b.state === "conflict");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Synthesis",
    index: "05/08",
    title: "Six branches compress into one ranked conclusion.",
    telemetry: [{
      label: "Branches",
      value: "6"
    }, {
      label: "Evidence",
      value: "128",
      tone: "verified"
    }, {
      label: "Confidence",
      value: "0.72",
      tone: "active"
    }, {
      label: "Objections",
      value: "3",
      tone: "consequence"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "auto",
      padding: "var(--space-8) var(--gutter-page)"
    }
  }, /*#__PURE__*/React.createElement(ConvergenceCore, {
    size: 188,
    agents: 41,
    models: 5,
    evidence: 128,
    generation: "08",
    confidence: "0.72",
    objections: 3,
    branches: DE.branches,
    expanded: coreOpen,
    onToggle: () => setCoreOpen(!coreOpen)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-10)",
      borderTop: "1px solid var(--border-on-dark-strong)",
      paddingTop: "var(--space-7)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark"
  }, "Proposed conclusion"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "40ch",
      font: "400 34px/1.06 var(--font-display)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--cold-white)",
      textWrap: "pretty"
    }
  }, "On disclosed capacity alone, supply falls short of 2029 EU demand by 11\u201319%."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "var(--measure-body)",
      font: "400 15px/1.5 var(--font-interface)",
      color: "var(--text-on-dark-secondary)"
    }
  }, "The conclusion holds only while announced ramp schedules are discounted at their historical slip rate and imports remain outside the mission boundary. Two objections below can invert the sign of the result."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "10px",
      marginTop: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "primary",
    onClick: () => run("synthesis accept --with-objections")
  }, "Accept with objections"), /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "secondary",
    onClick: () => go("EVIDENCE")
  }, "Inspect inputs"), /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "ghost",
    onClick: () => run("synthesis reopen --branch A-19")
  }, "Reopen branch")))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "320px",
      flex: "none",
      borderLeft: "1px solid var(--border-on-dark-strong)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    rule: true
  }, "Unresolved objections")), objections.map(o => /*#__PURE__*/React.createElement("div", {
    key: o.label,
    style: {
      padding: "var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark)",
      borderLeft: "3px solid var(--vermilion)",
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 15px/1.35 var(--font-interface)",
      color: "var(--cold-white)"
    }
  }, o.label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1.4 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, o.source, " \xB7 CONF ", o.confidence))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark)",
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 15px/1.35 var(--font-interface)",
      color: "var(--cold-white)"
    }
  }, "Unit conversion in one filing is unverified."), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1.4 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, "EV-131 \xB7 A-19 \xB7 CONF 0.41"), /*#__PURE__*/React.createElement(StateBadge, {
    on: "dark",
    state: "gate",
    label: "NEEDS A-22"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      borderTop: "1px solid var(--border-on-dark)",
      font: "400 11px/1.6 var(--font-telemetry)",
      color: "var(--quiet-metal-dim)"
    }
  }, "Objections travel with the conclusion. Accepting does not close them."))));
}
Object.assign(window, {
  EvidenceScreen,
  SynthesisScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/ResearchScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/Shell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  GlobalRail,
  CLISheet,
  ContextInspector,
  DecisionGate,
  Button,
  SectionLabel,
  Telemetry,
  StateBadge,
  Aperture
} = window.AOSDesignSystem_20e4c5;
const D = window.AOSDATA;
function CommandPalette({
  open,
  onClose,
  onRun
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 20,
      background: "rgba(5,5,9,0.72)",
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "center",
      paddingTop: "120px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: "620px",
      background: "var(--void-raise)",
      border: "1px solid var(--border-on-dark-strong)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      padding: "0 14px",
      height: "44px",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(Aperture, {
    size: 14,
    tone: "cobalt",
    state: "converging"
  }), /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    placeholder: "command or goal\u2026",
    style: {
      flex: 1,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--cold-white)",
      font: "400 14px/1 var(--font-telemetry)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, "ESC")), D.palette.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.cmd,
    onClick: () => {
      onRun(p.cmd);
      onClose();
    },
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "14px",
      width: "100%",
      textAlign: "left",
      padding: "9px 14px",
      background: "transparent",
      border: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "84px",
      flex: "none",
      font: "500 10px/1.4 var(--font-telemetry)",
      letterSpacing: "0.08em",
      color: p.cat === "AI/ACC" ? "var(--ultraviolet)" : "var(--quiet-metal-dim)"
    }
  }, p.cat), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "400 13px/1.4 var(--font-telemetry)",
      color: "var(--cold-white)"
    }
  }, p.cmd), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1.4 var(--font-interface)",
      color: "var(--quiet-metal)"
    }
  }, p.hint)))));
}

/* One header strip shared by every route: objective, then aggregate telemetry. */
function RouteHeader({
  label,
  index,
  title,
  telemetry,
  right,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      padding: "14px var(--gutter-page)",
      display: "flex",
      flexDirection: "column",
      gap: "10px",
      background: "var(--void)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    index: index
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), right), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: "400 30px/1.08 var(--font-display)",
      letterSpacing: "var(--tracking-title)",
      color: "var(--cold-white)",
      maxWidth: "44ch",
      textWrap: "pretty"
    }
  }, title), telemetry ? /*#__PURE__*/React.createElement(Telemetry, {
    on: "dark",
    items: telemetry,
    style: {
      flex: "none"
    }
  }) : null), children);
}
function App() {
  const [route, setRoute] = React.useState("SWARM");
  const [sel, setSel] = React.useState(null);
  const [cliOpen, setCliOpen] = React.useState(false);
  const [paletteOpen, setPaletteOpen] = React.useState(false);
  const [lines, setLines] = React.useState(D.cli);
  const [gateOpen, setGateOpen] = React.useState(true);
  const [prompt, setPrompt] = React.useState("");
  const [coreOpen, setCoreOpen] = React.useState(true);
  const [expanded, setExpanded] = React.useState([]);
  React.useEffect(() => {
    const h = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen(v => !v);
      }
      if (e.key === "Escape") setPaletteOpen(false);
      if (e.ctrlKey && e.key === "`") {
        e.preventDefault();
        setCliOpen(v => !v);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);
  const run = cmd => {
    setLines(l => [...l, {
      kind: "command",
      text: cmd
    }, {
      kind: "meta",
      text: "illustrative state · command not executed"
    }]);
    setCliOpen(true);
  };
  const go = r => {
    setRoute(r);
    setSel(null);
  };
  const shared = {
    sel,
    setSel,
    run,
    go,
    coreOpen,
    setCoreOpen,
    expanded,
    setExpanded,
    gateOpen,
    setGateOpen,
    RouteHeader
  };
  const screen = route === "SWARM" ? /*#__PURE__*/React.createElement(window.SwarmScreen, shared) : route === "MISSIONS" ? /*#__PURE__*/React.createElement(window.MissionsScreen, shared) : route === "INTAKE" ? /*#__PURE__*/React.createElement(window.IntakeScreen, shared) : route === "EVIDENCE" ? /*#__PURE__*/React.createElement(window.EvidenceScreen, shared) : route === "SYNTHESIS" ? /*#__PURE__*/React.createElement(window.SynthesisScreen, shared) : route === "EVOLUTION" ? /*#__PURE__*/React.createElement(window.EvolutionScreen, shared) : route === "CAPABILITIES" ? /*#__PURE__*/React.createElement(window.CapabilitiesScreen, shared) : /*#__PURE__*/React.createElement(window.MemoryScreen, shared);
  const gate = route === "SWARM" && gateOpen ? {
    prompt: "A-22 is blocked by a provider rate limit and two dependents are waiting.",
    detail: "Filings audit holds the unit-conversion check that could invert EV-118. Waiting costs 41 seconds; rerouting costs an estimated $2.10 and loses the cite-check skill.",
    authority: "OPERATOR",
    choices: [{
      label: "Wait 41s",
      consequence: "Dependents stay queued",
      reversible: true,
      variant: "secondary"
    }, {
      label: "Reroute to Codex",
      consequence: "Loses cite-check skill",
      reversible: true,
      variant: "primary"
    }, {
      label: "Stop branch",
      consequence: "Drops 6 evidence items",
      reversible: false,
      variant: "consequence"
    }]
  } : route === "EVOLUTION" && gateOpen ? {
    prompt: "Promote GEN 08 to the default coordination policy?",
    detail: "Held-out evaluation across 40 archived missions: +7.4% verified claims, −12% wasted tokens, one new regression in long-context routing. Rollback point gen-07 · 4a91c2 is retained either way.",
    authority: "OWNER",
    choices: [{
      label: "Promote",
      consequence: "New runs use GEN 08",
      reversible: true,
      variant: "primary"
    }, {
      label: "Reject",
      consequence: "Candidate archived with traces",
      reversible: true,
      variant: "secondary"
    }, {
      label: "Promote + auto-adopt",
      consequence: "Future safe changes self-promote",
      reversible: false,
      variant: "consequence"
    }]
  } : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--void)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(GlobalRail, {
    route: route,
    mission: `${D.mission.id} · GEN ${D.mission.generation}`,
    mode: "ILLUSTRATIVE",
    connection: {
      state: "degraded",
      label: "4 PROVIDERS · 1 LIMITED"
    },
    onRoute: go,
    onCommand: () => setPaletteOpen(true)
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex",
      overflow: "hidden"
    }
  }, screen), gate ? /*#__PURE__*/React.createElement(DecisionGate, _extends({
    open: true
  }, gate, {
    onChoose: c => {
      setGateOpen(false);
      run(`gate resolve --choice "${c.label}"`);
    }
  })) : null, /*#__PURE__*/React.createElement(CLISheet, {
    expanded: cliOpen,
    lines: lines,
    context: `mission/${D.mission.id}${sel ? ` · ${sel}` : ""}`,
    simulated: true,
    prompt: prompt,
    onPromptChange: setPrompt,
    onSubmit: v => {
      if (v.trim()) run(v.trim());
      setPrompt("");
    },
    onToggle: () => setCliOpen(v => !v)
  }), /*#__PURE__*/React.createElement(CommandPalette, {
    open: paletteOpen,
    onClose: () => setPaletteOpen(false),
    onRun: run
  }));
}
Object.assign(window, {
  App,
  CommandPalette,
  RouteHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/SwarmScreen.jsx
try { (() => {
const {
  AccelerationField,
  ContextInspector,
  Button,
  StateBadge,
  Telemetry,
  SectionLabel
} = window.AOSDesignSystem_20e4c5;
const DS = window.AOSDATA;
function agentInspector(a, run) {
  const sections = [{
    label: "Ownership",
    rows: [{
      k: "Owner",
      v: a.owner
    }, {
      k: "Depth",
      v: String(a.depth)
    }, {
      k: "Workspace",
      v: a.workspace
    }]
  }, {
    label: "Runtime",
    rows: [{
      k: "Harness",
      v: a.harness
    }, {
      k: "Model",
      v: a.model,
      tone: a.state === "handoff" ? "transition" : "neutral"
    }, {
      k: "Reasoning",
      v: a.reasoning
    }, {
      k: "Context",
      v: a.context
    }]
  }, {
    label: "Resource",
    rows: [{
      k: "Tokens",
      v: a.tokens
    }, {
      k: "Est. cost",
      v: a.cost,
      tone: "active"
    }, {
      k: "Elapsed",
      v: a.elapsed
    }]
  }, {
    label: "Work",
    rows: [{
      k: "Evidence",
      v: String(a.evidence),
      tone: "verified"
    }, {
      k: "Dependencies",
      v: String(a.deps),
      tone: a.deps ? "neutral" : "dim"
    }, {
      k: "Skills",
      v: (a.skills || []).join(", ") || "—"
    }, {
      k: "MCP",
      v: (a.mcp || []).join(", ") || "—"
    }]
  }];
  if (a.block) sections.push({
    label: "Intervention",
    rows: [{
      k: "Blocked by",
      v: a.block,
      tone: "consequence"
    }],
    body: "Two dependents are waiting. Resolve at the decision gate below."
  });
  if (a.note) sections.push({
    label: "Note",
    body: a.note
  });
  return sections;
}
function clusterInspector(c) {
  const total = Object.values(c.distribution).reduce((x, y) => x + y, 0);
  return [{
    label: "Aggregate",
    rows: [{
      k: "Workers",
      v: String(c.count)
    }, {
      k: "Owner",
      v: c.owner
    }, {
      k: "Tokens",
      v: c.tokens
    }, {
      k: "Est. cost",
      v: c.cost,
      tone: "active"
    }]
  }, {
    label: "Distribution",
    rows: Object.keys(c.distribution).map(k => ({
      k,
      v: `${c.distribution[k]} / ${total}`,
      tone: k === "failed" ? "consequence" : k === "complete" ? "verified" : "neutral"
    }))
  }, {
    label: "Why aggregated",
    body: "34 siblings run the same low-value scan. AOS draws the active path and bundles repetition; expanding enters the cluster as a new scale without losing lineage."
  }];
}
function SwarmScreen({
  sel,
  setSel,
  run,
  RouteHeader
}) {
  const items = [...DS.agents.map(a => ({
    ...a,
    compact: true
  })), ...DS.clusters];
  const selected = items.find(i => i.id === sel);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Swarm",
    index: "03/08",
    title: DS.mission.goal,
    telemetry: [{
      label: "Agents",
      value: `${DS.mission.active}/${DS.mission.agents}`
    }, {
      label: "Tokens",
      value: DS.mission.tokens
    }, {
      label: "Cost",
      value: DS.mission.cost,
      tone: "active"
    }, {
      label: "Elapsed",
      value: DS.mission.elapsed
    }, {
      label: "Evidence",
      value: String(DS.mission.evidence),
      tone: "verified"
    }],
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: "10px"
      }
    }, /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: "running",
      label: "RUNNING 9"
    }), /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: "waiting",
      label: "WAITING 2"
    }), /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: "blocked",
      label: "BLOCKED 1"
    }), /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: "complete",
      label: "COMPLETE 26"
    }), /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: "failed",
      label: "FAILED 1"
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(AccelerationField, {
    items: items,
    edges: DS.edges,
    activePath: DS.activePath,
    selectedId: sel,
    onSelect: id => {
      setSel(id);
      run(`swarm inspect --agent ${id}`);
    },
    height: "100%",
    caption: "46 OF 41 OWNED TASKS AGGREGATED INTO 2 CLUSTERS"
  }))), /*#__PURE__*/React.createElement(ContextInspector, {
    open: !!selected,
    kind: selected && selected.kind === "cluster" ? "CLUSTER" : "AGENT",
    title: selected ? selected.role || selected.label : "",
    subtitle: selected ? `${selected.id} · ${selected.kind === "cluster" ? `${selected.count} workers` : `${selected.harness} / ${selected.model}`}` : "",
    sections: selected ? selected.kind === "cluster" ? clusterInspector(selected) : agentInspector(selected, run) : [],
    onClose: () => setSel(null),
    actions: selected && selected.kind === "cluster" ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "primary",
      size: "sm",
      full: true,
      onClick: () => run(`swarm enter --cluster ${selected.id}`)
    }, "Enter cluster"), /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => run(`swarm summarise --cluster ${selected.id}`)
    }, "Summarise")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => run(`swarm trace --agent ${sel}`)
    }, "Open trace"), /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "consequence",
      size: "sm",
      full: true,
      onClick: () => run(`swarm stop --branch ${sel}`)
    }, "Stop branch"))
  }));
}
Object.assign(window, {
  SwarmScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/SwarmScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/SystemScreens.jsx
try { (() => {
const {
  GenerationRift,
  ContextInspector,
  Button,
  StateBadge,
  SectionLabel,
  Telemetry
} = window.AOSDesignSystem_20e4c5;
const DV = window.AOSDATA;
function EvolutionScreen({
  run,
  RouteHeader
}) {
  const g = DV.generation;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Evolution",
    index: "06/08",
    title: "Generation 08 is a candidate, not a fact.",
    telemetry: [{
      label: "Proposals",
      value: "4"
    }, {
      label: "Passed",
      value: "3",
      tone: "verified"
    }, {
      label: "Regressions",
      value: "1",
      tone: "consequence"
    }, {
      label: "Rollback",
      value: "RETAINED"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: "flex",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "auto",
      padding: "var(--space-7) var(--gutter-page)"
    }
  }, /*#__PURE__*/React.createElement(GenerationRift, {
    baseline: g.baseline,
    candidate: g.candidate,
    changes: g.changes,
    regressions: g.regressions,
    rollback: g.rollback,
    adoption: g.adoption
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    rule: true
  }, "Execution traces"), g.traces.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    onClick: () => run(`generation trace ${t.id}`),
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)",
      textAlign: "left",
      background: "transparent",
      border: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      padding: "10px 0",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "78px",
      flex: "none",
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, t.id), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "400 14px/1.3 var(--font-interface)",
      color: "var(--cold-white)"
    }
  }, t.label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, t.detail), /*#__PURE__*/React.createElement(StateBadge, {
    on: "dark",
    state: t.result === "PASS" ? "verified" : "failed",
    label: t.result
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "300px",
      flex: "none",
      borderLeft: "1px solid var(--border-on-dark-strong)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    rule: true
  }, "Causal chain")), [["OBSERVED FAILURE", "MSN-2264 lost 1.02M tokens to duplicate scans."], ["CAUSAL HYPOTHESIS", "Verification sat below deduplication in the topology."], ["PROPOSED CHANGE", "Collapse duplicates before verification; move verification up."], ["HELD-OUT EVALUATION", "40 archived missions, no overlap with the proposal set."], ["COMPARISON", "+7.4% verified claims against GEN 07 baseline."], ["DECISION", "Awaiting owner approval at the gate below."]].map(([k, v], i) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      padding: "var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark)",
      borderLeft: `3px solid ${i === 5 ? "var(--vermilion)" : "var(--ultraviolet)"}`,
      display: "flex",
      flexDirection: "column",
      gap: "6px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 10px/1 var(--font-telemetry)",
      letterSpacing: "0.1em",
      color: i === 5 ? "var(--vermilion)" : "var(--ultraviolet)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 13px/1.45 var(--font-interface)",
      color: "var(--text-on-dark)"
    }
  }, v))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      borderTop: "1px solid var(--border-on-dark)",
      font: "400 11px/1.6 var(--font-telemetry)",
      color: "var(--quiet-metal-dim)"
    }
  }, "AOS does not approve its own high-risk changes."))));
}
function CapabilitiesScreen({
  sel,
  setSel,
  run,
  RouteHeader
}) {
  const rows = DV.capabilities.flatMap(g => g.rows.map(r => ({
    ...r,
    group: g.group
  })));
  const selected = rows.find(r => r.name === sel);
  const head = ["RESOURCE", "AUTH", "MODELS", "CONTEXT", "RATE", "COST", "TOOLS", "IN USE", ""];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Capabilities",
    index: "07/08",
    title: "Routing topology: harnesses, models, skills, servers, tools.",
    telemetry: [{
      label: "Harnesses",
      value: "4"
    }, {
      label: "Models",
      value: "7"
    }, {
      label: "MCP",
      value: "2"
    }, {
      label: "Generated",
      value: "1",
      tone: "consequence"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.4fr 0.7fr 1.4fr 0.7fr 0.5fr 0.8fr 0.6fr 0.5fr auto",
      gap: 0,
      alignItems: "stretch"
    }
  }, head.map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "10px var(--space-5)",
      borderBottom: "1px solid var(--border-on-dark-strong)",
      font: "500 10px/1 var(--font-telemetry)",
      letterSpacing: "0.1em",
      color: "var(--quiet-metal)",
      background: "var(--void)",
      position: "sticky",
      top: 0
    }
  }, h)), DV.capabilities.map(g => [/*#__PURE__*/React.createElement("div", {
    key: g.group,
    style: {
      gridColumn: "1 / -1",
      padding: "12px var(--space-5) 6px",
      font: "500 10px/1 var(--font-telemetry)",
      letterSpacing: "0.14em",
      color: "var(--ultraviolet)",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, g.group, " \xB7 ", g.rows.length), ...g.rows.map(r => {
    const cells = [r.name, r.auth, r.models, r.context, r.rate, r.cost, r.tools, String(r.inUse)];
    return cells.map((c, ci) => /*#__PURE__*/React.createElement("div", {
      key: r.name + ci,
      onClick: () => {
        setSel(r.name);
        run(`capability inspect "${r.name}"`);
      },
      style: {
        padding: "11px var(--space-5)",
        borderBottom: "1px solid var(--border-on-dark)",
        cursor: "pointer",
        background: sel === r.name ? "var(--void-plate)" : "transparent",
        font: ci === 0 ? "500 13px/1.2 var(--font-interface)" : "400 12px/1.2 var(--font-telemetry)",
        color: ci === 0 ? "var(--cold-white)" : "var(--text-on-dark-secondary)",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis"
      }
    }, c)).concat(/*#__PURE__*/React.createElement("div", {
      key: r.name + "s",
      onClick: () => setSel(r.name),
      style: {
        padding: "11px var(--space-5)",
        borderBottom: "1px solid var(--border-on-dark)",
        background: sel === r.name ? "var(--void-plate)" : "transparent",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement(StateBadge, {
      on: "dark",
      state: r.state,
      form: "bare"
    })));
  })])), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      padding: "var(--space-7) var(--gutter-page)",
      maxWidth: "var(--measure-body)",
      font: "400 13px/1.5 var(--font-interface)",
      color: "var(--text-on-dark-secondary)"
    }
  }, "Providers expose their real differences: model availability, reasoning controls, context limits, rate limits, authentication mode, tool support, token accounting and cost. A generated tool is not trusted because an agent wrote it \u2014 it stays blocked until a bounded test passes."))), /*#__PURE__*/React.createElement(ContextInspector, {
    open: !!selected,
    kind: "CAPABILITY",
    title: selected ? selected.name : "",
    subtitle: selected ? `${selected.group} · ${selected.inUse} task(s)` : "",
    sections: selected ? [{
      label: "Routing",
      rows: [{
        k: "Auth",
        v: selected.auth
      }, {
        k: "Models",
        v: selected.models
      }, {
        k: "Context",
        v: selected.context
      }, {
        k: "Tool support",
        v: selected.tools
      }]
    }, {
      label: "Pressure",
      rows: [{
        k: "Rate limit",
        v: selected.rate,
        tone: selected.rate === "68%" ? "consequence" : "neutral"
      }, {
        k: "Cost",
        v: selected.cost,
        tone: "active"
      }, {
        k: "State",
        v: selected.state.toUpperCase(),
        tone: selected.state === "blocked" ? "consequence" : "neutral"
      }]
    }, selected.note ? {
      label: "Note",
      body: selected.note
    } : {
      label: "Note",
      body: "No constraint recorded beyond the provider's published limits."
    }] : [],
    onClose: () => setSel(null),
    actions: /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => run(`capability test "${sel}"`)
    }, "Run bounded test")
  }));
}
function MemoryScreen({
  run,
  RouteHeader
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(RouteHeader, {
    label: "Memory",
    index: "08/08",
    title: "Three stores, explicit inheritance, visible boundaries.",
    telemetry: [{
      label: "Global",
      value: "412"
    }, {
      label: "Project",
      value: "1 286"
    }, {
      label: "Agent",
      value: "94"
    }, {
      label: "Expiring 24h",
      value: "37",
      tone: "transition"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflow: "auto",
      display: "flex",
      flexDirection: "column"
    }
  }, DV.memory.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: m.scope,
    style: {
      display: "flex",
      alignItems: "stretch",
      borderBottom: "1px solid var(--border-on-dark)",
      paddingLeft: `${i * 48}px`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: "var(--space-7)",
      padding: "var(--space-7) var(--gutter-page) var(--space-7) var(--space-7)",
      borderLeft: `3px solid ${i === 0 ? "var(--cobalt)" : i === 1 ? "var(--ultraviolet)" : "var(--quiet-metal)"}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "160px",
      flex: "none",
      display: "flex",
      flexDirection: "column",
      gap: "6px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 22px/1 var(--font-display)",
      letterSpacing: "0.04em",
      color: "var(--cold-white)"
    }
  }, m.scope), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 11px/1 var(--font-telemetry)",
      color: "var(--quiet-metal)"
    }
  }, m.items, " ITEMS")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 14px/1.4 var(--font-interface)",
      color: "var(--text-on-dark)"
    }
  }, m.note), /*#__PURE__*/React.createElement(Telemetry, {
    on: "dark",
    size: "sm",
    items: [{
      label: "Retention",
      value: m.retention
    }, {
      label: "Inherits to",
      value: m.inherit
    }, {
      label: "Write policy",
      value: m.policy
    }]
  })), /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "ghost",
    size: "sm",
    onClick: () => run(`memory list --scope ${m.scope.toLowerCase()}`)
  }, "Inspect")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-10)",
      padding: "var(--space-8) var(--gutter-page)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "52ch",
      font: "400 13px/1.5 var(--font-interface)",
      color: "var(--text-on-dark-secondary)"
    }
  }, "Inheritance runs downward only: a global pattern reaches every mission, a project finding reaches that mission's agents, and an agent's working context reaches nothing. \u201CRemember everything\u201D is an option with consequences, not a hidden default."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "10px",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "secondary",
    size: "sm",
    onClick: () => run("memory export --scope project --format jsonl")
  }, "Export project"), /*#__PURE__*/React.createElement(Button, {
    on: "dark",
    variant: "consequence",
    size: "sm",
    onClick: () => run("memory purge --scope agent --confirm")
  }, "Purge agent memory")))));
}
Object.assign(window, {
  EvolutionScreen,
  CapabilitiesScreen,
  MemoryScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/SystemScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/data.js
try { (() => {
/* Deterministic illustrative state for the AOS UI kit. No live data, no random values. */
window.AOSDATA = (() => {
  const mission = {
    id: "MSN-2291",
    goal: "Can solid-state cell supply meet 2029 EU demand?",
    generation: "07",
    candidate: "08",
    started: "2026-09-14 09:52Z",
    agents: 41,
    active: 9,
    tokens: "1.84M",
    cost: "$21.40",
    elapsed: "01:12:44",
    evidence: 128,
    objections: 3,
    budget: "2.5M",
    dod: ["One ranked conclusion with cost bounds", "Every claim traced to a primary filing", "Objections attached, not resolved away"],
    constraints: ["2.5M token budget", "Primary filings only", "No paid data sources", "Stop any branch above $8"],
    documents: [{
      name: "eu-battery-directive-2026.pdf",
      size: "2.1 MB"
    }, {
      name: "supplier-capacity-disclosures.csv",
      size: "340 KB"
    }, {
      name: "prior-run-MSN-2104-retro.md",
      size: "18 KB"
    }],
    ambiguities: [{
      q: "Does “supply” include imports from non-EU plants?",
      status: "ASKED"
    }, {
      q: "Is 2029 calendar or fiscal?",
      status: "ASSUMED CALENDAR"
    }]
  };
  const agents = [{
    id: "OBJ",
    role: "Objective",
    owner: "—",
    depth: 0,
    lane: 0.5,
    harness: "AOS",
    model: "control plane",
    state: "running",
    tokens: "—",
    cost: "$21.40",
    elapsed: "01:12:44",
    evidence: 128,
    deps: 0,
    workspace: "mission root",
    reasoning: "—",
    context: "—"
  }, {
    id: "L-01",
    role: "Lead",
    owner: "OBJ",
    depth: 1,
    lane: 0.36,
    harness: "AOS",
    model: "claude-opus-4",
    state: "running",
    tokens: "180K",
    cost: "$9.10",
    elapsed: "01:12:02",
    evidence: 4,
    deps: 0,
    workspace: "ws/lead",
    reasoning: "HIGH",
    context: "62% of 200K",
    skills: ["decompose", "budget-guard"],
    mcp: ["filings-index"]
  }, {
    id: "A-07",
    role: "Supply mapping",
    owner: "L-01",
    depth: 2,
    lane: 0.22,
    harness: "Codex",
    model: "gpt-5-codex",
    state: "running",
    tokens: "640K",
    cost: "$12.80",
    elapsed: "22:10",
    evidence: 38,
    deps: 1,
    workspace: "ws/a-07",
    reasoning: "MEDIUM",
    context: "41% of 400K",
    skills: ["table-extract"],
    mcp: ["filings-index", "eur-lex"]
  }, {
    id: "A-22",
    role: "Filings audit",
    owner: "L-01",
    depth: 2,
    lane: 0.62,
    harness: "Claude Code",
    model: "claude-sonnet-4",
    state: "blocked",
    tokens: "94K",
    cost: "$1.10",
    elapsed: "03:41",
    evidence: 6,
    deps: 2,
    workspace: "ws/a-22",
    reasoning: "HIGH",
    context: "18% of 200K",
    skills: ["cite-check"],
    mcp: ["filings-index"],
    block: "Rate limit · anthropic · retry in 41s"
  }, {
    id: "A-31",
    role: "Demand model",
    owner: "L-01",
    depth: 2,
    lane: 0.88,
    harness: "DeepSeek Harness",
    model: "deepseek-r1",
    state: "complete",
    tokens: "221K",
    cost: "$0.84",
    elapsed: "11:03",
    evidence: 14,
    deps: 0,
    workspace: "ws/a-31",
    reasoning: "HIGH",
    context: "34% of 128K",
    skills: ["forecast-audit"],
    mcp: []
  }, {
    id: "A-14",
    role: "Corpus triage",
    owner: "A-07",
    depth: 3,
    lane: 0.16,
    harness: "Claude Code",
    model: "claude-sonnet-4",
    state: "running",
    tokens: "412K",
    cost: "$4.90",
    elapsed: "07:22",
    evidence: 22,
    deps: 1,
    workspace: "ws/a-14",
    reasoning: "MEDIUM",
    context: "77% of 200K",
    skills: ["dedupe", "table-extract"],
    mcp: ["filings-index"]
  }, {
    id: "A-19",
    role: "Capacity reconciler",
    owner: "A-07",
    depth: 3,
    lane: 0.44,
    harness: "Codex",
    model: "gpt-5 → opus-4",
    state: "handoff",
    tokens: "308K",
    cost: "$6.20",
    elapsed: "04:58",
    evidence: 9,
    deps: 2,
    workspace: "ws/a-19",
    reasoning: "HIGH",
    context: "handoff at 182K",
    skills: ["unit-normalise"],
    mcp: ["filings-index"],
    note: "Context exceeded gpt-5 window; lead moved the task to opus-4 mid-run."
  }, {
    id: "V-03",
    role: "Claim verifier",
    owner: "L-01",
    depth: 4,
    lane: 0.3,
    harness: "Ollama (local)",
    model: "qwen3-8b",
    state: "running",
    tokens: "96K",
    cost: "$0.00",
    elapsed: "02:14",
    evidence: 31,
    deps: 1,
    workspace: "ws/v-03",
    reasoning: "LOW",
    context: "22% of 32K",
    skills: ["verify-claim"],
    mcp: [],
    note: "Local model earned this role in GEN 06 on cost/quality trade-off."
  }, {
    id: "CORE",
    role: "Convergence",
    owner: "L-01",
    depth: 5,
    lane: 0.5,
    harness: "AOS",
    model: "synthesis",
    state: "waiting",
    tokens: "—",
    cost: "—",
    elapsed: "—",
    evidence: 128,
    deps: 4,
    workspace: "mission root",
    reasoning: "—",
    context: "—"
  }];
  const clusters = [{
    id: "CL-1",
    kind: "cluster",
    depth: 3,
    lane: 0.72,
    label: "Source scanners",
    count: 34,
    owner: "A-07",
    tokens: "2.1M",
    cost: "$18.60",
    distribution: {
      complete: 25,
      running: 6,
      waiting: 2,
      failed: 1
    }
  }, {
    id: "CL-2",
    kind: "cluster",
    depth: 4,
    lane: 0.74,
    label: "Unit normalisers",
    count: 12,
    owner: "A-19",
    tokens: "480K",
    cost: "$3.20",
    distribution: {
      complete: 9,
      running: 2,
      failed: 1
    }
  }];
  const edges = [{
    from: "OBJ",
    to: "L-01",
    throughput: 0.9
  }, {
    from: "L-01",
    to: "A-07",
    throughput: 0.7
  }, {
    from: "L-01",
    to: "A-22",
    state: "waiting"
  }, {
    from: "L-01",
    to: "A-31",
    state: "verified",
    throughput: 0.3
  }, {
    from: "A-07",
    to: "A-14",
    throughput: 0.8
  }, {
    from: "A-07",
    to: "A-19",
    state: "handoff",
    throughput: 0.5
  }, {
    from: "A-07",
    to: "CL-1",
    state: "dormant"
  }, {
    from: "A-19",
    to: "CL-2",
    state: "dormant"
  }, {
    from: "A-22",
    to: "A-19",
    kind: "dependency",
    state: "conflict",
    label: "BLOCKS"
  }, {
    from: "A-14",
    to: "V-03",
    throughput: 0.6
  }, {
    from: "V-03",
    to: "CORE",
    state: "verified",
    throughput: 0.4
  }, {
    from: "A-31",
    to: "CORE",
    state: "stable",
    throughput: 0.2
  }];
  const activePath = ["OBJ", "L-01", "A-07", "A-14", "V-03", "CORE"];
  const evidence = [{
    id: "EV-118",
    claim: "Two of three named suppliers disclose 2029 capacity below the modelled EU requirement.",
    source: "Supplier 10-K filings (3)",
    provenance: "PRIMARY · RETRIEVED",
    freshness: "4h",
    confidence: "0.81",
    producedBy: "A-14",
    consumers: ["A-19", "CORE"],
    contradiction: false
  }, {
    id: "EV-121",
    claim: "Announced gigafactory ramp schedules slip by a median of 14 months against first public guidance.",
    source: "Company announcements, 2019–2026",
    provenance: "PRIMARY · COMPUTED",
    freshness: "11h",
    confidence: "0.74",
    producedBy: "A-07",
    consumers: ["A-31"],
    contradiction: false
  }, {
    id: "EV-126",
    claim: "EU demand projection assumes a 38% solid-state share by 2029.",
    source: "eu-battery-directive-2026.pdf, p.44",
    provenance: "USER DOCUMENT",
    freshness: "SUPPLIED",
    confidence: "0.66",
    producedBy: "A-31",
    consumers: ["CORE"],
    contradiction: true
  }, {
    id: "EV-131",
    claim: "One supplier's disclosed capacity is stated in cell count, not GWh; conversion is unverified.",
    source: "Supplier filing (1)",
    provenance: "PRIMARY · UNRESOLVED",
    freshness: "2h",
    confidence: "0.41",
    producedBy: "A-19",
    consumers: ["A-22"],
    contradiction: true
  }, {
    id: "EV-134",
    claim: "Import capacity from non-EU plants is excluded by the current mission boundary.",
    source: "Mission constraint · operator",
    provenance: "DECISION RECORD",
    freshness: "1h",
    confidence: "1.00",
    producedBy: "L-01",
    consumers: ["A-07", "A-31"],
    contradiction: false
  }, {
    id: "EV-137",
    claim: "31 of 34 scanner findings duplicate three underlying filings.",
    source: "Scanner cluster CL-1",
    provenance: "DERIVED · AGGREGATE",
    freshness: "22m",
    confidence: "0.88",
    producedBy: "V-03",
    consumers: ["L-01"],
    contradiction: false
  }];
  const branches = [{
    label: "Supply falls short on disclosed capacity",
    source: "A-14 · 22 evidence",
    confidence: "0.81",
    weight: 0.95,
    state: "verified"
  }, {
    label: "Shortfall closes if announced ramps hold",
    source: "A-07 · 38 evidence",
    confidence: "0.52",
    weight: 0.7
  }, {
    label: "Demand baseline itself is contested",
    source: "A-31 · 14 evidence",
    confidence: "0.44",
    weight: 0.6,
    state: "conflict"
  }, {
    label: "Unit conversion error could invert the result",
    source: "A-19 · 9 evidence",
    confidence: "0.41",
    weight: 0.5,
    state: "conflict"
  }, {
    label: "Scanner findings add no independent signal",
    source: "V-03 · 31 evidence",
    confidence: "0.88",
    weight: 0.4,
    dormant: true
  }, {
    label: "Imports excluded by operator decision",
    source: "L-01 · 1 decision",
    confidence: "1.00",
    weight: 0.55
  }];
  const missions = [{
    id: "MSN-2291",
    goal: "Can solid-state cell supply meet 2029 EU demand?",
    state: "running",
    agents: 41,
    gen: "07 → 08",
    tokens: "1.84M",
    cost: "$21.40",
    elapsed: "01:12:44",
    velocity: "3.1 findings/min",
    gates: 1
  }, {
    id: "MSN-2287",
    goal: "Which of our failed runs share a single coordination cause?",
    state: "complete",
    agents: 18,
    gen: "07",
    tokens: "760K",
    cost: "$8.05",
    elapsed: "00:41:19",
    velocity: "1.4 findings/min",
    gates: 0
  }, {
    id: "MSN-2281",
    goal: "Build a verified cost model for local-model substitution.",
    state: "waiting",
    agents: 6,
    gen: "06",
    tokens: "210K",
    cost: "$1.60",
    elapsed: "00:09:02",
    velocity: "0.4 findings/min",
    gates: 1
  }, {
    id: "MSN-2264",
    goal: "Reconstruct the provenance chain for the 2025 policy brief.",
    state: "failed",
    agents: 22,
    gen: "06",
    tokens: "1.02M",
    cost: "$14.80",
    elapsed: "00:58:41",
    velocity: "—",
    gates: 0
  }];
  const generation = {
    baseline: {
      label: "GEN 07",
      metrics: [{
        label: "Verified claims",
        value: "71%"
      }, {
        label: "Wasted tokens",
        value: "18%"
      }, {
        label: "Median mission cost",
        value: "$26.10"
      }, {
        label: "Long-context routing",
        value: "0.67"
      }, {
        label: "Human gates per run",
        value: "2.4"
      }]
    },
    candidate: {
      label: "GEN 08 · CANDIDATE",
      metrics: [{
        label: "Verified claims",
        value: "78%",
        delta: "+7.4"
      }, {
        label: "Wasted tokens",
        value: "6%",
        delta: "−12"
      }, {
        label: "Median mission cost",
        value: "$19.40",
        delta: "−$6.70"
      }, {
        label: "Long-context routing",
        value: "0.62",
        delta: "−0.05",
        regression: true
      }, {
        label: "Human gates per run",
        value: "1.7",
        delta: "−0.7"
      }]
    },
    changes: [{
      kind: "RULE",
      text: "The lead must request a missing input before delegating."
    }, {
      kind: "RULE",
      text: "Duplicate scanner findings collapse before verification."
    }, {
      kind: "TOPOLOGY",
      text: "Verification moved one level up, under the lead."
    }, {
      kind: "ROUTING",
      text: "Local qwen3-8b takes first-pass claim verification."
    }],
    regressions: ["Long-context routing on corpora above 200K tokens"],
    rollback: "gen-07 · 4a91c2",
    adoption: "AWAITING APPROVAL",
    traces: [{
      id: "TR-08-1",
      label: "Held-out eval · 40 archived missions",
      result: "PASS",
      detail: "+7.4% verified claims"
    }, {
      id: "TR-08-2",
      label: "Cost regression suite",
      result: "PASS",
      detail: "−12% wasted tokens"
    }, {
      id: "TR-08-3",
      label: "Long-context routing suite",
      result: "FAIL",
      detail: "−0.05 on >200K corpora"
    }, {
      id: "TR-08-4",
      label: "Safety: self-modification bounds",
      result: "PASS",
      detail: "No rule touched approval gates"
    }]
  };
  const capabilities = [{
    group: "HARNESS",
    rows: [{
      name: "Claude Code",
      auth: "OAUTH",
      models: "sonnet-4, opus-4",
      context: "200K",
      rate: "68%",
      cost: "$/1M 3.00",
      tools: "FULL",
      state: "running",
      inUse: 3
    }, {
      name: "Codex",
      auth: "API KEY",
      models: "gpt-5, gpt-5-codex",
      context: "400K",
      rate: "22%",
      cost: "$/1M 2.50",
      tools: "FULL",
      state: "running",
      inUse: 2
    }, {
      name: "DeepSeek Harness",
      auth: "API KEY",
      models: "deepseek-r1",
      context: "128K",
      rate: "4%",
      cost: "$/1M 0.55",
      tools: "PARTIAL",
      state: "complete",
      inUse: 1
    }, {
      name: "Ollama (local)",
      auth: "LOCAL",
      models: "qwen3-8b, llama3.1-8b",
      context: "32K",
      rate: "—",
      cost: "COMPUTE",
      tools: "NONE",
      state: "running",
      inUse: 1
    }]
  }, {
    group: "SKILL",
    rows: [{
      name: "table-extract",
      auth: "—",
      models: "any",
      context: "—",
      rate: "—",
      cost: "—",
      tools: "—",
      state: "running",
      inUse: 2
    }, {
      name: "cite-check",
      auth: "—",
      models: "any",
      context: "—",
      rate: "—",
      cost: "—",
      tools: "—",
      state: "waiting",
      inUse: 1
    }, {
      name: "verify-claim",
      auth: "—",
      models: "local preferred",
      context: "—",
      rate: "—",
      cost: "—",
      tools: "—",
      state: "running",
      inUse: 1
    }]
  }, {
    group: "MCP",
    rows: [{
      name: "filings-index",
      auth: "OAUTH",
      models: "—",
      context: "—",
      rate: "31%",
      cost: "—",
      tools: "READ",
      state: "running",
      inUse: 4
    }, {
      name: "eur-lex",
      auth: "PUBLIC",
      models: "—",
      context: "—",
      rate: "8%",
      cost: "—",
      tools: "READ",
      state: "running",
      inUse: 1
    }]
  }, {
    group: "GENERATED TOOL",
    rows: [{
      name: "gwh-converter",
      auth: "SANDBOX",
      models: "—",
      context: "—",
      rate: "—",
      cost: "—",
      tools: "EXEC",
      state: "blocked",
      inUse: 0,
      note: "Written by A-19. Bounded test required before any worker may depend on it."
    }]
  }];
  const memory = [{
    scope: "GLOBAL",
    items: 412,
    retention: "PERSISTENT",
    inherit: "ALL MISSIONS",
    policy: "OPERATOR APPROVAL TO WRITE",
    state: "running",
    note: "Validated coordination patterns and policies."
  }, {
    scope: "PROJECT",
    items: 1286,
    retention: "MISSION + 90d",
    inherit: "MISSION AGENTS",
    policy: "LEAD MAY WRITE",
    state: "running",
    note: "Documents, findings, decisions, and this run's history."
  }, {
    scope: "AGENT",
    items: 94,
    retention: "TASK",
    inherit: "NONE",
    policy: "ISOLATED WORKSPACE",
    state: "waiting",
    note: "Working context for one role; discarded at task close."
  }];
  const cli = [{
    kind: "command",
    text: "mission open MSN-2291"
  }, {
    kind: "output",
    text: "goal: Can solid-state cell supply meet 2029 EU demand?  gen 07  budget 2.5M"
  }, {
    kind: "command",
    text: "swarm dispatch --lead L-01 --parallel 3"
  }, {
    kind: "output",
    text: "9 specialists created · 34 scanners aggregated as CL-1 · 12 normalisers as CL-2"
  }, {
    kind: "handoff",
    text: "A-19 handoff gpt-5 → claude-opus-4 (context 182K of 400K, reasoning HIGH)"
  }, {
    kind: "ok",
    text: "evidence EV-118 verified by V-03 (local qwen3-8b) against 3 primary filings"
  }, {
    kind: "error",
    text: "A-22 blocked: rate limit anthropic · retry 41s · 2 dependents waiting"
  }, {
    kind: "meta",
    text: "tokens 1.84M / 2.5M · cost $21.40 · elapsed 01:12:44 · 1 gate open"
  }];
  const palette = [{
    cat: "MISSION",
    cmd: "mission open <id>",
    hint: "Switch the active mission"
  }, {
    cat: "SWARM",
    cmd: "swarm inspect --agent A-14",
    hint: "Open an agent in the inspector"
  }, {
    cat: "SWARM",
    cmd: "swarm stop --branch A-22",
    hint: "Stop a low-value or blocked branch"
  }, {
    cat: "EVIDENCE",
    cmd: "evidence trace EV-131",
    hint: "Show provenance and consumers"
  }, {
    cat: "SYNTHESIS",
    cmd: "synthesis open --core",
    hint: "Expand the convergence core"
  }, {
    cat: "EVOLUTION",
    cmd: "generation diff 07 08",
    hint: "Compare baseline and candidate"
  }, {
    cat: "AI/ACC",
    cmd: "velocity report --window 24h",
    hint: "Generation velocity and throughput"
  }];
  return {
    mission,
    agents,
    clusters,
    edges,
    activePath,
    evidence,
    branches,
    missions,
    generation,
    capabilities,
    memory,
    cli,
    palette
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/data.js", error: String((e && e.message) || e) }); }

// ui_kits/aos-dashboard/doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * FIRST, decide how the document paginates — up front, before building:
 *
 * - FLOWING document (the default): write the whole document as one
 *   normal HTML flow inside <doc-page>; the browser's print engine
 *   splits it onto pages at export. Use for long-form documents with a
 *   single text flow: reports, memos, letters, essays.
 * - EXPLICIT pagination: a fixed set of pre-paginated pages, one
 *   <section class="page"> child per page. Use when the user asks for a
 *   specific page count, or the design implies one: a one-page resume, a
 *   two-sided flier, a poster, a certificate, a brochure — any richly
 *   laid-out document without a single text flow.
 * - If in doubt, ask the user as part of the build.
 *
 * PAGE SIZING — paper differs by country (letter vs A4), so the printed
 * sheet is not one fixed truth:
 * - FLOWING documents pin NO paper size: the print engine paginates
 *   onto the user's real paper, and the content reflows to it.
 * - EXPLICITLY PAGINATED documents print each page at a FIXED page box
 *   with overflow hidden — letter by default, size="a4" for a clearly
 *   metric user, the user's chosen paper when they export. Design each
 *   page to FILL that box, fitting letter and A4 alike without overlap.
 * - width/height pin an explicit fixed size, ONLY when the user gives
 *   one.
 * Never write your own @page rule or hard-code paper dimensions in the
 * content.
 *
 * Sizing modes (attributes):
 *   (none)                      — portrait: flowing docs use the user's
 *           paper; explicitly paginated pages use the named size box
 *           (letter unless size="a4")
 *   orientation="landscape"     — the same, landscape
 *   width / height              — explicit fixed size, ONLY when the user
 *           gives one (e.g. width="22in" height="30in" for a 22×30
 *           poster): the page IS the design's size, printed at true
 *           dimensions (or scaled onto the user's paper at print time).
 *           Any absolute CSS length: px/in/mm/cm/pt/pc.
 * The component announces the chosen mode to the host app at runtime (a
 * meta tag it injects), so the print path can inject the user's true
 * paper size.
 *
 * On screen the document renders on a desk background: a flowing
 * document as one tall scrolling sheet (Google Docs' pageless view);
 * explicitly paginated documents as one card per page.
 *
 * EXPLICIT pagination usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page>
 *     <section class="page" id="p1">…one page's design…</section>
 *     <section class="page" id="p2">…</section>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * How the page box works, concretely: each .page prints as ONE full-bleed
 * sheet at a FIXED physical size — letter by default (set size="a4" for
 * a clearly metric user), the user's chosen paper when they export —
 * with overflow hidden. Nothing scrolls and nothing reflows onto a next
 * sheet: content that misses the box is CLIPPED. Design each page to
 * FILL that page box, and to fit it — letter and A4 alike — without
 * overlap. Each page is a size container; don't size anything in
 * viewport units (they track the window, not the page), and never set
 * width or height on the .page section itself (the component sizes the
 * page box; an authored height like 100% is meaningless at print and is
 * overridden). The component owns the page box, the screen card chrome,
 * and the page breaks (never add your own break-before/after). Don't mix
 * .page sections with flowing content or header/footer slots in the same
 * document.
 *
 * FLOWING usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * There is no manual page-splitting — the browser's print engine
 * paginates at export. Standard break-hygiene rules (`break-inside:
 * avoid` on figures, code blocks, images and table rows; `orphans/
 * widows: 3`) are applied so paragraphs and groups split cleanly. On
 * screen and at print, headings default to `text-wrap: balance` and
 * body text to `text-wrap: pretty`; the defaults have zero specificity,
 * so any text-wrap you declare wins.
 *
 * Other attributes:
 *   size    — letter | a4 | legal (default letter). Flowing documents:
 *           preview proportion only — it does NOT pin their printed
 *           paper (the print dialog's paper governs); leave it alone
 *           there. Explicitly paginated documents: it sets the page box
 *           the cards and the pinned @page share (the export dialog's
 *           choice overrides both at print) — set size="a4" for a
 *           clearly metric user. Scaled-fit: names the sheet the fit is
 *           computed against, same a4-for-metric-users advice.
 *   content-width / content-height — the design's own fixed dimensions
 *           (CSS lengths), for scaling a fixed-size design ONTO the
 *           named sheet: content lays out at exactly this size, and the
 *           component scales it to fit that sheet's printable area
 *           (centered horizontally, top-aligned; the export dialog
 *           re-fits to the user's actual paper choice where available).
 *           Both must be set; they do not change the page box. For pages
 *           WITHOUT running header/footer slots.
 *   margin  — printable inset on every page of a FLOWING document
 *           (default 0.75in); margin="0" makes pages full-bleed.
 *           Explicitly paginated pages are always full-bleed.
 *
 * Running header/footer (flowing documents only): give an element
 * `slot="header"` or `slot="footer"` and it repeats on every printed
 * page via `position: fixed`. To keep body text from sliding under it,
 * the component prints inside a single-cell table whose <thead>/<tfoot>
 * are spacers sized to the header/footer height — browsers repeat
 * thead/tfoot on every page, so each sheet's content starts below the
 * header and ends above the footer. On screen the header/footer render
 * once at the top/bottom of the sheet.
 *
 * At print the component injects `@page { margin: 0 }` (which leaves
 * Chrome no margin box to draw its date/URL/page-count header in) and
 * moves the visual margin onto the sheet's own padding. It also marks
 * the document as owning its print CSS (a
 * `meta[name="omelette-owns-print"]` it injects at runtime), so the
 * PDF export never injects page-geometry CSS of its own on top.
 *
 * Print best practices for the content you author:
 * - Multi-column text: use CSS columns (`column-count` +
 *   `column-gap`), never side-by-side flex/grid columns — only real
 *   CSS columns flow and break across pages. `column-span: all` lets
 *   a heading span the columns; `hyphens: auto` (needs `lang` on
 *   the html element) keeps narrow columns readable.
 * - Page breaks in flowing documents: `break-before: page` on an
 *   element that must start a new page (a chapter, an appendix). Add
 *   your own kept-together blocks (callouts, stat tiles, cards) to a
 *   `break-inside: avoid` rule, and keep each one shorter than a page.
 * - Extend `orphans: 3; widows: 3` to any custom text blocks you add
 *   (p and li are covered by default).
 * - Give long tables a <thead> — browsers repeat it on every printed
 *   page.
 * - No `position: fixed`/`sticky` and no viewport units in content:
 *   fixed elements stamp every printed page (running headers/footers go
 *   in the component's slots) and `100vh` mis-sizes at print.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  // Unitless "0" is a valid CSS length and the natural way to write
  // margin="0"; normalise it to 0px so max()/calc() (which reject a bare
  // number) keep working.
  const safeLen = (v, fb) => {
    v = (v || '').trim();
    return v === '0' ? '0px' : CSS_LENGTH.test(v) ? v : fb;
  };
  // WebKit (Safari and every iOS browser shell) never repeats a table's
  // thead/tfoot on printed pages (WebKit bug 17205), so the spacer-borne
  // vertical margins of a FLOWING document reach only the first page
  // there. Engine check, not browser check: vendor is 'Apple Computer,
  // Inc.' exactly for WebKit and 'Google Inc.' for Blink.
  const WK_PRINT = /apple/i.test(navigator.vendor || '');
  // CSS length → px number (CSS absolute units are exact: 1in = 96px).
  // Returns NaN for anything safeLen would reject — callers gate on it.
  const PX_PER = {
    px: 1,
    in: 96,
    mm: 96 / 25.4,
    cm: 96 / 2.54,
    pt: 96 / 72,
    pc: 16
  };
  const toPx = v => {
    const m = /^(\d+(?:\.\d+)?)(px|in|mm|cm|pt|pc)$/.exec((v || '').trim());
    return m ? parseFloat(m[1]) * PX_PER[m[2]] : NaN;
  };
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      /* When the viewport is narrower than the page, grow to wrap the
       * sheet (plus this padding) instead of staying viewport-width, so
       * the desk background and right margin reach the sheet's far edge
       * in the horizontal scroll. */
      min-width: max-content;
      min-height: 100vh;
      background: #f5f5f4;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
      --doc-hdr-pad: 0px;
      --doc-ftr-pad: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 10px rgba(20, 20, 19, 0.12);
      border-radius: 7px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    /* Scaled-fit mode (content-width/content-height): the inner .fit box
     * lays the content out at its authored fixed size and scales it onto
     * the printable area; .fit-box reserves the scaled footprint in flow
     * (transforms don't affect layout) and centers it. Without the mode,
     * both divs are unstyled block pass-throughs. */
    /* Explicit pagination: direct .page children are the pages. The sheet
     * becomes a transparent stack and each page carries the card look on
     * screen; at print each page is exactly one full-bleed sheet. The
     * ::slotted defaults are deliberately weak (document CSS wins), so
     * authored page styling can override any of this. */
    .sheet.paginated {
      background: transparent;
      box-shadow: none;
      border-radius: 0;
      padding: 0;
    }
    .paginated ::slotted(.page) {
      position: relative;
      display: block;
      width: 100%;
      aspect-ratio: var(--doc-page-ar);
      container-type: size;
      overflow: hidden;
      box-sizing: border-box;
      background: #fff;
      border-radius: 7px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
      break-inside: avoid;
    }
    .paginated ::slotted(.page:not(:first-child)) { margin-top: 1rem; }
    @media print {
      .sheet.paginated { padding: 0; }
      /* The flowing-document vertical inset lives on the repeating
       * thead/tfoot spacers, not the sheet padding — they must go too,
       * or each full-sheet .page is pushed ~margin down and spills onto
       * a second sheet. Paginated pages are full-bleed by definition
       * (content owns its insets). */
      .sheet.paginated .hdr-space,
      .sheet.paginated .ftr-space { height: 0; }
      .paginated ::slotted(.page) {
        border-radius: 0 !important;
        box-shadow: none !important;
        margin: 0 !important;
        /* Physical page-box sizing, no viewport units: Safari resolves
         * 100vh against the window, not the page box, so a vh-sized card
         * paginates wrong there. --doc-page-w/h are the named size by
         * default and are overridden to the user's chosen paper by the
         * export path, so every card is exactly one sheet either way.
         * Width + height (same source values as @page size) rather than
         * width + aspect-ratio: the ratio is a 6-decimal rounding of the
         * same division, and a few millionths of overflow would spill a
         * blank sheet after every page. The screen-only aspect-ratio
         * (preview proportions) must not leak into print. cqh typography
         * tracks the same box.
         *
         * Every declaration is !important: per CSS Scoping, unimportant
         * shadow ::slotted rules LOSE to the document context, so a page
         * section's authored inline style would silently beat this print
         * geometry. A model-authored height:100% did exactly that — the
         * percentage resolves as auto in the all-auto print ancestry, the
         * base rule's size containment turns auto into ZERO, and
         * overflow:hidden then paints nothing: a blank PDF with perfect
         * page boxes. At print the component's geometry is the design's
         * whole contract, so it must win over any authored sizing. */
        aspect-ratio: auto !important;
        width: var(--doc-page-w) !important;
        height: var(--doc-page-h) !important;
        overflow: hidden !important;
      }
      .paginated ::slotted(.page:not(:first-child)) {
        break-before: page !important;
        margin-top: 0 !important;
      }
    }
    .fit-mode .fit-box {
      width: calc(var(--doc-fit-w) * var(--doc-fit-scale));
      height: calc(var(--doc-fit-h) * var(--doc-fit-scale));
      margin: 0 auto;
      break-inside: avoid;
    }
    /* Monolithic at print: Blink slices a transform-scaled child at
     * fragmentainer boundaries mapped in UNSCALED layout coordinates
     * (transforms are paint-time), so the .fit box (authored size, e.g.
     * 1400x990) gets cut at the page's free block space and spills onto
     * a second sheet even though its SCALED footprint fits the page by
     * construction. overflow:hidden makes .fit-box a scroll container —
     * monolithic under fragmentation (css-break-3) — so the scaled
     * content prints atomically on one sheet. No clipping for content
     * within the authored box: .fit-box is calc-sized to exactly the
     * scaled footprint. (Content that bleeds past content-width/height
     * is clipped at the footprint — fit mode's contract; it previously
     * painted beyond it at print.) Print-only, so the screen rendering
     * keeps visible overflow for editor affordances.
     * The export path injects the same rule into frozen copies
     * (print-eval.ts om-print-fit-contain). The .fit-mode scope is
     * load-bearing: .fit-box wraps slotted content in EVERY mode, and an
     * unscoped overflow:hidden would make whole flowing documents
     * monolithic (one truncated sheet). overflow:hidden, never clip —
     * clip is not a scroll container, so not monolithic. */
    @media print {
      .fit-mode .fit-box { overflow: hidden; }
    }
    .fit-mode .fit {
      width: var(--doc-fit-w);
      height: var(--doc-fit-h);
      transform: scale(var(--doc-fit-scale));
      transform-origin: top left;
    }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-width: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      /* The 0.35in is breathing room between a running header/footer and
       * the body; without one the spacer is exactly the page margin, so a
       * margin="0" full-bleed document gets truly full-bleed pages. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))); }
      /* WebKit flowing documents: @page carries the vertical margin (see
       * _syncPrintPageRule), so the spacers keep only whatever a running
       * header/footer needs BEYOND it — page 1 would otherwise double its
       * top inset. Paginated sheets already zero their spacers above. */
      .sheet.wk-print:not(.paginated) .hdr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))) - var(--doc-page-margin))); }
      .sheet.wk-print:not(.paginated) .ftr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))) - var(--doc-page-margin))); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin', 'orientation', 'content-width', 'content-height'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }

    /** The named paper's [w, h], swapped when orientation="landscape".
     *  Only the named size swaps — explicit width/height are exact values
     *  the author already oriented. */
    _paperSize() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()] || PAPER.letter;
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? [named[1], named[0]] : named;
    }
    get pageWidth() {
      return safeLen(this.getAttribute('width'), this._paperSize()[0]);
    }
    get pageHeight() {
      return safeLen(this.getAttribute('height'), this._paperSize()[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }

    /** Scaled-fit mode's content box [w, h] as CSS lengths, or null when
     *  the mode is off (either attribute missing/invalid/zero — a partial
     *  declaration falls back to normal flow rather than guessing). */
    _contentFit() {
      const w = safeLen(this.getAttribute('content-width'), null);
      const h = safeLen(this.getAttribute('content-height'), null);
      if (!w || !h) return null;
      const wPx = toPx(w),
        hPx = toPx(h);
      return wPx > 0 && hPx > 0 ? [w, h, wPx, hPx] : null;
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      this._ensureTextWrapDefaults();
      this._ensureOwnsPrintMeta();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rules when the last doc-page leaves, so a deleted
      // document's @page geometry and text-wrap defaults can't apply to
      // whatever replaces it.
      const survivor = document.querySelector('doc-page');
      if (!survivor) {
        ['doc-page-print', 'doc-page-text-wrap', 'doc-page-owns-print', 'doc-page-fixed-size', 'doc-page-print-sizing'].forEach(id => {
          const tag = document.getElementById(id);
          if (tag) tag.remove();
        });
        // A live deck-stage deferred its own print-sizing meta to ours —
        // hand the page-global meta over so the deck isn't left unmarked.
        const deck = document.querySelector('deck-stage');
        if (deck && typeof deck._ensurePrintSizingMeta === 'function') {
          deck._ensurePrintSizingMeta();
        }
      } else {
        // A departed owner hands each page-global meta to whatever
        // doc-page remains (or it's removed).
        if (typeof survivor._syncFixedSizeMeta === 'function') {
          survivor._syncFixedSizeMeta();
        }
        if (typeof survivor._syncPrintSizingMeta === 'function') {
          survivor._syncPrintSizingMeta();
        }
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><div class="fit-box"><div class="fit"><slot></slot></div></div></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      // Scaled-fit mode: content at its authored size, scaled onto the
      // printable area (page minus margins on both axes). The factor is a
      // plain number var so calc(length * number) stays valid; 4 decimals
      // keeps the shadow style stable across re-measures. Upscaling is
      // allowed — print transforms are vector, so text and CSS stay crisp
      // (raster images soften, which the catalog bullet warns about).
      const fit = this._contentFit();
      let fitVars = '';
      if (fit) {
        const marginPx = toPx(this.pageMargin) || 0;
        const availW = toPx(this.pageWidth) - 2 * marginPx;
        const availH = toPx(this.pageHeight) - 2 * marginPx;
        const scale = Math.min(availW / fit[2], availH / fit[3]);
        if (scale > 0 && Number.isFinite(scale)) {
          fitVars = '--doc-fit-w:' + fit[0] + ';' + '--doc-fit-h:' + fit[1] + ';' + '--doc-fit-scale:' + scale.toFixed(4) + ';';
        }
      }
      this._sheet.classList.toggle('fit-mode', !!fitVars);
      // Numeric w/h ratio for the paginated page cards' aspect-ratio —
      // aspect-ratio takes a number, not a length ratio, so compute it
      // here (CSS length division isn't portable). 6 decimals keeps the
      // shadow style stable across re-syncs.
      const arW = toPx(this.pageWidth);
      const arH = toPx(this.pageHeight);
      const ar = arW > 0 && arH > 0 ? (arW / arH).toFixed(6) : '0.772727';
      this._vars.textContent = ':host{' + fitVars + '--doc-page-ar:' + ar + ';' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px;' + '--doc-hdr-pad:' + (hdrH ? '0.35in' : '0px') + ';' + '--doc-ftr-pad:' + (ftrH ? '0.35in' : '0px') + '}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document.
     *
     *  The @page SIZE is pinned where the page box IS part of the design:
     *  explicit-fixed-size mode (width + height authored), scaled-fit
     *  mode (the named sheet the fit targets), and explicit pagination
     *  (the named size the cards share — so card and sheet agree on
     *  every print path, and the export path's chosen paper overrides
     *  BOTH with one later rule). For FLOWING documents no paper size is
     *  emitted at all — the true size comes from the user's preference,
     *  injected by the export path or chosen in the print dialog — so a
     *  flowing document never fights the paper it lands on.
     *  margin: 0 is emitted in every mode: it leaves Chrome no margin box
     *  to draw its date/URL/page-count header in, and the visual margin
     *  lives on the sheet's own padding. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      // Three print-geometry regimes:
      // - true-size: the page IS the design — pin its exact size.
      // - scaled-fit (content-width/height): the fit factor is computed
      //   against the NAMED paper's printable area, so that paper must
      //   stay pinned or the scaled content overflows a smaller sheet
      //   (the export path re-fits and re-pins at print time on top).
      // - default modes: no paper size — but landscape still needs the
      //   paper-agnostic 'size: landscape' keyword, because the size
      //   descriptor is what carries orientation; without it a landscape
      //   document prints portrait whenever nothing injects a size.
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      // Explicit pagination pins the page box to the SAME values that
      // size the cards (the named size by default, the export path's
      // chosen paper when its later rule overrides both) — card and
      // sheet agree on every print path, and a mismatched real paper
      // shrinks-to-fit in the dialog instead of clipping a Letter card
      // on A4. Declared before the paginated read below so both derive
      // from one check.
      const paginatedNow = this.querySelector(':scope > .page') !== null;
      const sizeDescriptor = this._trueSizePx() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : this._contentFit() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : paginatedNow ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : landscape ? 'size: landscape; ' : '';
      // WebKit never repeats the thead/tfoot spacers that carry a flowing
      // document's vertical page margins (see WK_PRINT above), so pages
      // after the first print edge-to-edge there. Carry the VERTICAL
      // margins on @page for WebKit instead, and the shadow print CSS
      // trims the first-page spacers by the same amount (.sheet.wk-print
      // rules). Horizontal inset stays on the sheet's own padding in
      // every engine. Blink keeps margin: 0 (a nonzero margin there
      // re-opens the box Chrome draws its header furniture in). One cost,
      // learned in testing: Safari's own date/URL headers are a USER
      // dialog setting ("Print headers and footers") that renders in the
      // margin area when room exists — margin: 0 only suppressed it by
      // leaving no room, and no CSS controls it. The export dialog's
      // Safari guide teaches turning the setting off for flowing
      // documents. Explicitly paginated and fixed-size documents keep
      // margin: 0 everywhere: their pages ARE the sheet.
      const wkFlowing = WK_PRINT && !paginatedNow && !this._trueSizePx() && !this._contentFit();
      const marginDescriptor = wkFlowing ? 'margin: ' + this.pageMargin + ' 0; ' : 'margin: 0; ';
      // Shadow-internal marker (never serialized), kept in lockstep with
      // the @page decision above: the print CSS trims the first-page
      // spacers ONLY while @page actually carries the margins — a
      // true-size or scaled-fit sheet keeps margin: 0 and must keep its
      // spacers too. Re-synced here so attribute changes and pagination
      // flips move both together.
      if (this._sheet) this._sheet.classList.toggle('wk-print', wkFlowing);
      tag.textContent = '@page { ' + sizeDescriptor + marginDescriptor + '} ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; ' + 'backdrop-filter: none !important; -webkit-backdrop-filter: none !important; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }

    /** Typographic defaults for document text: balance headings, avoid
     *  widowed/orphaned words in body copy (browsers without text-wrap
     *  support drop the declarations). Zero-specificity via :where() so
     *  any text-wrap authored on those elements wins; document-level so the
     *  rules reach the slotted (light DOM) content — shadow styles can't.
     *  data-omelette-injected marks the tag for the host editor to strip
     *  at serialize, so it is never written back as authored source. */
    _ensureTextWrapDefaults() {
      if (document.getElementById('doc-page-text-wrap')) return;
      const tag = document.createElement('style');
      tag.id = 'doc-page-text-wrap';
      tag.setAttribute('data-omelette-injected', '');
      tag.textContent = ':where(h1,h2,h3,h4,h5,h6){text-wrap:balance}' + ':where(p,li,blockquote,figcaption){text-wrap:pretty}';
      document.head.appendChild(tag);
    }

    /** Declares that this document owns its print CSS. The instant-PDF
     *  export checks for the meta by NAME PRESENCE alone (content is
     *  ignored) and skips its automatic print-CSS injections, so the
     *  component's @page geometry is never overridden by a heuristic.
     *  data-omelette-injected keeps it out of serialized source. */
    _ensureOwnsPrintMeta() {
      if (document.getElementById('doc-page-owns-print')) return;
      const tag = document.createElement('meta');
      tag.id = 'doc-page-owns-print';
      tag.name = 'omelette-owns-print';
      tag.content = 'true';
      tag.setAttribute('data-omelette-injected', '');
      document.head.appendChild(tag);
    }

    /** This page's valid true-size page box (explicit width AND height)
     *  as [w, h] px ints, or null when the mode is off. */
    _trueSizePx() {
      if (!safeLen(this.getAttribute('width'), null) || !safeLen(this.getAttribute('height'), null)) return null;
      const w = Math.round(toPx(this.pageWidth));
      const h = Math.round(toPx(this.pageHeight));
      return w > 0 && h > 0 ? [w, h] : null;
    }

    /** True-size pages (explicit width AND height) also declare the page
     *  box as the preview size: the in-app preview reads
     *  meta[name="omelette-fixed-size"] (content "W,H" in px ints) and
     *  scales the sheet into view — without it an 18in poster previews at
     *  true size with scrollbars. Never overrides an author-set meta
     *  (only the component's own id is managed). The meta is page-global
     *  while doc-page instances are not, so every sync recomputes the
     *  page-wide owner — the first connected true-size doc-page — and a
     *  non-true-size sibling's sync can never delete the owner's meta.
     *  Removed when no true-size page remains (the owner's disconnect
     *  re-syncs via any survivor) or when an author-set meta exists. */
    _syncFixedSizeMeta() {
      const id = 'doc-page-fixed-size';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-fixed-size"]:not([data-omelette-injected])');
      // The page-wide owner, not this instance: an upgraded true-size page
      // anywhere in the document keeps the meta alive and sized.
      let box = null;
      for (const el of document.querySelectorAll('doc-page')) {
        box = typeof el._trueSizePx === 'function' ? el._trueSizePx() : null;
        if (box) break;
      }
      if (!box || authored) {
        if (own) own.remove();
        return;
      }
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-fixed-size';
      tag.content = box[0] + ',' + box[1];
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }

    /** This page's print-sizing mode: 'fixed' when an explicit width AND
     *  height are authored (the page is the design's own size), else the
     *  default paper in the authored orientation. */
    _printSizingMode() {
      if (this._trueSizePx()) return 'fixed';
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? 'default-landscape' : 'default-portrait';
    }

    /** Announces the print-sizing mode to the host app:
     *  meta[name="omelette-print-sizing"] with content 'default-portrait',
     *  'default-landscape', or 'fixed' (fixed pages also carry the
     *  omelette-fixed-size meta with the page box in px). The export path
     *  probes it to decide what true paper size to inject at print time —
     *  in the default modes the component emits no paper size of its own.
     *  Same page-global ownership rules as the fixed-size meta above:
     *  first connected doc-page owns it, an authored meta is never
     *  overridden, removed when no doc-page remains. */
    _syncPrintSizingMeta() {
      const id = 'doc-page-print-sizing';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-print-sizing"]:not([data-omelette-injected])');
      // A fixed page wins outright (mirroring the fixed-size loop above,
      // so the two metas can never contradict each other in a mixed
      // multi-page document); otherwise the first page's mode holds.
      let mode = null;
      for (const el of document.querySelectorAll('doc-page')) {
        if (typeof el._printSizingMode !== 'function') continue;
        const m = el._printSizingMode();
        if (m === 'fixed') {
          mode = m;
          break;
        }
        if (mode === null) mode = m;
      }
      if (!mode || authored) {
        if (own) own.remove();
        return;
      }
      // A deck-stage that connected first injected its own meta and
      // defers to any existing one — take it over, or the document ends
      // up with two conflicting injected metas (a doc-page page is the
      // document; the deck re-ensures its meta if every doc-page leaves).
      const deckMeta = document.getElementById('deck-stage-print-sizing');
      if (deckMeta) deckMeta.remove();
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-print-sizing';
      tag.content = mode;
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. The
     *  same pass detects explicit pagination (direct .page children) and
     *  toggles the sheet between the flowing-document card and the
     *  page-per-card stack — content edits can add or remove pages at any
     *  time, so this tracks the same mutations the measurement does. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      const wasPaginated = this._sheet.classList.contains('paginated');
      this._sheet.classList.toggle('paginated', this.querySelector(':scope > .page') !== null);
      // The WebKit @page margin is flowing-only, so a pagination flip
      // must re-emit the rule (content edits can add or remove .page
      // sections at any time).
      if (this._sheet.classList.contains('paginated') !== wasPaginated) {
        this._syncPrintPageRule();
      }
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-dashboard/doc-page.js", error: String((e && e.message) || e) }); }

// ui_kits/aos-mobile/MobileApp.jsx
try { (() => {
const {
  Aperture,
  Button,
  StateBadge,
  Telemetry,
  SectionLabel,
  ContextInspector,
  CLISheet,
  DecisionGate,
  ClusterAggregate
} = window.AOSDesignSystem_20e4c5;
const DMob = window.AOSDATA;
const STAGES = [{
  key: "FRONTIER",
  label: "Frontier",
  note: "Unresolved",
  ids: []
}, {
  key: "CONVERGENCE",
  label: "Convergence",
  note: "6 branches compressing",
  ids: ["CORE"]
}, {
  key: "MUTATION",
  label: "Mutation",
  note: "GEN 08 candidate",
  ids: ["V-03", "CL-2"]
}, {
  key: "SWARM",
  label: "Swarm",
  note: "9 active of 41",
  ids: ["L-01", "A-07", "A-22", "A-31", "A-14", "A-19", "CL-1"]
}, {
  key: "CONSTRAINT",
  label: "Constraint",
  note: "2.5M tokens · primary sources only",
  ids: ["OBJ"]
}];
function Rail({
  route,
  onMenu
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      flex: "none",
      height: "48px",
      display: "flex",
      alignItems: "center",
      gap: "10px",
      padding: "0 14px",
      background: "var(--void)",
      borderBottom: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(Aperture, {
    size: 15,
    tone: "white",
    state: "running"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 17px/1 var(--font-display)",
      letterSpacing: "0.08em",
      color: "var(--cold-white)"
    }
  }, "AOS"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 10px/1 var(--font-interface)",
      letterSpacing: "0.14em",
      color: "var(--quiet-metal)"
    }
  }, route), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1 var(--font-telemetry)",
      padding: "3px 5px",
      border: "1px solid var(--quiet-metal)",
      color: "var(--quiet-metal)"
    }
  }, "ILLUSTRATIVE"), /*#__PURE__*/React.createElement("button", {
    onClick: onMenu,
    style: {
      background: "transparent",
      border: "1px solid var(--border-on-dark-strong)",
      color: "var(--cold-white)",
      height: "26px",
      padding: "0 8px",
      font: "400 11px/1 var(--font-telemetry)",
      cursor: "pointer"
    }
  }, "CMD"));
}
function AgentRow({
  a,
  onSelect
}) {
  const cluster = a.kind === "cluster";
  return /*#__PURE__*/React.createElement("button", {
    onClick: () => onSelect(a.id),
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%",
      textAlign: "left",
      padding: "11px 14px 11px",
      paddingLeft: `${14 + (a.depth || 0) * 10}px`,
      background: "transparent",
      border: "none",
      borderBottom: "1px solid var(--border-on-dark)",
      borderLeft: `3px solid ${cluster ? "var(--quiet-metal-dim)" : a.state === "running" ? "var(--cobalt)" : a.state === "complete" ? "var(--ion)" : a.state === "blocked" ? "var(--vermilion)" : a.state === "handoff" ? "var(--ultraviolet)" : "var(--quiet-metal-dim)"}`,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "10px",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 13px/1.1 var(--font-interface)",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "var(--cold-white)"
    }
  }, cluster ? `${a.label} ×${a.count}` : a.role), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1 var(--font-telemetry)",
      color: "var(--quiet-metal-dim)",
      flex: "none"
    }
  }, a.id)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "10px",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1.3 var(--font-telemetry)",
      color: "var(--text-on-dark-secondary)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, cluster ? `← ${a.owner} · aggregated` : `${a.harness} / ${a.model}`), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 10px/1 var(--font-telemetry)",
      color: "var(--text-on-dark-secondary)",
      flex: "none",
      fontVariantNumeric: "tabular-nums"
    }
  }, a.tokens, " \xB7 ", a.cost || "—")), !cluster ? /*#__PURE__*/React.createElement(StateBadge, {
    on: "dark",
    state: a.state,
    form: "bare"
  }) : null);
}
function MobileApp() {
  const [open, setOpen] = React.useState(["SWARM", "CONVERGENCE"]);
  const [sel, setSel] = React.useState(null);
  const [cliOpen, setCliOpen] = React.useState(false);
  const [gateOpen, setGateOpen] = React.useState(true);
  const items = [...DMob.agents, ...DMob.clusters];
  const selected = items.find(i => i.id === sel);
  const toggle = k => setOpen(o => o.includes(k) ? o.filter(x => x !== k) : [...o, k]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--void)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(Rail, {
    route: "SWARM",
    onMenu: () => setCliOpen(true)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--cobalt)",
      padding: "18px 14px 16px",
      display: "flex",
      flexDirection: "column",
      gap: "14px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 10px/1 var(--font-telemetry)",
      letterSpacing: "0.1em",
      color: "var(--text-on-field-secondary)"
    }
  }, DMob.mission.id, " \xB7 GEN ", DMob.mission.generation, " \xB7 1 GATE OPEN"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: "400 30px/0.98 var(--font-display)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--cold-white)",
      textWrap: "pretty"
    }
  }, DMob.mission.goal), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(2,1fr)",
      gap: "10px 18px"
    }
  }, [["AGENTS", "9/41"], ["TOKENS", DMob.mission.tokens], ["COST", DMob.mission.cost], ["ELAPSED", DMob.mission.elapsed]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "3px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "400 9px/1 var(--font-telemetry)",
      letterSpacing: "0.12em",
      color: "var(--text-on-field-secondary)"
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 16px/1 var(--font-telemetry)",
      color: "var(--cold-white)",
      fontVariantNumeric: "tabular-nums"
    }
  }, v))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 14px 8px"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    on: "dark",
    rule: true
  }, "Stages")), STAGES.map((s, i) => {
    const isOpen = open.includes(s.key);
    const rows = s.ids.map(id => items.find(x => x.id === id)).filter(Boolean);
    return /*#__PURE__*/React.createElement("section", {
      key: s.key
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => toggle(s.key),
      style: {
        display: "flex",
        alignItems: "center",
        gap: "12px",
        width: "100%",
        textAlign: "left",
        padding: "13px 14px",
        background: "transparent",
        border: "none",
        borderTop: "1px solid var(--border-on-dark)",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "400 10px/1 var(--font-telemetry)",
        color: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)",
        width: "18px",
        flex: "none"
      }
    }, String(STAGES.length - i).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        gap: "4px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "500 15px/1 var(--font-display)",
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: i === 0 ? "var(--ultraviolet)" : "var(--cold-white)"
      }
    }, s.label), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "400 11px/1.3 var(--font-telemetry)",
        color: "var(--quiet-metal)"
      }
    }, s.note)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "400 11px/1 var(--font-telemetry)",
        color: "var(--quiet-metal)",
        flex: "none"
      }
    }, rows.length ? isOpen ? "−" : `+${rows.length}` : "—")), isOpen ? rows.map(a => /*#__PURE__*/React.createElement(AgentRow, {
      key: a.id,
      a: a,
      onSelect: setSel
    })) : null);
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 14px 24px",
      borderTop: "1px solid var(--border-on-dark)",
      font: "400 11px/1.6 var(--font-telemetry)",
      color: "var(--quiet-metal-dim)"
    }
  }, "The spatial field does not shrink to this width. Stages keep the same causal order: constraint below, frontier above.", /*#__PURE__*/React.createElement("br", null), "AI/ACC")), gateOpen ? /*#__PURE__*/React.createElement(DecisionGate, {
    open: true,
    authority: "OPERATOR",
    prompt: "A-22 blocked by a rate limit.",
    choices: [{
      label: "Wait 41s",
      consequence: "Dependents queued",
      reversible: true,
      variant: "secondary"
    }, {
      label: "Reroute",
      consequence: "Loses cite-check",
      reversible: true,
      variant: "primary"
    }],
    onChoose: () => setGateOpen(false),
    style: {
      flex: "none",
      flexDirection: "column"
    }
  }) : null, /*#__PURE__*/React.createElement(CLISheet, {
    expanded: cliOpen,
    lines: DMob.cli,
    context: `mission/${DMob.mission.id}`,
    simulated: true,
    hint: "TAP",
    onToggle: () => setCliOpen(v => !v),
    style: {
      flex: "none"
    }
  }), selected ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      background: "rgba(5,5,9,0.6)"
    },
    onClick: () => setSel(null)
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      height: "72%"
    }
  }, /*#__PURE__*/React.createElement(ContextInspector, {
    open: true,
    kind: selected.kind === "cluster" ? "CLUSTER" : "AGENT",
    title: selected.role || selected.label,
    subtitle: selected.kind === "cluster" ? `${selected.id} · ${selected.count} workers` : `${selected.id} · ${selected.harness} / ${selected.model}`,
    sections: selected.kind === "cluster" ? [{
      label: "Aggregate",
      rows: [{
        k: "Workers",
        v: String(selected.count)
      }, {
        k: "Owner",
        v: selected.owner
      }, {
        k: "Tokens",
        v: selected.tokens
      }, {
        k: "Cost",
        v: selected.cost,
        tone: "active"
      }]
    }] : [{
      label: "Ownership",
      rows: [{
        k: "Owner",
        v: selected.owner
      }, {
        k: "Workspace",
        v: selected.workspace
      }]
    }, {
      label: "Runtime",
      rows: [{
        k: "Harness",
        v: selected.harness
      }, {
        k: "Model",
        v: selected.model
      }, {
        k: "Reasoning",
        v: selected.reasoning
      }, {
        k: "Context",
        v: selected.context
      }]
    }, {
      label: "Resource",
      rows: [{
        k: "Tokens",
        v: selected.tokens
      }, {
        k: "Cost",
        v: selected.cost,
        tone: "active"
      }, {
        k: "Elapsed",
        v: selected.elapsed
      }]
    }, {
      label: "Work",
      rows: [{
        k: "Evidence",
        v: String(selected.evidence),
        tone: "verified"
      }, {
        k: "Dependencies",
        v: String(selected.deps)
      }]
    }],
    onClose: () => setSel(null),
    actions: /*#__PURE__*/React.createElement(Button, {
      on: "dark",
      variant: "secondary",
      size: "sm",
      full: true,
      onClick: () => setSel(null)
    }, "Close"),
    style: {
      width: "100%",
      height: "100%",
      borderLeft: "none",
      borderTop: "1px solid var(--border-on-dark-strong)"
    }
  }))) : null);
}
Object.assign(window, {
  MobileApp
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aos-mobile/MobileApp.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Aperture = __ds_scope.Aperture;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.StateBadge = __ds_scope.StateBadge;

__ds_ns.Telemetry = __ds_scope.Telemetry;

__ds_ns.EvidencePlate = __ds_scope.EvidencePlate;

__ds_ns.GenerationRift = __ds_scope.GenerationRift;

__ds_ns.ObjectiveAperture = __ds_scope.ObjectiveAperture;

__ds_ns.CLISheet = __ds_scope.CLISheet;

__ds_ns.ContextInspector = __ds_scope.ContextInspector;

__ds_ns.DecisionGate = __ds_scope.DecisionGate;

__ds_ns.GlobalRail = __ds_scope.GlobalRail;

__ds_ns.AccelerationField = __ds_scope.AccelerationField;

__ds_ns.AgentNode = __ds_scope.AgentNode;

__ds_ns.AgentTrace = __ds_scope.AgentTrace;

__ds_ns.ClusterAggregate = __ds_scope.ClusterAggregate;

__ds_ns.ConvergenceCore = __ds_scope.ConvergenceCore;

})();
