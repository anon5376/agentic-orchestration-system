The swarm's atom. Role, id, harness/model, state, tokens · cost · elapsed, and evidence/dependency counts. Nothing else.

```jsx
<AgentNode onPath onSelect={setSel} agent={{
  id: "A-14", role: "Corpus triage", harness: "Claude Code", model: "sonnet-4",
  state: "running", tokens: "412K", cost: "$4.90", elapsed: "07:22", evidence: 12, deps: 2
}} />
```

- Left edge is 3px in the state colour; selection inverts the plate to cobalt with a white edge.
- Use `compact` below 1200px. Extra metadata goes to `ContextInspector`, never onto the node.
