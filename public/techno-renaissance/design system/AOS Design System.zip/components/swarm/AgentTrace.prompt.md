Delegation and dependency edges. Orthogonal elbows only — direction must be unambiguous.

```jsx
<svg width={720} height={420} viewBox="0 0 720 420">
  <AgentTrace from={{x:180,y:360}} to={{x:320,y:240}} state="stable" throughput={0.7} />
  <AgentTrace from={{x:320,y:240}} to={{x:560,y:240}} kind="dependency" label="WAITS ON A-22" />
</svg>
```

- Coordinates are pixels in the parent svg space; never scale the svg non-uniformly.
- Thickness encodes throughput; never thicken for emphasis.
- Ownership (delegation) and scheduling (dependency) are different edges and must stay visually distinct.
