/** A directional line with source, destination, state and temporal character.
 * Returns SVG nodes — render inside an <svg> (AccelerationField does), or pass
 * `wrap` for a standalone diagram. Coordinates are PIXELS in the parent svg's
 * own coordinate space (no non-uniform scaling: markers and labels stay true). */
export interface TracePoint { x: number; y: number }
export interface AgentTraceProps {
  from?: TracePoint;
  to?: TracePoint;
  /** stable = cobalt; waiting = broken metal; verified = ion endpoint; conflict = vermilion interruption; handoff = ultraviolet phase mark; dormant = faint. */
  state?: "stable" | "waiting" | "verified" | "conflict" | "handoff" | "dormant";
  /** delegation = elbow down-the-tree; dependency = dashed lateral edge. */
  kind?: "delegation" | "dependency";
  /** 0..1 — thickness only when backed by throughput or urgency data. */
  throughput?: number;
  label?: string;
  wrap?: boolean;
  width?: string | number;
  height?: string | number;
  viewBox?: string;
}
export declare function AgentTrace(props: AgentTraceProps): JSX.Element;
