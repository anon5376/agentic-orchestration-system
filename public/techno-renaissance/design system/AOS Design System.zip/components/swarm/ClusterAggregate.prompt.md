How AOS shows an unbounded swarm without drawing it.

```jsx
<ClusterAggregate label="Source scanners" count={34} owner="A-07" tokens="2.1M" cost="$18.60"
  distribution={{ running: 6, complete: 25, waiting: 2, failed: 1 }} onExpand={expand} />
```

- Use whenever more than ~8 siblings do the same low-value work, or whenever a branch is dormant.
- The distribution bar is the only chart in the system; it must sum to the count.
- Expansion happens in place or as a new scale — lineage is always preserved.
