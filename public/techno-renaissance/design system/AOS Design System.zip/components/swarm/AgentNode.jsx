import React from "react";
import { StateBadge } from "../core/StateBadge.jsx";

const EDGE = {
  running: "var(--cobalt)",
  waiting: "var(--quiet-metal-dim)",
  blocked: "var(--ultraviolet)",
  failed: "var(--vermilion)",
  complete: "var(--ion)",
  dormant: "var(--quiet-metal-dim)",
  handoff: "var(--ultraviolet)",
  gate: "var(--vermilion)"
};

/* One owned task in the hierarchy. Carries only the facts needed to read the
   causal path: role, owner, harness/model, state, tokens, cost, elapsed.
   Everything else belongs in the ContextInspector. */
export function AgentNode({
  agent,
  selected = false,
  onPath = false,
  dim = false,
  compact = false,
  width,
  onSelect,
  style,
  ...rest
}) {
  const a = agent || {};
  const accent = EDGE[a.state] || EDGE.waiting;
  const nodeSx = {
    display: "flex",
    flexDirection: "column",
    gap: compact ? "4px" : "6px",
    width: width || (compact ? "186px" : "212px"),
    padding: compact ? "8px 10px" : "10px 12px",
    textAlign: "left",
    background: selected ? "var(--cobalt)" : onPath ? "var(--void-plate)" : "var(--void-raise)",
    border: `1px solid ${selected ? "var(--cold-white)" : onPath ? accent : "var(--border-on-dark)"}`,
    borderLeft: `${selected ? 1 : 3}px solid ${selected ? "var(--cold-white)" : accent}`,
    borderRadius: "var(--radius-none)",
    color: selected ? "var(--cold-white)" : "var(--text-on-dark)",
    opacity: dim ? "var(--opacity-recede)" : 1,
    cursor: onSelect ? "pointer" : "default",
    transition: "opacity var(--dur-state) var(--ease-instrument),background var(--dur-state) var(--ease-instrument),border-color var(--dur-state) var(--ease-instrument)",
    ...style
  };
  const metaSx = {
    font: `var(--weight-regular) var(--type-telemetry-sm)/1.25 var(--font-telemetry)`,
    color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)",
    letterSpacing: "var(--tracking-telemetry)",
    display: "flex",
    gap: "6px",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  };
  return (
    <div role={onSelect ? "button" : undefined} onClick={onSelect ? () => onSelect(a.id) : undefined} style={nodeSx} {...rest}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "var(--space-3)" }}>
        <span
          style={{
            font: `var(--weight-medium) ${compact ? "12px" : "13px"}/1.1 var(--font-interface)`,
            letterSpacing: "var(--tracking-label-tight)",
            textTransform: "uppercase",
            color: "var(--cold-white)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {a.role}
        </span>
        <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal-dim)" }}>
          {a.id}
        </span>
      </div>
      <div style={metaSx}>
        <span style={{ color: selected ? "var(--cold-white)" : "var(--text-on-dark-secondary)" }}>{a.harness}</span>
        <span style={{ opacity: 0.5 }}>/</span>
        <span>{a.model}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-3)" }}>
        <StateBadge state={a.state} on={selected ? "field" : "dark"} form="bare" />
        <span
          style={{
            font: `var(--weight-medium) 10px/1 var(--font-telemetry)`,
            color: selected ? "var(--cold-white)" : "var(--text-on-dark-secondary)",
            fontVariantNumeric: "tabular-nums",
            whiteSpace: "nowrap"
          }}
        >
          {a.tokens} · {a.cost} · {a.elapsed}
        </span>
      </div>
      {!compact && (a.evidence || a.deps) ? (
        <div style={{ display: "flex", gap: "var(--space-4)", paddingTop: "4px", borderTop: `1px solid ${selected ? "var(--border-on-field)" : "var(--border-on-dark)"}` }}>
          {a.evidence != null ? (
            <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)" }}>
              EVID {a.evidence}
            </span>
          ) : null}
          {a.deps != null ? (
            <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: selected ? "var(--text-on-field-secondary)" : "var(--quiet-metal)" }}>
              DEPS {a.deps}
            </span>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
