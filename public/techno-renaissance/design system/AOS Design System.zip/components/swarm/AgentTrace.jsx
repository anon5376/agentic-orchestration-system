import React from "react";

const TRACE = {
  stable: { stroke: "var(--trace-stable-on-dark)", dash: null, opacity: 1 },
  waiting: { stroke: "var(--trace-idle)", dash: "4 4", opacity: 0.9 },
  verified: { stroke: "var(--trace-verified)", dash: null, opacity: 1 },
  conflict: { stroke: "var(--trace-conflict)", dash: "6 3", opacity: 1 },
  handoff: { stroke: "var(--trace-handoff)", dash: null, opacity: 1 },
  dormant: { stroke: "var(--trace-idle)", dash: "1 4", opacity: 0.55 },
  dependency: { stroke: "var(--quiet-metal)", dash: "2 3", opacity: 0.8 }
};

/* A directional line with source, destination, state and temporal character.
   Renders SVG nodes in the parent's pixel coordinate space: place inside an
   <svg> (AccelerationField does this), or pass `wrap` for a standalone
   diagram. Orthogonal elbows only — direction must never be ambiguous. */
export function AgentTrace({
  from = { x: 40, y: 300 },
  to = { x: 200, y: 120 },
  state = "stable",
  kind = "delegation",
  throughput = 0.4,
  label,
  wrap = false,
  width = 320,
  height = 360,
  viewBox
}) {
  const t = kind === "dependency" ? TRACE.dependency : TRACE[state] || TRACE.stable;
  const mid = from.y + (to.y - from.y) / 2;
  const d =
    kind === "dependency"
      ? `M${from.x} ${from.y} H${from.x + (to.x - from.x) / 2} V${to.y} H${to.x}`
      : `M${from.x} ${from.y} V${mid} H${to.x} V${to.y}`;
  const sw = 1 + Math.max(0, Math.min(1, throughput)) * 2.2;

  const body = (
    <g>
      <path d={d} fill="none" stroke={t.stroke} strokeWidth={sw} strokeDasharray={t.dash || undefined} strokeOpacity={t.opacity} />
      {state === "verified" ? <circle cx={to.x} cy={to.y} r="3" fill="var(--ion)" /> : null}
      {state === "conflict" ? (
        <g stroke="var(--vermilion)" strokeWidth="1.5">
          <path d={`M${to.x - 4} ${to.y - 4} L${to.x + 4} ${to.y + 4}`} />
          <path d={`M${to.x + 4} ${to.y - 4} L${to.x - 4} ${to.y + 4}`} />
        </g>
      ) : null}
      {state === "handoff" ? <rect x={to.x - 1.5} y={mid - 6} width="3" height="12" fill="var(--ultraviolet)" /> : null}
      {label ? (
        <text x={to.x + 7} y={mid - 4} fill="var(--quiet-metal)" style={{ font: "400 10px var(--font-telemetry)", letterSpacing: "0.08em" }}>
          {label}
        </text>
      ) : null}
    </g>
  );

  if (!wrap) return body;
  return (
    <svg width={width} height={height} viewBox={viewBox || `0 0 ${width} ${height}`} style={{ display: "block", overflow: "visible" }}>
      {body}
    </svg>
  );
}
