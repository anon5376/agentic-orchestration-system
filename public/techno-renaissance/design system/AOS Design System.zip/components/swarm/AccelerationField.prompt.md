The dominant region of `#/swarm`. Not a node cloud: geometry is delegation depth, and only the active neighbourhood is drawn.

```jsx
<AccelerationField height={560} activePath={["L-01","A-07","A-14","CORE"]} selectedId={sel} onSelect={setSel}
  items={[
    { id: "OBJ", depth: 0, role: "Objective", state: "running", harness: "AOS", model: "lead", tokens: "—", cost: "$61.20", elapsed: "01:12:44" },
    { id: "L-01", depth: 1, role: "Lead", harness: "AOS", model: "opus-4", state: "running", tokens: "180K", cost: "$9.10", elapsed: "01:12:02" },
    { id: "CL-1", kind: "cluster", depth: 2, label: "Source scanners", count: 34, distribution: { complete: 25, running: 6, waiting: 2, failed: 1 }, tokens: "2.1M" }
  ]}
  edges={[{ from: "OBJ", to: "L-01", state: "stable", throughput: 0.8 }]} />
```

- Always pass `activePath`: without it nothing recedes and the field reads as decoration.
- Aggregate siblings into clusters past ~8; never render every worker.
- Selection drives `ContextInspector`; the field itself shows no extra metadata.
