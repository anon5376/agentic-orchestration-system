Use on SYNTHESIS, at the top of the swarm field, or wherever many branches compress into one consequential decision.

```jsx
<ConvergenceCore size={200} agents={41} models={5} evidence={128} generation="08"
  confidence="0.72" objections={3} expanded={open} onToggle={() => setOpen(!open)}
  branches={[
    { label: "Cost-driven substitution", source: "A-14 · 22 evid", confidence: "0.81", weight: 0.9 },
    { label: "Latency-driven substitution", source: "A-19 · 14 evid", confidence: "0.44", weight: 0.5 },
    { label: "Contradicted by supplier filings", source: "A-31 · 6 evid", state: "conflict", weight: 0.7 }
  ]} />
```

- The ring is always open and one path always exits: convergence produces a next generation, not an end state.
- Expanding must reveal the inputs, confidences and unresolved objections. Never a closed summary.
