/** The central working surface: the relevant part of the agent hierarchy and
 * its movement through time. Depth 0 sits at the bottom (the constrained
 * objective); higher depth rises toward the frontier.
 * @startingPoint section="AOS" subtitle="Hierarchical swarm field with active causal path" viewport="1440x620"
 */
export interface FieldItem {
  id: string;
  /** "agent" (default) or "cluster". */
  kind?: "agent" | "cluster";
  /** Causal depth: 0 = objective, max = frontier. */
  depth?: number;
  /** 0..1 horizontal position; omit for even distribution across the depth row. */
  lane?: number;
  /** Percentage overrides if the author needs exact geometry. */
  x?: number;
  y?: number;
  role?: string;
  label?: string;
  count?: number;
  distribution?: Record<string, number>;
  harness?: string;
  model?: string;
  state?: string;
  tokens?: string;
  cost?: string;
  elapsed?: string;
  evidence?: number;
  deps?: number;
  owner?: string;
  compact?: boolean;
}
export interface FieldEdge {
  from: string;
  to: string;
  state?: "stable" | "waiting" | "verified" | "conflict" | "handoff" | "dormant";
  kind?: "delegation" | "dependency";
  throughput?: number;
  label?: string;
}
export interface AccelerationFieldProps {
  items?: FieldItem[];
  edges?: FieldEdge[];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  /** Vertical stage ladder, top to bottom. Defaults to the AOS thesis. */
  stages?: string[];
  /** Ids on the active causal path: everything else recedes. */
  activePath?: string[];
  height?: number | string;
  grid?: boolean;
  caption?: string;
  style?: React.CSSProperties;
}
export declare function AccelerationField(props: AccelerationFieldProps): JSX.Element;
