import React from "react";
import { AgentNode } from "./AgentNode.jsx";
import { AgentTrace } from "./AgentTrace.jsx";
import { ClusterAggregate } from "./ClusterAggregate.jsx";

const DEFAULT_STAGES = ["FRONTIER", "CONVERGENCE", "MUTATION", "SWARM", "CONSTRAINT"];
const LADDER = 64;

/* The central working surface. Geometry is causal, not physical: depth 0 is the
   constrained objective at the bottom, higher depth rises toward the frontier.
   Supply `depth` (+ optional `lane` 0..1) per item and the field places it;
   explicit `x`/`y` percentages override. Dormant branches come in as clusters. */
export function AccelerationField({
  items = [],
  edges = [],
  selectedId,
  onSelect,
  stages = DEFAULT_STAGES,
  activePath = [],
  height = 560,
  grid = true,
  caption,
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  const [box, setBox] = React.useState({ w: 1200, h: typeof height === "number" ? height : 560 });
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setBox({ w: el.clientWidth, h: el.clientHeight });
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const maxDepth = Math.max(1, ...items.map((i) => i.depth || 0));
  const byDepth = {};
  items.forEach((i) => {
    const d = i.depth || 0;
    (byDepth[d] = byDepth[d] || []).push(i);
  });
  const pos = {};
  items.forEach((i) => {
    const d = i.depth || 0;
    const row = byDepth[d];
    const lane = i.lane != null ? i.lane : (row.indexOf(i) + 1) / (row.length + 1);
    const px = i.x != null ? (i.x / 100) * box.w : LADDER + 120 + lane * Math.max(120, box.w - LADDER - 240);
    const py = i.y != null ? (i.y / 100) * box.h : box.h - 52 - (d / maxDepth) * Math.max(80, box.h - 104);
    pos[i.id] = { x: Math.round(px), y: Math.round(py) };
  });

  const fieldSx = {
    position: "relative",
    height: typeof height === "number" ? `${height}px` : height,
    background: "var(--void)",
    backgroundImage: grid
      ? "linear-gradient(to right,rgba(35,35,44,0.55) 0 1px,transparent 1px 100%),linear-gradient(to bottom,rgba(35,35,44,0.55) 0 1px,transparent 1px 100%)"
      : "none",
    backgroundSize: "48px 48px",
    overflow: "hidden",
    ...style
  };

  return (
    <div ref={ref} style={fieldSx} {...rest}>
      {/* stage ladder: per aspera ad astra, as structure */}
      <div style={{ position: "absolute", inset: `0 auto 0 0`, width: `${LADDER}px`, borderRight: `1px solid var(--border-on-dark)`, display: "flex", flexDirection: "column", zIndex: 3, background: "linear-gradient(to right,var(--void) 60%,transparent)" }}>
        {stages.map((s, i) => (
          <div key={s} style={{ flex: 1, minHeight: 0, display: "flex", alignItems: "center", gap: "6px", paddingLeft: "var(--space-4)", borderTop: i === 0 ? "none" : `1px solid rgba(35,35,44,0.7)` }}>
            <span style={{ width: "5px", height: "1px", background: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)" }} />
            <span
              style={{
                font: `var(--weight-regular) 9px/1 var(--font-telemetry)`,
                letterSpacing: "0.1em",
                color: i === 0 ? "var(--ultraviolet)" : "var(--quiet-metal-dim)",
                writingMode: "vertical-rl",
                transform: "rotate(180deg)",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                maxHeight: "100%"
              }}
            >
              {s}
            </span>
          </div>
        ))}
      </div>

      <svg width={box.w} height={box.h} viewBox={`0 0 ${box.w} ${box.h}`} style={{ position: "absolute", inset: 0, zIndex: 1 }}>
        {edges.map((e, i) => {
          const f = pos[e.from];
          const t = pos[e.to];
          if (!f || !t) return null;
          const onPath = activePath.includes(e.from) && activePath.includes(e.to);
          return (
            <AgentTrace
              key={i}
              from={f}
              to={t}
              state={e.state || "stable"}
              kind={e.kind || "delegation"}
              throughput={onPath ? (e.throughput != null ? e.throughput : 0.6) : 0.1}
              label={e.label}
            />
          );
        })}
      </svg>

      {items.map((i) => {
        const p = pos[i.id];
        const wrapSx = { position: "absolute", left: `${p.x}px`, top: `${p.y}px`, transform: "translate(-50%,-50%)", zIndex: selectedId === i.id ? 4 : 2 };
        return (
          <div key={i.id} style={wrapSx}>
            {i.kind === "cluster" ? (
              <ClusterAggregate
                label={i.label}
                count={i.count}
                distribution={i.distribution}
                tokens={i.tokens}
                cost={i.cost}
                owner={i.owner}
                onExpand={onSelect ? () => onSelect(i.id) : undefined}
              />
            ) : (
              <AgentNode
                agent={i}
                selected={selectedId === i.id}
                onPath={activePath.includes(i.id)}
                dim={activePath.length > 0 && !activePath.includes(i.id)}
                compact={i.compact}
                onSelect={onSelect}
              />
            )}
          </div>
        );
      })}

      {caption ? (
        <div
          style={{
            position: "absolute",
            right: "var(--space-5)",
            bottom: "var(--space-4)",
            zIndex: 3,
            font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
            color: "var(--quiet-metal-dim)",
            letterSpacing: "var(--tracking-label-tight)"
          }}
        >
          {caption}
        </div>
      ) : null}
    </div>
  );
}
