import React from "react";

const DIST = {
  running: "var(--cobalt)",
  complete: "var(--ion)",
  waiting: "var(--quiet-metal-dim)",
  failed: "var(--vermilion)",
  blocked: "var(--ultraviolet)"
};

/* Dormant or repetitive branches, aggregated. The field never draws unlimited
   nodes: it draws the active path and bundles the rest into named clusters
   with counts, a state distribution, and a way back in. */
export function ClusterAggregate({
  label,
  count = 0,
  distribution = { running: 0, complete: 0, waiting: 0, failed: 0 },
  tokens,
  cost,
  owner,
  width,
  onExpand,
  style,
  ...rest
}) {
  const total = Object.values(distribution).reduce((a, b) => a + b, 0) || 1;
  const clusterSx = {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    width: width || "196px",
    padding: "8px 10px",
    background: "var(--void)",
    border: `1px solid var(--border-on-dark)`,
    borderLeft: "3px solid var(--quiet-metal-dim)",
    cursor: onExpand ? "pointer" : "default",
    textAlign: "left",
    ...style
  };
  return (
    <div role={onExpand ? "button" : undefined} onClick={onExpand} style={clusterSx} {...rest}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "var(--space-3)" }}>
        <span
          style={{
            font: `var(--weight-medium) 12px/1.1 var(--font-interface)`,
            letterSpacing: "var(--tracking-label-tight)",
            textTransform: "uppercase",
            color: "var(--text-on-dark-secondary)"
          }}
        >
          {label}
        </span>
        <span style={{ font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)`, color: "var(--cold-white)" }}>×{count}</span>
      </div>
      <div style={{ display: "flex", height: "3px", gap: "1px", background: "var(--graphite-edge)" }}>
        {Object.keys(distribution).map((k) =>
          distribution[k] ? <span key={k} style={{ width: `${(distribution[k] / total) * 100}%`, background: DIST[k] }} /> : null
        )}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "var(--space-3)", font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>
        <span>{owner ? `← ${owner}` : "AGGREGATED"}</span>
        <span style={{ fontVariantNumeric: "tabular-nums" }}>
          {tokens}
          {cost ? ` · ${cost}` : ""}
        </span>
      </div>
      {onExpand ? (
        <div style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--state-running-on-dark)", letterSpacing: "var(--tracking-label-tight)" }}>EXPAND IN PLACE →</div>
      ) : null}
    </div>
  );
}
