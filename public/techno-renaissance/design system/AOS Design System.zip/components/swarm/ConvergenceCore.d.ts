/** The singularity component as a functional convergence state: how many
 * branches, agents, models, evidence items and generations are compressing
 * into one decision — and the way back into them.
 * @startingPoint section="AOS" subtitle="Convergence core and generation exit" viewport="700x420"
 */
export interface CoreBranch {
  label: string;
  source?: string;
  confidence?: string;
  weight?: number;
  state?: "stable" | "verified" | "conflict" | "handoff";
  dormant?: boolean;
}
export interface ConvergenceCoreProps {
  size?: number;
  branches?: CoreBranch[];
  agents?: number;
  models?: number;
  evidence?: number;
  /** Generation the exiting path leads to, e.g. "08". */
  generation?: string;
  confidence?: string;
  objections?: number;
  expanded?: boolean;
  onToggle?: () => void;
  legend?: boolean;
  style?: React.CSSProperties;
}
export declare function ConvergenceCore(props: ConvergenceCoreProps): JSX.Element;
