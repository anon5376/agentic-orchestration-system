/** Dormant or repetitive branches, aggregated into one named bundle with a
 * count, a state distribution and a way back in. */
export interface ClusterAggregateProps {
  label: string;
  count?: number;
  distribution?: { running?: number; complete?: number; waiting?: number; failed?: number; blocked?: number };
  tokens?: string;
  cost?: string;
  /** Delegating agent id, rendered as "← L-01". */
  owner?: string;
  width?: string;
  onExpand?: () => void;
  style?: React.CSSProperties;
}
export declare function ClusterAggregate(props: ClusterAggregateProps): JSX.Element;
