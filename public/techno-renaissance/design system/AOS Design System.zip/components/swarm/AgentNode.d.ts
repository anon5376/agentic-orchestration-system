/** One owned task in the hierarchy, carrying only causal-path facts. */
export interface AgentDatum {
  id: string;
  role: string;
  owner?: string;
  harness?: string;
  model?: string;
  state?: "running" | "waiting" | "blocked" | "failed" | "complete" | "dormant" | "handoff" | "gate";
  tokens?: string;
  cost?: string;
  elapsed?: string;
  evidence?: number;
  deps?: number;
}
export interface AgentNodeProps {
  agent: AgentDatum;
  selected?: boolean;
  /** On the active causal path: keeps full contrast and a state-coloured edge. */
  onPath?: boolean;
  /** Off-path: recedes to --opacity-recede. */
  dim?: boolean;
  compact?: boolean;
  width?: string;
  onSelect?: (id: string) => void;
  style?: React.CSSProperties;
}
export declare function AgentNode(props: AgentNodeProps): JSX.Element;
