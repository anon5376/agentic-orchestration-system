import React from "react";
import { Telemetry } from "../core/Telemetry.jsx";

/* The singularity component, as a functional convergence state. It says how
   many branches, agents, models, evidence items and generations are
   compressing into one decision — and it opens back into those inputs.
   It never hides provenance. */
export function ConvergenceCore({
  size = 200,
  branches = [],
  agents = 0,
  models = 0,
  evidence = 0,
  generation,
  confidence,
  objections = 0,
  expanded = false,
  onToggle,
  legend = true,
  style,
  ...rest
}) {
  const n = branches.length || 6;
  const r = size / 2;
  const ring = r * 0.44;
  const ticks = Array.from({ length: n }, (_, i) => {
    const b = branches[i] || { weight: 0.5, state: "stable" };
    const ang = -150 + (i * 300) / Math.max(1, n - 1); // asymmetric: paths enter from the left arc
    const rad = (ang * Math.PI) / 180;
    const outer = r * 0.98;
    const inner = ring + 6;
    return {
      x1: r + Math.cos(rad) * outer,
      y1: r + Math.sin(rad) * outer,
      x2: r + Math.cos(rad) * inner,
      y2: r + Math.sin(rad) * inner,
      w: 0.8 + (b.weight || 0.5) * 2.6,
      stroke:
        b.state === "conflict" ? "var(--vermilion)" : b.state === "verified" ? "var(--ion)" : b.state === "handoff" ? "var(--ultraviolet)" : "var(--trace-stable-on-dark)",
      opacity: b.dormant ? 0.3 : 1
    };
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-5)", ...style }} {...rest}>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--space-11)" }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          onClick={onToggle}
          style={{ display: "block", flex: "none", cursor: onToggle ? "pointer" : "default", overflow: "visible" }}
        >
          {ticks.map((t, i) => (
            <line key={i} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} stroke={t.stroke} strokeWidth={t.w} strokeOpacity={t.opacity} />
          ))}
          {/* open aperture: never a closed ring */}
          <circle
            cx={r}
            cy={r}
            r={ring}
            fill="none"
            stroke="var(--cold-white)"
            strokeWidth="1"
            strokeDasharray={`${2 * Math.PI * ring * 0.74} ${2 * Math.PI * ring * 0.26}`}
            transform={`rotate(-132 ${r} ${r})`}
          />
          <circle cx={r} cy={r} r="2.5" fill="var(--cold-white)" />
          {/* next generation exits the far side */}
          <line x1={r + ring + 4} y1={r} x2={size + 8} y2={r} stroke="var(--ultraviolet)" strokeWidth="1.5" />
          <text x={size + 12} y={r + 3} fill="var(--ultraviolet)" style={{ font: "500 10px var(--font-telemetry)", letterSpacing: "0.08em" }}>
            {generation ? `GEN ${generation}` : "NEXT GEN"}
          </text>
          <text x={r} y={r - ring - 10} textAnchor="middle" fill="var(--quiet-metal)" style={{ font: "400 10px var(--font-telemetry)", letterSpacing: "0.12em" }}>
            CONVERGENCE
          </text>
        </svg>
        {legend ? (
          <Telemetry
            on="dark"
            layout="grid"
            style={{ flex: 1, minWidth: 0 }}
            items={[
              { label: "Branches", value: n },
              { label: "Agents", value: agents },
              { label: "Models", value: models },
              { label: "Evidence", value: evidence, tone: "verified" },
              { label: "Confidence", value: confidence, tone: "active" },
              { label: "Objections", value: objections, tone: objections ? "consequence" : "dim" }
            ]}
          />
        ) : null}
      </div>
      {expanded && branches.length ? (
        <div style={{ borderTop: `1px solid var(--border-on-dark-strong)` }}>
          {branches.map((b) => (
            <div
              key={b.label}
              style={{
                display: "flex",
                alignItems: "baseline",
                justifyContent: "space-between",
                gap: "var(--space-5)",
                padding: "8px 0",
                borderBottom: `1px solid var(--border-on-dark)`
              }}
            >
              <span style={{ font: `var(--weight-medium) var(--type-body-sm)/1.3 var(--font-interface)`, color: "var(--cold-white)" }}>{b.label}</span>
              <span style={{ display: "flex", gap: "var(--space-5)", font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>
                <span>{b.source}</span>
                <span style={{ color: b.state === "conflict" ? "var(--vermilion)" : "var(--text-on-dark-secondary)" }}>
                  {b.state === "conflict" ? "OBJECTION" : `CONF ${b.confidence}`}
                </span>
              </span>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
