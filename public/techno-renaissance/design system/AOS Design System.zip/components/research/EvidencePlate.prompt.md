The unit of the `#/evidence` surface and of any synthesis input.

```jsx
<EvidencePlate on="dark" id="EV-118" confidence="0.81" freshness="4h"
  claim="Two of three named suppliers disclose 2029 capacity below the modelled EU requirement."
  source="Supplier 10-K filings (3)" provenance="PRIMARY · RETRIEVED" producedBy="A-14"
  consumers={["A-19", "SYN-3"]} onOpen={open} />
```

- `contradiction` flips the header to `CONTRADICTED` in vermilion. Dissent stays visible; never drop a contradicted plate.
- `slot` renders an honest "source image · not supplied" region — do not substitute stock imagery.
