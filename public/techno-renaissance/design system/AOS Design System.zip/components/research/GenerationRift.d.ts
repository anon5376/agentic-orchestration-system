/** The mutation seam between baseline and candidate generations: changed
 * rules, metric deltas, regressions, rollback point, adoption state.
 * @startingPoint section="AOS" subtitle="Baseline / candidate generation seam" viewport="700x420"
 */
export interface RiftMetric { label: string; value: string; delta?: string; regression?: boolean }
export interface RiftChange { kind?: string; text: string }
export interface GenerationRiftProps {
  baseline?: { label: string; metrics?: RiftMetric[] };
  candidate?: { label: string; metrics?: RiftMetric[] };
  changes?: (RiftChange | string)[];
  regressions?: string[];
  /** Commit-like rollback handle, e.g. "gen-07 · 4a91c2". */
  rollback?: string;
  adoption?: string;
  style?: React.CSSProperties;
}
export declare function GenerationRift(props: GenerationRiftProps): JSX.Element;
