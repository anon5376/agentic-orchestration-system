import React from "react";

/* The mutation seam between a baseline generation and a candidate. The seam is
   visible on purpose: improvement must never look magical. Carries changed
   rules, topology changes, metric deltas, regressions, rollback point and
   adoption state. */
export function GenerationRift({
  baseline = { label: "GEN 07", metrics: [] },
  candidate = { label: "GEN 08 · CANDIDATE", metrics: [] },
  changes = [],
  regressions = [],
  rollback,
  adoption = "AWAITING APPROVAL",
  style,
  ...rest
}) {
  const sideSx = { flex: 1, minWidth: 0, padding: "var(--space-6)", display: "flex", flexDirection: "column", gap: "var(--space-5)" };
  const labelSx = {
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color: "var(--quiet-metal)"
  };
  const metricRow = (m, side) => (
    <div key={m.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: "var(--space-5)", padding: "6px 0", borderBottom: `1px solid var(--border-on-dark)` }}>
      <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--quiet-metal)", textTransform: "uppercase", letterSpacing: "var(--tracking-label-tight)" }}>{m.label}</span>
      <span style={{ display: "flex", gap: "var(--space-4)", alignItems: "baseline" }}>
        <span style={{ font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)`, color: side === "candidate" ? "var(--cold-white)" : "var(--text-on-dark-secondary)", fontVariantNumeric: "tabular-nums" }}>
          {m.value}
        </span>
        {side === "candidate" && m.delta ? (
          <span style={{ font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: m.regression ? "var(--vermilion)" : "var(--ion)" }}>{m.delta}</span>
        ) : null}
      </span>
    </div>
  );

  return (
    <section style={{ display: "flex", background: "var(--void)", border: `1px solid var(--border-on-dark)`, ...style }} {...rest}>
      <div style={{ ...sideSx, opacity: 0.78 }}>
        <div style={labelSx}>BASELINE · {baseline.label}</div>
        <div>{(baseline.metrics || []).map((m) => metricRow(m, "baseline"))}</div>
        {rollback ? (
          <div style={{ font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>
            ROLLBACK POINT
            <br />
            <span style={{ color: "var(--text-on-dark-secondary)" }}>{rollback}</span>
          </div>
        ) : null}
      </div>

      {/* the seam */}
      <div style={{ flex: "none", width: "1px", background: "var(--ultraviolet)", position: "relative" }}>
        <div style={{ position: "absolute", top: 0, bottom: 0, left: "1px", width: "6px", background: "var(--hatch-45)", color: "var(--ultraviolet)", opacity: 0.5 }} />
      </div>

      <div style={sideSx}>
        <div style={{ ...labelSx, color: "var(--ultraviolet)" }}>{candidate.label}</div>
        <div>{(candidate.metrics || []).map((m) => metricRow(m, "candidate"))}</div>
        {changes.length ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <div style={labelSx}>CHANGED</div>
            {changes.map((c, i) => (
              <div key={i} style={{ display: "flex", gap: "8px", font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`, color: "var(--text-on-dark-secondary)" }}>
                <span style={{ color: "var(--ultraviolet)", flex: "none" }}>{c.kind || "RULE"}</span>
                <span>{c.text || c}</span>
              </div>
            ))}
          </div>
        ) : null}
        {regressions.length ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "4px", paddingTop: "var(--space-4)", borderTop: `1px solid var(--vermilion)` }}>
            <div style={{ ...labelSx, color: "var(--vermilion)" }}>NEW REGRESSIONS · {regressions.length}</div>
            {regressions.map((r, i) => (
              <div key={i} style={{ font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`, color: "var(--cold-white)" }}>{r}</div>
            ))}
          </div>
        ) : null}
        <div style={{ font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`, letterSpacing: "var(--tracking-label-tight)", color: "var(--cold-white)", border: `1px solid var(--border-on-dark-strong)`, padding: "6px 8px", alignSelf: "flex-start" }}>
          ADOPTION · {adoption}
        </div>
      </div>
    </section>
  );
}
