/** Goal intake: one dominant objective with constraints, context documents,
 * definition of done and open ambiguity orbiting it.
 * @startingPoint section="AOS" subtitle="Objective intake on a committed cobalt field" viewport="1440x700"
 */
export interface ObjectiveDocument { name: string; size?: string }
export interface ObjectiveAmbiguity { q: string; status?: string }
export interface ObjectiveApertureProps {
  mission?: string;
  goal?: string;
  placeholder?: string;
  constraints?: (string | { name: string; size?: string })[];
  documents?: ObjectiveDocument[];
  definitionOfDone?: string[];
  ambiguities?: ObjectiveAmbiguity[];
  /** field = committed cobalt (default, intake); dark = operational; light = mineral. */
  on?: "field" | "dark" | "light";
  actions?: React.ReactNode;
  /** Pass to make the objective editable; omit to render it as set copy. */
  onGoalChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  style?: React.CSSProperties;
}
export declare function ObjectiveAperture(props: ObjectiveApertureProps): JSX.Element;
