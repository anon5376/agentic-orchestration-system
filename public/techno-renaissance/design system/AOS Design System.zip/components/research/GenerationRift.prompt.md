The `#/evolution` comparison. Baseline recedes at 78% opacity; the candidate is full contrast; an ultraviolet 1px seam with hatch marks separates them.

```jsx
<GenerationRift
  baseline={{ label: "GEN 07", metrics: [{ label: "Verified claims", value: "71%" }, { label: "Wasted tokens", value: "18%" }] }}
  candidate={{ label: "GEN 08 · CANDIDATE", metrics: [
    { label: "Verified claims", value: "78%", delta: "+7.4" },
    { label: "Wasted tokens", value: "6%", delta: "−12" },
    { label: "Long-context routing", value: "0.62", delta: "−0.05", regression: true }
  ] }}
  changes={[{ kind: "RULE", text: "Lead must request a missing input before delegating" }]}
  regressions={["Long-context routing on >200K corpora"]}
  rollback="gen-07 · 4a91c2" adoption="AWAITING APPROVAL" />
```

- Improvement must never look magical: show the seam, the regressions and the rollback point every time.
- Pair with a `DecisionGate` when adoption is actually available.
