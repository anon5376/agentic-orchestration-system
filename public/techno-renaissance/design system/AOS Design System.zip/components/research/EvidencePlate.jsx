import React from "react";

/* A bounded source or finding: claim, provenance, freshness, confidence,
   contradiction state, downstream consumers. Source text and citation
   controls stay crisp; only imagery may be dithered. */
export function EvidencePlate({
  id,
  claim,
  source,
  provenance,
  freshness,
  confidence,
  contradiction,
  consumers = [],
  producedBy,
  slot = false,
  on = "dark",
  selected = false,
  onOpen,
  style,
  ...rest
}) {
  const dark = on !== "light";
  const fg = dark ? "var(--cold-white)" : "var(--void)";
  const dim = dark ? "var(--quiet-metal)" : "var(--text-secondary)";
  const edge = dark ? "var(--border-on-dark)" : "var(--border-rule)";
  const plateSx = {
    display: "flex",
    flexDirection: "column",
    background: dark ? "var(--void-raise)" : "var(--surface-plate)",
    border: `1px solid ${selected ? "var(--cobalt)" : edge}`,
    color: fg,
    cursor: onOpen ? "pointer" : "default",
    ...style
  };
  const rowSx = { display: "flex", justifyContent: "space-between", gap: "var(--space-4)", font: `var(--type-telemetry-sm)/1.4 var(--font-telemetry)`, color: dim };

  return (
    <article onClick={onOpen} style={plateSx} {...rest}>
      {slot ? (
        <div
          style={{
            height: "96px",
            borderBottom: `1px solid ${edge}`,
            color: dark ? "var(--quiet-metal-dim)" : "var(--rule)",
            background: "var(--dither-coarse)",
            display: "flex",
            alignItems: "flex-end",
            padding: "8px"
          }}
        >
          <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, letterSpacing: "var(--tracking-label-tight)", color: dim }}>
            SOURCE IMAGE · NOT SUPPLIED
          </span>
        </div>
      ) : null}
      <div style={{ padding: "var(--space-5)", display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
        <div style={rowSx}>
          <span style={{ letterSpacing: "var(--tracking-label-tight)" }}>{id}</span>
          <span style={{ color: contradiction ? "var(--vermilion)" : dark ? "var(--ion)" : "#4C7A00", letterSpacing: "var(--tracking-label-tight)" }}>
            {contradiction ? "CONTRADICTED" : "CORROBORATED"}
          </span>
        </div>
        <p style={{ margin: 0, font: `var(--weight-regular) var(--type-body)/1.45 var(--font-interface)`, textWrap: "pretty" }}>{claim}</p>
        <div style={{ display: "flex", flexDirection: "column", gap: "3px", paddingTop: "var(--space-4)", borderTop: `1px solid ${edge}` }}>
          <div style={rowSx}>
            <span>SOURCE</span>
            <span style={{ color: fg, textAlign: "right" }}>{source}</span>
          </div>
          <div style={rowSx}>
            <span>PROVENANCE</span>
            <span style={{ color: fg }}>{provenance}</span>
          </div>
          <div style={rowSx}>
            <span>FRESHNESS</span>
            <span style={{ color: fg }}>{freshness}</span>
          </div>
          <div style={rowSx}>
            <span>CONFIDENCE</span>
            <span style={{ color: dark ? "var(--state-running-on-dark)" : "var(--cobalt)" }}>{confidence}</span>
          </div>
          {producedBy ? (
            <div style={rowSx}>
              <span>PRODUCED BY</span>
              <span style={{ color: fg }}>{producedBy}</span>
            </div>
          ) : null}
        </div>
        {consumers.length ? (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "4px", paddingTop: "var(--space-3)" }}>
            <span style={{ font: `var(--type-telemetry-sm)/1.6 var(--font-telemetry)`, color: dim, marginRight: "4px" }}>USED BY</span>
            {consumers.map((c) => (
              <span
                key={c}
                style={{
                  font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`,
                  padding: "3px 5px",
                  border: `1px solid ${edge}`,
                  color: fg,
                  letterSpacing: "var(--tracking-label-tight)"
                }}
              >
                {c}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </article>
  );
}
