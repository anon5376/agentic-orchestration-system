The `#/intake` surface, and the header of a mission. The objective is display-scale; everything else is 13px.

```jsx
<ObjectiveAperture mission="MSN-2291" on="field"
  goal="Determine whether solid-state cell supply can meet 2029 EU demand."
  constraints={["Budget 2.5M tokens", "No paid data sources", "Cite primary filings only"]}
  documents={[{ name: "eu-battery-directive.pdf", size: "2.1 MB" }]}
  definitionOfDone={["One ranked conclusion", "Objections attached"]}
  ambiguities={[{ q: "Does 'supply' include imports?", status: "ASKED" }]}
  actions={<Button on="field" variant="primary">Decompose</Button>} />
```

- Keep the goal under about 24 characters per line at display scale; it is the only monumental element on the screen.
- Open ambiguity is never hidden: an empty ambiguity column still shows its `0`.
