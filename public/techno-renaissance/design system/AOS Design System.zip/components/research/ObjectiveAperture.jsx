import React from "react";
import { Aperture } from "../core/Aperture.jsx";

/* Goal intake. One high-contrast aperture for the objective; constraints,
   documents, definition of done and open ambiguities orbit it by importance.
   The prompt dominates — setup controls stay secondary. */
export function ObjectiveAperture({
  mission,
  goal,
  placeholder = "State the objective, its boundaries, and what would count as done.",
  constraints = [],
  documents = [],
  definitionOfDone = [],
  ambiguities = [],
  on = "field",
  actions,
  onGoalChange,
  style,
  ...rest
}) {
  const field = on === "field";
  const fg = field ? "var(--cold-white)" : on === "dark" ? "var(--cold-white)" : "var(--void)";
  const dim = field ? "var(--text-on-field-secondary)" : "var(--quiet-metal)";
  const edge = field ? "var(--border-on-field)" : on === "dark" ? "var(--border-on-dark)" : "var(--border-rule)";
  const wrapSx = {
    background: field ? "var(--cobalt)" : on === "dark" ? "var(--void)" : "var(--mineral-white)",
    color: fg,
    padding: "var(--space-10) var(--space-8) 0",
    ...style
  };
  const columns = [
    { label: "CONSTRAINTS", items: constraints },
    { label: "CONTEXT", items: documents },
    { label: "DEFINITION OF DONE", items: definitionOfDone },
    { label: "OPEN AMBIGUITY", items: ambiguities, warn: true }
  ];

  return (
    <section style={wrapSx} {...rest}>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--space-4)", marginBottom: "var(--space-7)" }}>
        <Aperture size={14} tone="inherit" state="converging" />
        <span style={{ font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: dim }}>
          OBJECTIVE APERTURE
        </span>
        {mission ? <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: dim }}>{mission}</span> : null}
      </div>

      <div style={{ borderTop: `1px solid ${edge}`, borderBottom: `1px solid ${edge}`, padding: "var(--space-8) 0" }}>
        {onGoalChange ? (
          <textarea
            value={goal}
            onChange={onGoalChange}
            placeholder={placeholder}
            rows={3}
            style={{
              width: "100%",
              background: "transparent",
              border: "none",
              outline: "none",
              resize: "none",
              color: fg,
              font: `var(--weight-regular) var(--type-display-3)/var(--leading-display) var(--font-display)`,
              letterSpacing: "var(--tracking-display)"
            }}
          />
        ) : (
          <p
            style={{
              margin: 0,
              maxWidth: "24ch",
              font: `var(--weight-regular) var(--type-display-2)/var(--leading-display) var(--font-display)`,
              letterSpacing: "var(--tracking-display)",
              textWrap: "pretty"
            }}
          >
            {goal || placeholder}
          </p>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", borderBottom: `1px solid ${edge}` }}>
        {columns.map((c, ci) => (
          <div key={c.label} style={{ padding: "var(--space-6) var(--space-6) var(--space-7) 0", borderLeft: ci === 0 ? "none" : `1px solid ${edge}`, paddingLeft: ci === 0 ? 0 : "var(--space-6)" }}>
            <div
              style={{
                font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
                letterSpacing: "var(--tracking-label)",
                textTransform: "uppercase",
                color: c.warn && c.items.length ? (field ? "var(--cold-white)" : "var(--vermilion)") : dim,
                marginBottom: "var(--space-4)",
                display: "flex",
                gap: "6px"
              }}
            >
              {c.label}
              <span style={{ font: `var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: dim }}>{c.items.length}</span>
            </div>
            <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: "6px" }}>
              {c.items.map((it, i) => {
                const text = typeof it === "string" ? it : it.name || it.q;
                const meta = typeof it === "string" ? null : it.size || it.status;
                return (
                  <li key={i} style={{ display: "flex", gap: "8px", justifyContent: "space-between", font: `var(--weight-regular) var(--type-body-sm)/1.4 var(--font-interface)`, color: fg }}>
                    <span style={{ textWrap: "pretty" }}>{text}</span>
                    {meta ? <span style={{ font: `var(--type-telemetry-sm)/1.5 var(--font-telemetry)`, color: dim, flex: "none" }}>{meta}</span> : null}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      {actions ? <div style={{ display: "flex", gap: "var(--space-4)", padding: "var(--space-7) 0" }}>{actions}</div> : null}
    </section>
  );
}
