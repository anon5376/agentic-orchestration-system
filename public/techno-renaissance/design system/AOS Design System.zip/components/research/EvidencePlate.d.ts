/** A bounded source or finding with claim, provenance, freshness, confidence,
 * contradiction state and downstream consumers. */
export interface EvidencePlateProps {
  id?: string;
  claim?: string;
  source?: string;
  provenance?: string;
  freshness?: string;
  confidence?: string;
  contradiction?: boolean;
  /** Agent/task ids that depend on this evidence. */
  consumers?: string[];
  producedBy?: string;
  /** Reserve a labelled image region. Only imagery may be dithered; text stays crisp. */
  slot?: boolean;
  on?: "light" | "dark";
  selected?: boolean;
  onOpen?: () => void;
  style?: React.CSSProperties;
}
export declare function EvidencePlate(props: EvidencePlateProps): JSX.Element;
