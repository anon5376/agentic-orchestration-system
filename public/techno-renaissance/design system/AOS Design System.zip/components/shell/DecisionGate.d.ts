/** Bottom strip shown only when a decision changes the run or a future
 * generation. Each choice states consequence, reversibility and authority. */
export interface GateChoice {
  label: string;
  consequence: string;
  reversible?: boolean;
  variant?: "primary" | "secondary" | "ghost" | "consequence";
}
export interface DecisionGateProps {
  open?: boolean;
  prompt?: string;
  detail?: string;
  /** Who may act: OPERATOR, REVIEWER, OWNER, POLICY. */
  authority?: string;
  choices?: GateChoice[];
  onChoose?: (choice: GateChoice) => void;
  style?: React.CSSProperties;
}
export declare function DecisionGate(props: DecisionGateProps): JSX.Element | null;
