/** Conditional detail region for the current selection. Renders null when
 * closed — it is the reason the work field can stay uncrowded. */
export interface InspectorRow { k: string; v: React.ReactNode; tone?: "neutral" | "active" | "verified" | "consequence" | "transition" | "dim" }
export interface InspectorSection { label: string; rows?: InspectorRow[]; body?: string; children?: React.ReactNode }
export interface ContextInspectorProps {
  open?: boolean;
  /** What kind of thing is selected: AGENT, CLUSTER, EVIDENCE, GENERATION, CAPABILITY, MEMORY. */
  kind?: string;
  title?: string;
  subtitle?: string;
  sections?: InspectorSection[];
  actions?: React.ReactNode;
  children?: React.ReactNode;
  onClose?: () => void;
  style?: React.CSSProperties;
}
export declare function ContextInspector(props: ContextInspectorProps): JSX.Element | null;
