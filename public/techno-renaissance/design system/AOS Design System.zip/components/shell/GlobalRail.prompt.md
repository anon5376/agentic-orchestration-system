Top chrome for every AOS surface. 44px, edge to edge, one hairline, cobalt marks the active route.

```jsx
<GlobalRail route="SWARM" mission="MSN-2291" mode="ILLUSTRATIVE"
  connection={{ state: "ok", label: "4 PROVIDERS" }} onRoute={setRoute} onCommand={openPalette} />
```

- Routes are uppercase and terse: MISSIONS, INTAKE, SWARM, EVIDENCE, SYNTHESIS, EVOLUTION, CAPABILITIES, MEMORY.
- `mode` must state the truth: `ILLUSTRATIVE` for prototypes, `LIVE` when actions execute.
- The rail is an instrument, not a header: no logo lockup beyond `AOS`, no tagline, no marketing CTA.
