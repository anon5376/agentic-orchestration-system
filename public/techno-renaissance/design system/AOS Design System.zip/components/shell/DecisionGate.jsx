import React from "react";
import { Button } from "../core/Button.jsx";

/* Bottom strip, shown only when a decision changes this run or a future
   generation. Every choice states action, consequence, reversibility and
   required authority. Self-modifying or destructive choices are vermilion. */
export function DecisionGate({ open = true, prompt, detail, authority = "OPERATOR", choices = [], onChoose, style, ...rest }) {
  if (!open) return null;
  const stripSx = {
    display: "flex",
    alignItems: "stretch",
    gap: 0,
    background: "var(--void-plate)",
    borderTop: `1px solid var(--vermilion)`,
    ...style
  };
  return (
    <section style={stripSx} {...rest}>
      <div style={{ flex: 1, minWidth: 0, padding: "var(--space-5)", display: "flex", flexDirection: "column", gap: "6px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "var(--space-4)" }}>
          <span
            style={{
              font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
              letterSpacing: "var(--tracking-label)",
              textTransform: "uppercase",
              color: "var(--vermilion)"
            }}
          >
            // DECISION GATE
          </span>
          <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>
            AUTHORITY REQUIRED · {authority}
          </span>
        </div>
        <div style={{ font: `var(--weight-medium) var(--type-title-3)/1.25 var(--font-display)`, color: "var(--cold-white)", letterSpacing: "var(--tracking-title)" }}>{prompt}</div>
        {detail ? (
          <div style={{ font: `var(--weight-regular) var(--type-body-sm)/var(--leading-body) var(--font-interface)`, color: "var(--text-on-dark-secondary)", maxWidth: "var(--measure-body)" }}>
            {detail}
          </div>
        ) : null}
      </div>
      <div style={{ display: "flex", flex: "none" }}>
        {choices.map((c) => (
          <div
            key={c.label}
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              gap: "var(--space-4)",
              width: "216px",
              padding: "var(--space-5)",
              borderLeft: `1px solid var(--border-on-dark-strong)`
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1.4 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>{c.consequence}</span>
              <span
                style={{
                  font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
                  letterSpacing: "var(--tracking-label-tight)",
                  color: c.reversible ? "var(--ion)" : "var(--vermilion)"
                }}
              >
                {c.reversible ? "REVERSIBLE" : "IRREVERSIBLE"}
              </span>
            </div>
            <Button on="dark" variant={c.variant || "secondary"} size="sm" full onClick={() => onChoose && onChoose(c)}>
              {c.label}
            </Button>
          </div>
        ))}
      </div>
    </section>
  );
}
