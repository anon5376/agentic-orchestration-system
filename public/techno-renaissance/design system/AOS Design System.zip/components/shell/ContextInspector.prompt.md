380px right panel that exists only while something is selected.

```jsx
<ContextInspector open={!!sel} kind="AGENT" title="Corpus triage" subtitle="A-14 · owner L-01"
  sections={[{ label: "Runtime", rows: [
    { k: "Harness", v: "Claude Code" },
    { k: "Model", v: "claude-sonnet-4" },
    { k: "Tokens", v: "412K" },
    { k: "Cost", v: "$4.90", tone: "active" }
  ]}]}
  actions={<Button on="dark" variant="secondary" size="sm" full>Open trace</Button>}
  onClose={() => setSel(null)} />
```

- Move every secondary metric here instead of onto nodes.
- On narrow screens present the same content as a bottom sheet.
