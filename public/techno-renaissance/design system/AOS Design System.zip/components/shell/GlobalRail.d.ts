/** The instrument rail: AOS lockup, routes, mission id, demo/live honesty,
 * connection health, command aperture. There is no left sidebar in AOS. */
export interface GlobalRailProps {
  route?: string;
  routes?: string[];
  /** Mission identifier shown as telemetry, e.g. "MSN-2291". */
  mission?: string;
  /** Label demo state honestly. */
  mode?: "ILLUSTRATIVE" | "LIVE" | (string & {});
  connection?: { state: "ok" | "degraded" | "down"; label: string };
  onRoute?: (route: string) => void;
  onCommand?: () => void;
  on?: "dark" | "light" | "field";
  style?: React.CSSProperties;
}
export declare function GlobalRail(props: GlobalRailProps): JSX.Element;
