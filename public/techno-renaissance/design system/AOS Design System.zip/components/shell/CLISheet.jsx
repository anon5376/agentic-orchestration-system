import React from "react";

const KIND = {
  command: { color: "var(--cold-white)", prefix: "aos ›" },
  output: { color: "var(--text-on-dark-secondary)", prefix: "" },
  meta: { color: "var(--quiet-metal)", prefix: "" },
  ok: { color: "var(--ion)", prefix: "" },
  error: { color: "var(--vermilion)", prefix: "" },
  handoff: { color: "#8E72FF", prefix: "" }
};

/* Keyboard-first command surface. It always states the working context and
   whether an action is simulated. It is not a decorative terminal. */
export function CLISheet({
  expanded = false,
  lines = [],
  context = "mission/—",
  prompt = "",
  simulated = true,
  hint = "⌃` TOGGLE",
  onToggle,
  onPromptChange,
  onSubmit,
  style,
  ...rest
}) {
  const sheetSx = {
    display: "flex",
    flexDirection: "column",
    background: "var(--void)",
    borderTop: `1px solid ${expanded ? "var(--border-on-dark-strong)" : "var(--border-on-dark)"}`,
    height: expanded ? "var(--cli-expanded-height)" : "var(--cli-collapsed-height)",
    transition: "height var(--dur-branch) var(--ease-instrument)",
    overflow: "hidden",
    ...style
  };
  const barSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-5)",
    height: "var(--cli-collapsed-height)",
    flex: "none",
    padding: "0 var(--space-5)",
    borderBottom: expanded ? `1px solid var(--border-on-dark)` : "none",
    font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
    color: "var(--quiet-metal)",
    cursor: "pointer"
  };
  const last = lines.length ? lines[lines.length - 1] : null;

  return (
    <section style={sheetSx} {...rest}>
      <div style={barSx} onClick={onToggle}>
        <span style={{ color: "var(--text-on-dark-secondary)", letterSpacing: "var(--tracking-label-tight)" }}>// CLI</span>
        <span style={{ color: "var(--quiet-metal)" }}>{context}</span>
        <span
          style={{
            padding: "0 5px",
            border: `1px solid ${simulated ? "var(--quiet-metal)" : "var(--ion)"}`,
            color: simulated ? "var(--quiet-metal)" : "var(--ion)",
            letterSpacing: "var(--tracking-label-tight)"
          }}
        >
          {simulated ? "SIMULATED" : "EXECUTES"}
        </span>
        {!expanded && last ? (
          <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: KIND[last.kind].color }}>
            {last.kind === "command" ? "aos › " : ""}
            {last.text}
          </span>
        ) : (
          <span style={{ flex: 1 }} />
        )}
        <span style={{ color: "var(--quiet-metal-dim)" }}>{hint}</span>
      </div>
      {expanded ? (
        <>
          <div style={{ flex: 1, minHeight: 0, overflow: "auto", padding: "var(--space-4) var(--space-5)", display: "flex", flexDirection: "column", gap: "3px" }}>
            {lines.map((l, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: "8px",
                  font: `var(--weight-regular) var(--type-telemetry)/1.45 var(--font-telemetry)`,
                  color: KIND[l.kind] ? KIND[l.kind].color : KIND.output.color,
                  whiteSpace: "pre-wrap"
                }}
              >
                {l.kind === "command" ? <span style={{ color: "var(--state-running-on-dark)", flex: "none" }}>aos ›</span> : null}
                <span>{l.text}</span>
              </div>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSubmit && onSubmit(prompt);
            }}
            style={{ display: "flex", alignItems: "center", gap: "8px", flex: "none", height: "36px", padding: "0 var(--space-5)", borderTop: `1px solid var(--border-on-dark)` }}
          >
            <span style={{ color: "var(--state-running-on-dark)", font: `var(--weight-medium) var(--type-telemetry)/1 var(--font-telemetry)` }}>aos ›</span>
            <input
              value={prompt}
              onChange={(e) => onPromptChange && onPromptChange(e.target.value)}
              placeholder="swarm inspect --agent …"
              style={{
                flex: 1,
                background: "transparent",
                border: "none",
                outline: "none",
                color: "var(--cold-white)",
                font: `var(--weight-regular) var(--type-telemetry)/1 var(--font-telemetry)`
              }}
            />
          </form>
        </>
      ) : null}
    </section>
  );
}
