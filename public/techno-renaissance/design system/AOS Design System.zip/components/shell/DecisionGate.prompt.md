The only vermilion-bordered region in AOS. Appears at the foot of the surface when a gate is real.

```jsx
<DecisionGate open prompt="Promote GEN 08 to default coordination policy?"
  detail="Held-out evaluation: +7.4% claim verification, −12% wasted tokens, one new regression in long-context routing."
  authority="OWNER"
  choices={[
    { label: "Promote", consequence: "New runs use GEN 08", reversible: true, variant: "primary" },
    { label: "Reject", consequence: "Candidate archived with trace", reversible: true },
    { label: "Promote + auto-adopt", consequence: "Future safe changes self-promote", reversible: false, variant: "consequence" }
  ]} />
```

- Never show it speculatively, and never more than one per surface.
- Irreversible choices must read `IRREVERSIBLE` and use `variant="consequence"`.
