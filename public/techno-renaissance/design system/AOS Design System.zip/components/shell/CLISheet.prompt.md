Bottom rail on every operational surface: 32px collapsed (last line + context), 300px expanded.

```jsx
<CLISheet expanded={open} context="mission/MSN-2291" simulated lines={[
  { kind: "command", text: "swarm dispatch --lead L-01 --budget 2.5M" },
  { kind: "output", text: "9 specialists created · 3 lanes parallel" },
  { kind: "ok", text: "evidence/EV-118 verified" },
  { kind: "error", text: "A-22 blocked: rate limit (anthropic, 60s)" }
]} onToggle={() => setOpen(!open)} />
```

- Dashboard and CLI are two views of one state: the commands shown must correspond to what the dashboard just did.
- Never render it as decoration. If nothing is executable, omit it.
