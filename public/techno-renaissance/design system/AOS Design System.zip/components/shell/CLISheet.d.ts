/** Collapsible keyboard-first command surface. Shows the command, its output,
 * the working context, and whether execution is simulated. */
export interface CLILine { kind: "command" | "output" | "meta" | "ok" | "error" | "handoff"; text: string }
export interface CLISheetProps {
  expanded?: boolean;
  lines?: CLILine[];
  /** Working context, e.g. "mission/MSN-2291 · agent/A-14". */
  context?: string;
  prompt?: string;
  /** True whenever the action would not really execute. */
  simulated?: boolean;
  hint?: string;
  onToggle?: () => void;
  onPromptChange?: (v: string) => void;
  onSubmit?: (v: string) => void;
  style?: React.CSSProperties;
}
export declare function CLISheet(props: CLISheetProps): JSX.Element;
