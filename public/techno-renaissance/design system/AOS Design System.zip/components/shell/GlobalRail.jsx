import React from "react";
import { Aperture } from "../core/Aperture.jsx";

const SURFACE = {
  dark: { bg: "var(--void)", fg: "var(--cold-white)", dim: "var(--quiet-metal)", edge: "var(--border-on-dark)" },
  light: { bg: "var(--mineral-white)", fg: "var(--void)", dim: "var(--quiet-metal)", edge: "var(--border-rule)" },
  field: { bg: "var(--cobalt)", fg: "var(--cold-white)", dim: "var(--text-on-field-secondary)", edge: "var(--border-on-field)" }
};

/* The instrument rail. Edge to edge, one hairline, no marketing header behaviour. */
export function GlobalRail({
  route = "SWARM",
  routes = ["MISSIONS", "INTAKE", "SWARM", "EVIDENCE", "SYNTHESIS", "EVOLUTION", "CAPABILITIES", "MEMORY"],
  mission,
  mode = "ILLUSTRATIVE",
  connection = { state: "ok", label: "4 PROVIDERS" },
  onRoute,
  onCommand,
  on = "dark",
  style,
  ...rest
}) {
  const s = SURFACE[on] || SURFACE.dark;
  const railSx = {
    display: "flex",
    alignItems: "stretch",
    height: "var(--rail-height)",
    background: s.bg,
    borderBottom: `1px solid ${s.edge}`,
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color: s.dim,
    ...style
  };
  const lockupSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-3)",
    padding: "0 var(--space-5)",
    borderRight: `1px solid ${s.edge}`,
    color: s.fg
  };
  const navSx = { display: "flex", alignItems: "stretch", flex: 1, minWidth: 0, overflow: "hidden" };
  const rightSx = { display: "flex", alignItems: "center", gap: "var(--space-5)", padding: "0 var(--space-5)", borderLeft: `1px solid ${s.edge}` };

  return (
    <header style={railSx} {...rest}>
      <div style={lockupSx}>
        <Aperture size={16} tone="inherit" state="running" />
        <span style={{ font: `var(--weight-semibold) 17px/1 var(--font-display)`, letterSpacing: "var(--tracking-label-tight)" }}>AOS</span>
      </div>
      <nav style={navSx}>
        {routes.map((r) => {
          const active = r === route;
          return (
            <button
              key={r}
              type="button"
              onClick={() => onRoute && onRoute(r)}
              style={{
                appearance: "none",
                background: active ? (on === "field" ? "rgba(250,251,255,0.16)" : "var(--cobalt)") : "transparent",
                color: active ? "var(--cold-white)" : s.dim,
                border: "none",
                borderRight: `1px solid ${s.edge}`,
                padding: "0 var(--space-5)",
                font: "inherit",
                letterSpacing: "inherit",
                textTransform: "inherit",
                cursor: "pointer",
                transition: "color var(--dur-state) var(--ease-instrument),background var(--dur-state) var(--ease-instrument)"
              }}
            >
              {r}
            </button>
          );
        })}
      </nav>
      <div style={rightSx}>
        {mission ? (
          <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`, letterSpacing: "0.04em", color: s.dim }}>
            {mission}
          </span>
        ) : null}
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
            padding: "0 6px",
            height: "18px",
            border: `1px solid ${mode === "LIVE" ? "var(--ion)" : "var(--quiet-metal)"}`,
            color: mode === "LIVE" ? (on === "light" ? "#4C7A00" : "var(--ion)") : s.dim,
            font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
            letterSpacing: "var(--tracking-label-tight)"
          }}
        >
          {mode}
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)` }}>
          <span
            style={{
              width: "5px",
              height: "5px",
              borderRadius: "var(--radius-aperture)",
              background: connection.state === "ok" ? "var(--ion)" : connection.state === "degraded" ? "var(--ultraviolet)" : "var(--vermilion)"
            }}
          />
          {connection.label}
        </span>
        <button
          type="button"
          onClick={onCommand}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "var(--space-3)",
            height: "24px",
            padding: "0 8px",
            background: "transparent",
            border: `1px solid ${s.edge}`,
            color: s.fg,
            font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
            letterSpacing: "0.04em",
            cursor: "pointer"
          }}
        >
          <Aperture size={11} tone="inherit" />
          ⌘K
        </button>
      </div>
    </header>
  );
}
