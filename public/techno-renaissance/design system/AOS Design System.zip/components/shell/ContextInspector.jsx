import React from "react";

const ROW_TONE = {
  neutral: "var(--cold-white)",
  active: "var(--state-running-on-dark)",
  verified: "var(--ion)",
  consequence: "var(--vermilion)",
  transition: "#8E72FF",
  dim: "var(--quiet-metal)"
};

/* Conditional detail region for the current selection. Renders nothing when
   `open` is false — metadata never crowds the work field by default. */
export function ContextInspector({ open = true, kind = "AGENT", title, subtitle, sections = [], actions, children, onClose, style, ...rest }) {
  if (!open) return null;
  const panelSx = {
    display: "flex",
    flexDirection: "column",
    width: "var(--inspector-width)",
    flex: "none",
    background: "var(--void-raise)",
    borderLeft: `1px solid var(--border-on-dark-strong)`,
    height: "100%",
    overflow: "hidden",
    ...style
  };
  return (
    <aside style={panelSx} {...rest}>
      <div style={{ flex: "none", padding: "var(--space-5)", borderBottom: `1px solid var(--border-on-dark)` }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)" }}>
          <span
            style={{
              font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
              letterSpacing: "var(--tracking-label)",
              textTransform: "uppercase",
              color: "var(--quiet-metal)"
            }}
          >
            {kind}
          </span>
          <button
            type="button"
            onClick={onClose}
            style={{ background: "transparent", border: "none", color: "var(--quiet-metal)", cursor: "pointer", font: `var(--type-telemetry)/1 var(--font-telemetry)`, padding: 0 }}
          >
            CLOSE ×
          </button>
        </div>
        <h2 style={{ margin: "var(--space-4) 0 0", font: `var(--weight-medium) var(--type-title-2)/var(--leading-title) var(--font-display)`, letterSpacing: "var(--tracking-title)", color: "var(--cold-white)" }}>
          {title}
        </h2>
        {subtitle ? (
          <p style={{ margin: "6px 0 0", font: `var(--weight-regular) var(--type-telemetry)/1.45 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>{subtitle}</p>
        ) : null}
      </div>
      <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
        {sections.map((sec) => (
          <div key={sec.label} style={{ borderBottom: `1px solid var(--border-on-dark)`, padding: "var(--space-5)" }}>
            <div
              style={{
                font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
                letterSpacing: "var(--tracking-label)",
                textTransform: "uppercase",
                color: "var(--quiet-metal-dim)",
                marginBottom: "var(--space-4)"
              }}
            >
              {sec.label}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
              {(sec.rows || []).map((r, i) => (
                <div key={r.k + i} style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "var(--space-5)" }}>
                  <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1.3 var(--font-telemetry)`, color: "var(--quiet-metal)", textTransform: "uppercase", letterSpacing: "var(--tracking-label-tight)" }}>
                    {r.k}
                  </span>
                  <span
                    style={{
                      font: `var(--weight-medium) var(--type-telemetry)/1.3 var(--font-telemetry)`,
                      color: ROW_TONE[r.tone || "neutral"],
                      textAlign: "right",
                      fontVariantNumeric: "tabular-nums"
                    }}
                  >
                    {r.v}
                  </span>
                </div>
              ))}
              {sec.body ? (
                <p style={{ margin: 0, font: `var(--weight-regular) var(--type-body-sm)/var(--leading-body) var(--font-interface)`, color: "var(--text-on-dark-secondary)" }}>{sec.body}</p>
              ) : null}
              {sec.children || null}
            </div>
          </div>
        ))}
        {children}
      </div>
      {actions ? (
        <div style={{ flex: "none", display: "flex", gap: "var(--space-3)", padding: "var(--space-5)", borderTop: `1px solid var(--border-on-dark-strong)` }}>{actions}</div>
      ) : null}
    </aside>
  );
}
