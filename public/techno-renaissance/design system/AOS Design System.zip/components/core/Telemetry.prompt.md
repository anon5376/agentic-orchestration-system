The system's only numeric display. Monospace, tabular figures, uppercase labels.

```jsx
<Telemetry on="dark" layout="row" items={[
  { label: "Tokens", value: "1.84M" },
  { label: "Cost", value: "$21.40", tone: "active" },
  { label: "Elapsed", value: "00:41:12" },
  { label: "Rate limit", value: "68%", tone: "consequence" }
]} />
```

- `layout="row"` for rails and headers, `grid` for inspectors and cores, `stack` for single figures beside a heading.
- Never invent a metric to fill the row; four items is a full strip.
