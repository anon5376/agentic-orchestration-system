/** The "// SECTION" region marker: the only decorative glyph in AOS. */
export interface SectionLabelProps {
  children?: React.ReactNode;
  /** Optional ordinal, e.g. "#2" or "03/08". */
  index?: React.ReactNode;
  on?: "light" | "dark";
  /** Extend a 1px rule to the end of the region. */
  rule?: boolean;
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function SectionLabel(props: SectionLabelProps): JSX.Element;
