Marks a system region. Uppercase, 11px, `--tracking-label`, prefixed with `//`.

```jsx
<SectionLabel on="dark" rule index="03/08" action={<Button on="dark" variant="ghost" size="sm">Aggregate</Button>}>
  Active causal path
</SectionLabel>
```

- One per region, never nested inside itself. Use `rule` when the region has no other top border.
