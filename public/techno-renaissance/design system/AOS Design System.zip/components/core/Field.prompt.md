Single input primitive for filters, budgets, ids and short prose.

```jsx
<Field on="dark" label="Token budget" mono prefix="--budget" value="2.5M" hint="Hard stop; the lead cannot exceed it." />
<Field on="dark" label="Mission note" multiline rows={4} />
```

- For the mission objective itself use `ObjectiveAperture`, not `Field`.
- `invalid` turns the edge and hint vermilion; keep the hint a factual constraint, not an apology.
