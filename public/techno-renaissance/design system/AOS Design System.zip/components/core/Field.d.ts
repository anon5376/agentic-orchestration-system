/** Hard-edged text input. Focus is a cobalt edge plus the aperture glyph. */
export interface FieldProps {
  label?: string;
  value?: string;
  placeholder?: string;
  hint?: string;
  /** Monospace prefix, e.g. "aos ›" or "--budget". */
  prefix?: string;
  multiline?: boolean;
  rows?: number;
  /** Use the telemetry family for ids, commands, paths and numbers. */
  mono?: boolean;
  on?: "light" | "dark";
  invalid?: boolean;
  disabled?: boolean;
  size?: "sm" | "md";
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  style?: React.CSSProperties;
}
export declare function Field(props: FieldProps): JSX.Element;
