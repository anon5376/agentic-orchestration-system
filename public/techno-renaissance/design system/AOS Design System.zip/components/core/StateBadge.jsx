import React from "react";

const STATES = {
  running: { label: "RUNNING", color: "var(--cobalt)", onDark: "var(--state-running-on-dark)" },
  waiting: { label: "WAITING", color: "var(--quiet-metal)", onDark: "var(--quiet-metal)" },
  blocked: { label: "BLOCKED", color: "var(--ultraviolet)", onDark: "#8E72FF" },
  failed: { label: "FAILED", color: "var(--vermilion)", onDark: "var(--vermilion)" },
  complete: { label: "COMPLETE", color: "#4C7A00", onDark: "var(--ion)" },
  dormant: { label: "DORMANT", color: "var(--quiet-metal-dim)", onDark: "var(--quiet-metal-dim)" },
  handoff: { label: "HANDOFF", color: "var(--ultraviolet)", onDark: "#8E72FF" },
  gate: { label: "HUMAN GATE", color: "var(--vermilion)", onDark: "var(--vermilion)" },
  verified: { label: "VERIFIED", color: "#4C7A00", onDark: "var(--ion)" }
};

export function StateBadge({ state = "running", label, on = "light", form = "outline", dot = true, style, ...rest }) {
  const s = STATES[state] || STATES.running;
  const color = on === "light" ? s.color : s.onDark;
  const solid = form === "solid";
  const badgeSx = {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    height: "18px",
    padding: form === "bare" ? 0 : "0 6px",
    border: form === "bare" ? "none" : `1px solid ${solid ? color : color}`,
    background: solid ? color : "transparent",
    color: solid ? (state === "complete" || state === "verified" ? "var(--void)" : "var(--cold-white)") : color,
    font: `var(--weight-medium) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
    letterSpacing: "var(--tracking-label-tight)",
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    ...style
  };
  const dotSx = {
    width: "5px",
    height: "5px",
    flex: "none",
    background: solid ? "currentColor" : color,
    borderRadius: state === "running" || state === "complete" ? "var(--radius-aperture)" : "0",
    opacity: state === "dormant" || state === "waiting" ? 0.7 : 1
  };
  return (
    <span style={badgeSx} {...rest}>
      {dot ? <span style={dotSx} /> : null}
      {label || s.label}
    </span>
  );
}
