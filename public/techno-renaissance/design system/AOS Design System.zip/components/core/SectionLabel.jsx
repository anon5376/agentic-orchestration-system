import React from "react";

/* `// SECTION` label. The double slash is the AOS structural marker: it means
   "this is a system region", and it is the only decorative glyph in the system. */
export function SectionLabel({ children, index, on = "light", rule = false, action, style, ...rest }) {
  const dark = on !== "light";
  const color = dark ? "var(--text-on-dark-secondary)" : "var(--text-secondary)";
  const ruleColor = dark ? "var(--border-on-dark)" : "var(--border-rule)";
  const wrapSx = {
    display: "flex",
    alignItems: "center",
    gap: "var(--space-4)",
    minHeight: "20px",
    ...style
  };
  const labelSx = {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    color,
    whiteSpace: "nowrap"
  };
  return (
    <div style={wrapSx} {...rest}>
      <span style={labelSx}>
        <span style={{ color: dark ? "var(--quiet-metal-dim)" : "var(--quiet-metal)", letterSpacing: "0" }}>//</span>
        {children}
        {index != null ? (
          <span style={{ font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`, color: "var(--quiet-metal)" }}>{index}</span>
        ) : null}
      </span>
      {rule ? <span style={{ flex: 1, height: "1px", background: ruleColor }} /> : null}
      {action ? <span style={{ flex: "none" }}>{action}</span> : null}
    </div>
  );
}
