The AOS system mark — use it anywhere the system itself is speaking (rail lockup, input focus, in-flight progress, convergence gate).

```jsx
<Aperture size={16} tone="inherit" state="running" />
<Aperture size={96} tone="white" state="converging" />
```

- `state="running"` is the only looping motion permitted in the system, and only while work is actually in flight.
- Pair with the type lockup `AOS` (display family, uppercase) — the mark never replaces the name.
- Tone `inherit` takes the rail/field colour; prefer it inside coloured chrome.
