import React from "react";

const SURFACES = {
  light: {
    primary: { bg: "var(--cobalt)", fg: "var(--cold-white)", bd: "var(--cobalt)", hoverBg: "var(--cobalt-deep)" },
    secondary: { bg: "transparent", fg: "var(--void)", bd: "var(--void)", hoverBg: "var(--surface-sunken)" },
    ghost: { bg: "transparent", fg: "var(--text-secondary)", bd: "transparent", hoverBg: "var(--surface-sunken)" },
    consequence: { bg: "var(--vermilion)", fg: "var(--cold-white)", bd: "var(--vermilion)", hoverBg: "#E22F08" }
  },
  dark: {
    primary: { bg: "var(--cobalt)", fg: "var(--cold-white)", bd: "var(--cobalt)", hoverBg: "#2733FF" },
    secondary: { bg: "transparent", fg: "var(--cold-white)", bd: "var(--border-on-dark-strong)", hoverBg: "var(--void-plate)" },
    ghost: { bg: "transparent", fg: "var(--text-on-dark-secondary)", bd: "transparent", hoverBg: "var(--void-plate)" },
    consequence: { bg: "transparent", fg: "var(--vermilion)", bd: "var(--vermilion)", hoverBg: "rgba(255,59,18,0.12)" }
  },
  field: {
    primary: { bg: "var(--cold-white)", fg: "var(--cobalt)", bd: "var(--cold-white)", hoverBg: "#E6E9FF" },
    secondary: { bg: "transparent", fg: "var(--cold-white)", bd: "var(--cold-white)", hoverBg: "rgba(250,251,255,0.14)" },
    ghost: { bg: "transparent", fg: "var(--text-on-field-secondary)", bd: "transparent", hoverBg: "rgba(250,251,255,0.1)" },
    consequence: { bg: "var(--vermilion)", fg: "var(--cold-white)", bd: "var(--vermilion)", hoverBg: "#E22F08" }
  }
};

const SIZES = {
  sm: { h: "var(--control-height)", px: "10px", fs: "var(--type-label)" },
  md: { h: "var(--control-height-lg)", px: "16px", fs: "var(--type-label-lg)" }
};

export function Button({
  variant = "primary",
  size = "md",
  on = "light",
  icon,
  iconAfter,
  disabled = false,
  full = false,
  children,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = (SURFACES[on] || SURFACES.light)[variant] || SURFACES.light.primary;
  const z = SIZES[size] || SIZES.md;
  const buttonSx = {
    display: full ? "flex" : "inline-flex",
    width: full ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-3)",
    height: z.h,
    padding: `0 ${z.px}`,
    background: hover && !disabled ? s.hoverBg : s.bg,
    color: s.fg,
    border: `1px solid ${s.bd}`,
    borderRadius: "var(--radius-none)",
    font: `var(--weight-medium) ${z.fs}/1 var(--font-interface)`,
    letterSpacing: "var(--tracking-label)",
    textTransform: "uppercase",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.34 : 1,
    transition: `background var(--dur-state) var(--ease-instrument),color var(--dur-state) var(--ease-instrument)`,
    whiteSpace: "nowrap",
    userSelect: "none"
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={buttonSx}
      {...rest}
    >
      {icon ? <span style={{ display: "flex", flex: "none" }}>{icon}</span> : null}
      {children}
      {iconAfter ? <span style={{ display: "flex", flex: "none" }}>{iconAfter}</span> : null}
    </button>
  );
}
