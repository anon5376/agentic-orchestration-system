import React from "react";

const TONE_MAP = {
  neutral: null,
  active: "var(--cobalt)",
  verified: "#4C7A00",
  consequence: "var(--vermilion)",
  transition: "var(--ultraviolet)",
  dim: "var(--quiet-metal)"
};
const TONE_MAP_DARK = {
  neutral: null,
  active: "var(--state-running-on-dark)",
  verified: "var(--ion)",
  consequence: "var(--vermilion)",
  transition: "#8E72FF",
  dim: "var(--quiet-metal-dim)"
};

/* Telemetry: labelled machine values (tokens, cost, elapsed, model, ids).
   Never decorative — every item must be a real measured value. */
export function Telemetry({ items = [], layout = "row", on = "light", size = "md", align = "left", style, ...rest }) {
  const dark = on !== "light";
  const labelColor = dark ? "var(--quiet-metal)" : "var(--quiet-metal)";
  const valueColor = dark ? "var(--cold-white)" : "var(--void)";
  const fs = size === "sm" ? "var(--type-telemetry-sm)" : "var(--type-telemetry)";

  const wrapSx = {
    display: layout === "grid" ? "grid" : "flex",
    gridTemplateColumns: layout === "grid" ? "repeat(auto-fit,minmax(78px,1fr))" : undefined,
    flexDirection: layout === "stack" ? "column" : "row",
    flexWrap: layout === "row" ? "wrap" : undefined,
    alignItems: layout === "row" ? "baseline" : "stretch",
    gap: layout === "row" ? "0" : "var(--space-4)",
    ...style
  };

  return (
    <div style={wrapSx} {...rest}>
      {items.map((it, i) => {
        const tone = (dark ? TONE_MAP_DARK : TONE_MAP)[it.tone || "neutral"];
        const itemSx =
          layout === "row"
            ? {
                display: "flex",
                alignItems: "baseline",
                gap: "6px",
                padding: "0 var(--space-4)",
                borderLeft: i === 0 ? "none" : `1px solid ${dark ? "var(--border-on-dark)" : "var(--border-hairline)"}`,
                paddingLeft: i === 0 ? 0 : "var(--space-4)"
              }
            : { display: "flex", flexDirection: "column", gap: "3px", alignItems: align === "right" ? "flex-end" : "flex-start" };
        return (
          <div key={it.label + i} style={itemSx}>
            <span
              style={{
                font: `var(--weight-regular) var(--type-telemetry-sm)/1 var(--font-telemetry)`,
                letterSpacing: "var(--tracking-label-tight)",
                textTransform: "uppercase",
                color: labelColor
              }}
            >
              {it.label}
            </span>
            <span
              style={{
                font: `var(--weight-medium) ${fs}/1.1 var(--font-telemetry)`,
                letterSpacing: "var(--tracking-telemetry)",
                color: tone || valueColor,
                fontVariantNumeric: "tabular-nums"
              }}
            >
              {it.value}
              {it.unit ? <span style={{ color: labelColor, marginLeft: "2px" }}>{it.unit}</span> : null}
            </span>
          </div>
        );
      })}
    </div>
  );
}
