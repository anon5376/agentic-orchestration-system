import React from "react";
import { Aperture } from "./Aperture.jsx";

/* Hard-edged input. Focus is marked by a cobalt edge plus the aperture glyph —
   the same mark used for the goal input focus state in DESIGN.md. */
export function Field({
  label,
  value,
  placeholder,
  hint,
  prefix,
  multiline = false,
  rows = 3,
  mono = false,
  on = "light",
  invalid = false,
  disabled = false,
  size = "md",
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const dark = on !== "light";
  const edge = invalid ? "var(--vermilion)" : focus ? "var(--cobalt)" : dark ? "var(--border-on-dark-strong)" : "var(--void)";
  const fieldSx = {
    display: "flex",
    alignItems: multiline ? "flex-start" : "center",
    gap: "var(--space-3)",
    background: dark ? "var(--void-plate)" : "var(--surface-plate)",
    border: `1px solid ${edge}`,
    boxShadow: focus ? `inset 0 0 0 1px ${edge}` : "none",
    padding: multiline ? "10px 12px" : "0 12px",
    height: multiline ? "auto" : size === "sm" ? "var(--control-height)" : "var(--control-height-lg)",
    transition: "border-color var(--dur-state) var(--ease-instrument)",
    opacity: disabled ? 0.4 : 1
  };
  const inputSx = {
    flex: 1,
    width: "100%",
    background: "transparent",
    border: "none",
    outline: "none",
    resize: multiline ? "vertical" : "none",
    color: dark ? "var(--cold-white)" : "var(--void)",
    font: `var(--weight-regular) ${size === "sm" ? "var(--type-body-sm)" : "var(--type-body)"}/${multiline ? "var(--leading-body)" : "1"} ${
      mono ? "var(--font-telemetry)" : "var(--font-interface)"
    }`,
    letterSpacing: mono ? "var(--tracking-telemetry)" : "0"
  };
  const T = multiline ? "textarea" : "input";
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)", ...style }}>
      {label ? (
        <span
          style={{
            font: `var(--weight-medium) var(--type-label)/1 var(--font-interface)`,
            letterSpacing: "var(--tracking-label)",
            textTransform: "uppercase",
            color: dark ? "var(--text-on-dark-secondary)" : "var(--text-secondary)"
          }}
        >
          {label}
        </span>
      ) : null}
      <span style={fieldSx}>
        {prefix ? (
          <span
            style={{
              font: `var(--weight-regular) var(--type-telemetry)/1 var(--font-telemetry)`,
              color: "var(--quiet-metal)",
              flex: "none",
              paddingTop: multiline ? "3px" : 0
            }}
          >
            {prefix}
          </span>
        ) : null}
        <T
          value={value}
          rows={multiline ? rows : undefined}
          placeholder={placeholder}
          disabled={disabled}
          onChange={onChange}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={inputSx}
          {...rest}
        />
        {focus ? <Aperture size={14} tone="cobalt" state="converging" style={{ flex: "none", marginTop: multiline ? "2px" : 0 }} /> : null}
      </span>
      {hint ? (
        <span
          style={{
            font: `var(--weight-regular) var(--type-telemetry-sm)/1.4 var(--font-telemetry)`,
            color: invalid ? "var(--vermilion)" : "var(--quiet-metal)"
          }}
        >
          {hint}
        </span>
      ) : null}
    </label>
  );
}
