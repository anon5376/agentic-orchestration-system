/** Hard-edged uppercase control. Square corners, 1px border, no radius.
 * @startingPoint section="AOS Core" subtitle="Controls, state, telemetry and fields" viewport="700x300"
 */
export interface ButtonProps {
  /** primary = cobalt commitment; secondary = outline; ghost = quiet; consequence = vermilion, irreversible or self-modifying. */
  variant?: "primary" | "secondary" | "ghost" | "consequence";
  size?: "sm" | "md";
  /** Which field the button sits on. Required for correct contrast. */
  on?: "light" | "dark" | "field";
  icon?: React.ReactNode;
  iconAfter?: React.ReactNode;
  disabled?: boolean;
  full?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}
export declare function Button(props: ButtonProps): JSX.Element;
