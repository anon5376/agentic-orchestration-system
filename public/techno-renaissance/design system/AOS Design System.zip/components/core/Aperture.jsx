import React from "react";

const TONES = {
  cobalt: "var(--cobalt)",
  white: "var(--cold-white)",
  void: "var(--void)",
  ion: "var(--ion)",
  ultraviolet: "var(--ultraviolet)",
  inherit: "currentColor"
};

/* The AOS system sigil: asymmetric paths compress toward a centre but do not
   terminate there — one path exits the far side as the next generation.
   Geometry is fixed; only scale, tone and state change. */
export function Aperture({ size = 16, tone = "inherit", state = "idle", title, style, ...rest }) {
  const color = TONES[tone] || tone;
  const running = state === "running";
  const converging = state === "converging";
  const apertureSx = {
    display: "block",
    color,
    flex: "none",
    transformOrigin: "50% 50%",
    animation: running ? "aos-aperture-turn 3.2s linear infinite" : "none",
    ...style
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={size >= 48 ? 1 : 1.5}
      strokeLinecap="butt"
      role={title ? "img" : "presentation"}
      aria-label={title}
      style={apertureSx}
      {...rest}
    >
      <style>{"@keyframes aos-aperture-turn{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){svg{animation:none!important}}"}</style>
      <path d="M16.98 16.18A6.5 6.5 0 1 1 16.98 7.82" />
      {size >= 20 ? <path d="M0 3 5.9 9.8" strokeOpacity={converging ? 1 : 0.72} /> : null}
      {size >= 20 ? <path d="M0 21 5.9 14.2" strokeOpacity={converging ? 1 : 0.72} /> : null}
      <path d="M0 12 23 12" />
      {converging ? <circle cx="12" cy="12" r="1.8" fill="currentColor" stroke="none" /> : null}
    </svg>
  );
}
