Fixed state vocabulary. Colour carries meaning: cobalt = running, ion = complete/verified, ultraviolet = blocked/handoff, vermilion = failed/gate, quiet metal = waiting/dormant.

```jsx
<StateBadge state="running" on="dark" />
<StateBadge state="gate" on="dark" form="solid" label="HUMAN GATE" />
<StateBadge state="dormant" on="dark" form="bare" />
```

- `form="bare"` inside `AgentNode` and table rows; `outline` in headers; `solid` at most once per screen.
- A circular dot means time-based state (running, complete); square means held state (waiting, blocked, failed).
