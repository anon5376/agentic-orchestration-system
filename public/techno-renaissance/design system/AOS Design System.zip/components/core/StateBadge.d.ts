/** Run state of an agent, task, tool, or evidence item. The state vocabulary is
 * fixed — do not introduce new states or colours. */
export interface StateBadgeProps {
  state?: "running" | "waiting" | "blocked" | "failed" | "complete" | "dormant" | "handoff" | "gate" | "verified";
  /** Override the default uppercase label (e.g. "RUNNING 4/9"). */
  label?: string;
  on?: "light" | "dark" | "field";
  /** outline (default) | solid (use once, for the dominant event) | bare (inside dense nodes) */
  form?: "outline" | "solid" | "bare";
  dot?: boolean;
  style?: React.CSSProperties;
}
export declare function StateBadge(props: StateBadgeProps): JSX.Element;
