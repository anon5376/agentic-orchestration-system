/** The AOS system sigil: converging paths, an open aperture, one path exiting
 * the far side as the next generation. Use as rail mark, focus mark, progress
 * indicator, or at composition scale on a committed field.
 * Never use it as a decorative bullet. */
export interface ApertureProps {
  /** px box. Legible from 16; below 14 drop to the field asset. */
  size?: number;
  tone?: "cobalt" | "white" | "void" | "ion" | "ultraviolet" | "inherit" | (string & {});
  /** "running" turns slowly (3.2s, honours prefers-reduced-motion); "converging" fills the core. */
  state?: "idle" | "running" | "converging";
  title?: string;
  style?: React.CSSProperties;
}
export declare function Aperture(props: ApertureProps): JSX.Element;
