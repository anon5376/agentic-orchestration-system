/** Labelled machine values: tokens, cost, elapsed, context use, rate-limit
 * pressure, model, ids. Every item must be a measured value. */
export interface TelemetryItem {
  label: string;
  value: React.ReactNode;
  unit?: string;
  tone?: "neutral" | "active" | "verified" | "consequence" | "transition" | "dim";
}
export interface TelemetryProps {
  items?: TelemetryItem[];
  /** row = hairline-separated inline strip; stack = label over value; grid = auto-fit columns. */
  layout?: "row" | "stack" | "grid";
  on?: "light" | "dark";
  size?: "sm" | "md";
  align?: "left" | "right";
  style?: React.CSSProperties;
}
export declare function Telemetry(props: TelemetryProps): JSX.Element;
