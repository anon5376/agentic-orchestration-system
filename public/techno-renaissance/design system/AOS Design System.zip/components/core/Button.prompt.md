The only button in AOS: uppercase, square, 1px border, tracking `--tracking-label`.

```jsx
<Button on="dark" variant="primary" onClick={run}>Dispatch swarm</Button>
<Button on="dark" variant="secondary" size="sm">Inspect</Button>
<Button on="dark" variant="consequence">Promote generation</Button>
```

- Always set `on` — `light` (mineral), `dark` (void), `field` (cobalt). On a cobalt field, primary inverts to white-on-cobalt.
- `consequence` is reserved for destructive, irreversible or self-modifying actions and normally appears inside a `DecisionGate`.
- One primary per region. Hover darkens (never lightens or lifts); there is no shadow and no scale on press.
