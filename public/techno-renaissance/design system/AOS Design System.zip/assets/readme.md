# assets

## What is here

| File | Use |
|---|---|
| `aperture.svg` | The AOS system sigil at instrument scale (24px box, `currentColor`). Rail mark, favicon, loading indicator, input focus mark. |
| `aperture-field.svg` | The same mark at composition scale (240px box). Hero plates, synthesis gates, mutation boundaries, thumbnail. |

## What is deliberately NOT here

**No AOS logo or wordmark file.** The AOS brief supplied no logo, and none was
invented. Wherever a mark would go, set the three letters `AOS` in the display
family (`var(--font-display)`), uppercase, `--tracking-label-tight`. That is the
lockup. See `readme.md` > ICONOGRAPHY.

The `aperture.svg` files are **not a logo**. They are the *open convergence
aperture* specified verbatim in the supplied `DESIGN.md` ("Shapes > Signature
shape"): asymmetric paths compress toward a centre but do not terminate there —
one path exits the far side as the next generation. It is a functional system
mark drawn from that written spec as plain geometry (arcs + straight lines), and
it always sits next to, never instead of, the `AOS` type lockup.

**No photography, illustration, or dither imagery.** DESIGN.md calls for
"infrastructure, machinery, fibres, chips, servers, optical systems … dithered
evidence fragments". None was supplied and none can be generated here. Image
regions in the UI kits are rendered as honest labelled slots
(`EVIDENCE PLATE · NO SOURCE IMAGE`) with generated dither/hatch atmosphere from
`tokens/surfaces.css`. Supply real imagery and the slots take it directly.

**No icon binaries.** Iconography is Lucide from CDN at stroke-width 1.25 — a
flagged substitution, documented in `readme.md` > ICONOGRAPHY.
